"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = seedFromBackup;
const utils_1 = require("@medusajs/framework/utils");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const master_service_1 = require("../modules/master_service");
const oficina_1 = require("../modules/oficina");
async function seedFromBackup({ container }) {
    const logger = container.resolve(utils_1.ContainerRegistrationKeys.LOGGER);
    const oficinaModuleService = container.resolve(oficina_1.OFICINA_MODULE);
    const masterServiceModuleService = container.resolve(master_service_1.MASTER_SERVICE_MODULE);
    const productModuleService = container.resolve(utils_1.Modules.PRODUCT);
    const userModuleService = container.resolve(utils_1.Modules.USER);
    logger.info("🔄 Iniciando população do banco com dados do backup...");
    // Ler dados convertidos
    const backupData = JSON.parse(fs_1.default.readFileSync(path_1.default.join(__dirname, "../../backup-converted.json"), "utf-8"));
    // 1. POPULAR SERVIÇOS MESTRES
    logger.info(`📦 Criando ${backupData.services.length} serviços mestres...`);
    const masterServices = [];
    for (const service of backupData.services) {
        const created = await masterServiceModuleService.createMasterServices({
            name: service.title,
            description: service.description,
            category: service.category,
        });
        masterServices.push(created);
        logger.info(`   ✔ ${service.title}`);
    }
    // 2. POPULAR OFICINAS
    logger.info(`\n🏪 Criando ${backupData.oficinas.length} oficinas...`);
    for (const oficina of backupData.oficinas) {
        // Criar usuário para o dono (verificar se já existe)
        let user;
        try {
            user = await userModuleService.createUsers({
                email: oficina.email,
                first_name: oficina.owner_name?.split(' ')[0] || oficina.name,
                last_name: oficina.owner_name?.split(' ').slice(1).join(' ') || '',
            });
        }
        catch (error) {
            // Se usuário já existe, buscar
            const existingUsers = await userModuleService.listUsers({ email: oficina.email });
            user = existingUsers[0];
        }
        // Criar oficina
        const createdOficina = await oficinaModuleService.createOficinas({
            name: oficina.name,
            cnpj: oficina.cnpj,
            email: oficina.email,
            phone: oficina.phone,
            address: oficina.address,
            description: `Oficina ${oficina.name} - ${oficina.address?.cidade || ''}`,
            status: oficina.status,
            horario_funcionamento: {
                segunda: { inicio: '08:00', fim: '18:00', ativo: 'true' },
                terca: { inicio: '08:00', fim: '18:00', ativo: 'true' },
                quarta: { inicio: '08:00', fim: '18:00', ativo: 'true' },
                quinta: { inicio: '08:00', fim: '18:00', ativo: 'true' },
                sexta: { inicio: '08:00', fim: '18:00', ativo: 'true' },
                sabado: { inicio: '08:00', fim: '13:00', ativo: 'true' },
                domingo: { inicio: '', fim: '', ativo: 'false' },
            },
            bank_details: oficina.bank_details,
        });
        logger.info(`   ✔ ${oficina.name} - ${oficina.address?.cidade}/${oficina.address?.estado}`);
    }
    logger.info("\n✅ População concluída com sucesso!");
    logger.info(`\n📊 Resumo:`);
    logger.info(`   - ${masterServices.length} serviços mestres`);
    logger.info(`   - ${backupData.oficinas.length} oficinas`);
    logger.info(`   - ~${backupData.oficinas.length * 8} produtos/serviços criados`);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VlZC1mcm9tLWJhY2t1cC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9zY3JpcHRzL3NlZWQtZnJvbS1iYWNrdXAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFPQSxpQ0EyRUM7QUFqRkQscURBQThFO0FBQzlFLDRDQUFtQjtBQUNuQixnREFBdUI7QUFDdkIsOERBQWlFO0FBQ2pFLGdEQUFtRDtBQUVwQyxLQUFLLFVBQVUsY0FBYyxDQUFDLEVBQUUsU0FBUyxFQUFZO0lBQ2xFLE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsaUNBQXlCLENBQUMsTUFBTSxDQUFDLENBQUE7SUFDbEUsTUFBTSxvQkFBb0IsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLHdCQUFjLENBQUMsQ0FBQTtJQUM5RCxNQUFNLDBCQUEwQixHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsc0NBQXFCLENBQUMsQ0FBQTtJQUMzRSxNQUFNLG9CQUFvQixHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsZUFBTyxDQUFDLE9BQU8sQ0FBQyxDQUFBO0lBQy9ELE1BQU0saUJBQWlCLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsSUFBSSxDQUFDLENBQUE7SUFFekQsTUFBTSxDQUFDLElBQUksQ0FBQyx3REFBd0QsQ0FBQyxDQUFBO0lBRXJFLHdCQUF3QjtJQUN4QixNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUMzQixZQUFFLENBQUMsWUFBWSxDQUFDLGNBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLDZCQUE2QixDQUFDLEVBQUUsT0FBTyxDQUFDLENBQzlFLENBQUE7SUFFRCw4QkFBOEI7SUFDOUIsTUFBTSxDQUFDLElBQUksQ0FBQyxjQUFjLFVBQVUsQ0FBQyxRQUFRLENBQUMsTUFBTSxzQkFBc0IsQ0FBQyxDQUFBO0lBRTNFLE1BQU0sY0FBYyxHQUFHLEVBQUUsQ0FBQTtJQUN6QixLQUFLLE1BQU0sT0FBTyxJQUFJLFVBQVUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUMxQyxNQUFNLE9BQU8sR0FBRyxNQUFNLDBCQUEwQixDQUFDLG9CQUFvQixDQUFDO1lBQ3BFLElBQUksRUFBRSxPQUFPLENBQUMsS0FBSztZQUNuQixXQUFXLEVBQUUsT0FBTyxDQUFDLFdBQVc7WUFDaEMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxRQUFRO1NBQzNCLENBQUMsQ0FBQTtRQUNGLGNBQWMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUE7UUFDNUIsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFBO0lBQ3RDLENBQUM7SUFFRCxzQkFBc0I7SUFDdEIsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsVUFBVSxDQUFDLFFBQVEsQ0FBQyxNQUFNLGNBQWMsQ0FBQyxDQUFBO0lBRXJFLEtBQUssTUFBTSxPQUFPLElBQUksVUFBVSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQzFDLHFEQUFxRDtRQUNyRCxJQUFJLElBQUksQ0FBQTtRQUNSLElBQUksQ0FBQztZQUNILElBQUksR0FBRyxNQUFNLGlCQUFpQixDQUFDLFdBQVcsQ0FBQztnQkFDekMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFLO2dCQUNwQixVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksT0FBTyxDQUFDLElBQUk7Z0JBQzdELFNBQVMsRUFBRSxPQUFPLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUU7YUFDbkUsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZiwrQkFBK0I7WUFDL0IsTUFBTSxhQUFhLEdBQUcsTUFBTSxpQkFBaUIsQ0FBQyxTQUFTLENBQUMsRUFBRSxLQUFLLEVBQUUsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUE7WUFDakYsSUFBSSxHQUFHLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQTtRQUN6QixDQUFDO1FBRUQsZ0JBQWdCO1FBQ2hCLE1BQU0sY0FBYyxHQUFHLE1BQU0sb0JBQW9CLENBQUMsY0FBYyxDQUFDO1lBQy9ELElBQUksRUFBRSxPQUFPLENBQUMsSUFBSTtZQUNsQixJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUk7WUFDbEIsS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFLO1lBQ3BCLEtBQUssRUFBRSxPQUFPLENBQUMsS0FBSztZQUNwQixPQUFPLEVBQUUsT0FBTyxDQUFDLE9BQU87WUFDeEIsV0FBVyxFQUFFLFdBQVcsT0FBTyxDQUFDLElBQUksTUFBTSxPQUFPLENBQUMsT0FBTyxFQUFFLE1BQU0sSUFBSSxFQUFFLEVBQUU7WUFDekUsTUFBTSxFQUFFLE9BQU8sQ0FBQyxNQUFNO1lBQ3RCLHFCQUFxQixFQUFFO2dCQUNyQixPQUFPLEVBQUUsRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRTtnQkFDekQsS0FBSyxFQUFFLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxHQUFHLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUU7Z0JBQ3ZELE1BQU0sRUFBRSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsR0FBRyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFO2dCQUN4RCxNQUFNLEVBQUUsRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRTtnQkFDeEQsS0FBSyxFQUFFLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxHQUFHLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUU7Z0JBQ3ZELE1BQU0sRUFBRSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsR0FBRyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFO2dCQUN4RCxPQUFPLEVBQUUsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRTthQUNqRDtZQUNELFlBQVksRUFBRSxPQUFPLENBQUMsWUFBWTtTQUNuQyxDQUFDLENBQUE7UUFFRixNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsT0FBTyxDQUFDLElBQUksTUFBTSxPQUFPLENBQUMsT0FBTyxFQUFFLE1BQU0sSUFBSSxPQUFPLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUE7SUFDN0YsQ0FBQztJQUVELE1BQU0sQ0FBQyxJQUFJLENBQUMsc0NBQXNDLENBQUMsQ0FBQTtJQUNuRCxNQUFNLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFBO0lBQzNCLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxjQUFjLENBQUMsTUFBTSxtQkFBbUIsQ0FBQyxDQUFBO0lBQzdELE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxVQUFVLENBQUMsUUFBUSxDQUFDLE1BQU0sV0FBVyxDQUFDLENBQUE7SUFDMUQsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLFVBQVUsQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsNEJBQTRCLENBQUMsQ0FBQTtBQUNsRixDQUFDIn0=