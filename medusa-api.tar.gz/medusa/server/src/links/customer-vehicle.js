"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const customer_1 = __importDefault(require("@medusajs/medusa/customer"));
const vehicle_1 = __importDefault(require("../modules/vehicle"));
/**
 * Link: Customer -> Vehicle
 *
 * Um cliente pode ter múltiplos veículos cadastrados.
 * Este link substitui a FK direta customer_id no modelo Vehicle.
 */
exports.default = (0, utils_1.defineLink)(customer_1.default.linkable.customer, vehicle_1.default.linkable.vehicle);
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3VzdG9tZXItdmVoaWNsZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9saW5rcy9jdXN0b21lci12ZWhpY2xlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEscURBQXNEO0FBQ3RELHlFQUFzRDtBQUN0RCxpRUFBOEM7QUFFOUM7Ozs7O0dBS0c7QUFFSCxrQkFBZSxJQUFBLGtCQUFVLEVBQ3ZCLGtCQUFjLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFDaEMsaUJBQWEsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUMvQixDQUFBIn0=