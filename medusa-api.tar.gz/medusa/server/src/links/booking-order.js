"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const order_1 = __importDefault(require("@medusajs/medusa/order"));
const booking_1 = __importDefault(require("../modules/booking"));
/**
 * Link: Booking -> Order
 *
 * Vincula um agendamento ao pedido (order) criado após a finalização do serviço.
 * O fluxo é: Booking (agendamento) -> Service (serviço realizado) -> Order (pedido/pagamento)
 */
exports.default = (0, utils_1.defineLink)(booking_1.default.linkable.booking, order_1.default.linkable.order);
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYm9va2luZy1vcmRlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9saW5rcy9ib29raW5nLW9yZGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEscURBQXNEO0FBQ3RELG1FQUFnRDtBQUNoRCxpRUFBOEM7QUFFOUM7Ozs7O0dBS0c7QUFFSCxrQkFBZSxJQUFBLGtCQUFVLEVBQ3ZCLGlCQUFhLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFDOUIsZUFBVyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQzNCLENBQUEifQ==