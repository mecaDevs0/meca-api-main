"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const user_1 = __importDefault(require("@medusajs/medusa/user"));
const oficina_1 = __importDefault(require("../modules/oficina"));
/**
 * Link: User -> Oficina
 *
 * Vincula um usuário (dono) a uma oficina.
 * Permite que o sistema autentique o dono da oficina e acesse seus dados.
 */
exports.default = (0, utils_1.defineLink)(user_1.default.linkable.user, oficina_1.default.linkable.oficina);
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXNlci1vZmljaW5hLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL2xpbmtzL3VzZXItb2ZpY2luYS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUFBLHFEQUFzRDtBQUN0RCxpRUFBOEM7QUFDOUMsaUVBQThDO0FBRTlDOzs7OztHQUtHO0FBRUgsa0JBQWUsSUFBQSxrQkFBVSxFQUN2QixjQUFVLENBQUMsUUFBUSxDQUFDLElBQUksRUFDeEIsaUJBQWEsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUMvQixDQUFBIn0=