"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const oficina_1 = __importDefault(require("../modules/oficina"));
const vehicle_1 = __importDefault(require("../modules/vehicle"));
/**
 * Link: Oficina -> Vehicle
 *
 * Link direto entre oficina e veículo para histórico de serviços
 */
exports.default = (0, utils_1.defineLink)(oficina_1.default.linkable.oficina, vehicle_1.default.linkable.vehicle);
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib2ZpY2luYS12ZWhpY2xlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL2xpbmtzL29maWNpbmEtdmVoaWNsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUFBLHFEQUFzRDtBQUN0RCxpRUFBOEM7QUFDOUMsaUVBQThDO0FBRTlDOzs7O0dBSUc7QUFFSCxrQkFBZSxJQUFBLGtCQUFVLEVBQ3ZCLGlCQUFhLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFDOUIsaUJBQWEsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUMvQixDQUFBIn0=