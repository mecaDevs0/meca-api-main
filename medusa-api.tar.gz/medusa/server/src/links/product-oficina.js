"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const product_1 = __importDefault(require("@medusajs/medusa/product"));
const oficina_1 = __importDefault(require("../modules/oficina"));
/**
 * Link: Product -> Oficina
 *
 * Vincula serviços (Products) às oficinas que os oferecem.
 * Uma oficina pode oferecer múltiplos serviços.
 * Um serviço pode ser oferecido por múltiplas oficinas.
 */
exports.default = (0, utils_1.defineLink)(product_1.default.linkable.product, oficina_1.default.linkable.oficina);
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvZHVjdC1vZmljaW5hLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL2xpbmtzL3Byb2R1Y3Qtb2ZpY2luYS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUFBLHFEQUFzRDtBQUN0RCx1RUFBb0Q7QUFDcEQsaUVBQThDO0FBRTlDOzs7Ozs7R0FNRztBQUVILGtCQUFlLElBQUEsa0JBQVUsRUFDdkIsaUJBQWEsQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUM5QixpQkFBYSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQy9CLENBQUEifQ==