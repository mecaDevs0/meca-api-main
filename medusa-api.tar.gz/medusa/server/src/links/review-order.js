"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const order_1 = __importDefault(require("@medusajs/medusa/order"));
const review_1 = __importDefault(require("../modules/review"));
/**
 * Link: Review -> Order
 *
 * Vincula uma avaliação ao pedido (order) correspondente.
 * Garante que o cliente só pode avaliar serviços que de fato realizou.
 */
exports.default = (0, utils_1.defineLink)(review_1.default.linkable.review, order_1.default.linkable.order);
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmV2aWV3LW9yZGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL2xpbmtzL3Jldmlldy1vcmRlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUFBLHFEQUFzRDtBQUN0RCxtRUFBZ0Q7QUFDaEQsK0RBQTRDO0FBRTVDOzs7OztHQUtHO0FBRUgsa0JBQWUsSUFBQSxrQkFBVSxFQUN2QixnQkFBWSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQzVCLGVBQVcsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUMzQixDQUFBIn0=