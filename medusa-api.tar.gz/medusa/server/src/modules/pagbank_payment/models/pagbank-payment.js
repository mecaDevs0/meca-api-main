"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PagBankPaymentStatus = void 0;
const utils_1 = require("@medusajs/framework/utils");
/**
 * Modelo para armazenar dados de transações do PagBank
 */
var PagBankPaymentStatus;
(function (PagBankPaymentStatus) {
    PagBankPaymentStatus["PENDING"] = "pending";
    PagBankPaymentStatus["AUTHORIZED"] = "authorized";
    PagBankPaymentStatus["PAID"] = "paid";
    PagBankPaymentStatus["DECLINED"] = "declined";
    PagBankPaymentStatus["REFUNDED"] = "refunded";
    PagBankPaymentStatus["CANCELLED"] = "cancelled";
})(PagBankPaymentStatus || (exports.PagBankPaymentStatus = PagBankPaymentStatus = {}));
const PagBankPayment = utils_1.model.define("pagbank_payment", {
    id: utils_1.model.id().primaryKey(),
    // Identificadores
    pagbank_transaction_id: utils_1.model.text().nullable(),
    pagbank_charge_id: utils_1.model.text().nullable(),
    // Dados da transação
    amount: utils_1.model.number(),
    currency_code: utils_1.model.text().default("brl"),
    // Status
    status: utils_1.model.enum(PagBankPaymentStatus).default(PagBankPaymentStatus.PENDING),
    // Relação com Payment Session do Medusa
    payment_session_id: utils_1.model.text(),
    // Metadata adicional do PagBank
    pagbank_response: utils_1.model.json().nullable(),
    // Informações de reembolso
    refunded_at: utils_1.model.dateTime().nullable(),
    refund_amount: utils_1.model.number().nullable(),
});
exports.default = PagBankPayment;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnYmFuay1wYXltZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vc3JjL21vZHVsZXMvcGFnYmFua19wYXltZW50L21vZGVscy9wYWdiYW5rLXBheW1lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBQWlEO0FBRWpEOztHQUVHO0FBRUgsSUFBWSxvQkFPWDtBQVBELFdBQVksb0JBQW9CO0lBQzlCLDJDQUFtQixDQUFBO0lBQ25CLGlEQUF5QixDQUFBO0lBQ3pCLHFDQUFhLENBQUE7SUFDYiw2Q0FBcUIsQ0FBQTtJQUNyQiw2Q0FBcUIsQ0FBQTtJQUNyQiwrQ0FBdUIsQ0FBQTtBQUN6QixDQUFDLEVBUFcsb0JBQW9CLG9DQUFwQixvQkFBb0IsUUFPL0I7QUFFRCxNQUFNLGNBQWMsR0FBRyxhQUFLLENBQUMsTUFBTSxDQUFDLGlCQUFpQixFQUFFO0lBQ3JELEVBQUUsRUFBRSxhQUFLLENBQUMsRUFBRSxFQUFFLENBQUMsVUFBVSxFQUFFO0lBRTNCLGtCQUFrQjtJQUNsQixzQkFBc0IsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQy9DLGlCQUFpQixFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFFMUMscUJBQXFCO0lBQ3JCLE1BQU0sRUFBRSxhQUFLLENBQUMsTUFBTSxFQUFFO0lBQ3RCLGFBQWEsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztJQUUxQyxTQUFTO0lBQ1QsTUFBTSxFQUFFLGFBQUssQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxPQUFPLENBQUMsb0JBQW9CLENBQUMsT0FBTyxDQUFDO0lBRTlFLHdDQUF3QztJQUN4QyxrQkFBa0IsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFO0lBRWhDLGdDQUFnQztJQUNoQyxnQkFBZ0IsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBRXpDLDJCQUEyQjtJQUMzQixXQUFXLEVBQUUsYUFBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUN4QyxhQUFhLEVBQUUsYUFBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLFFBQVEsRUFBRTtDQUN6QyxDQUFDLENBQUE7QUFFRixrQkFBZSxjQUFjLENBQUEifQ==