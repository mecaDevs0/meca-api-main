"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
class PagBankProviderService extends utils_1.AbstractPaymentProvider {
    constructor(container, options) {
        super(container, options);
        this.apiKey = options.api_key || process.env.PAGBANK_API_KEY;
        this.apiSecret = options.api_secret || process.env.PAGBANK_API_SECRET;
        this.pagbankApiUrl = options.environment === "production"
            ? "https://api.pagseguro.com"
            : "https://sandbox.api.pagseguro.com";
        this.paymentSessions = new Map();
    }
    async getPaymentData(context) {
        return {
            api_key: this.apiKey,
            environment: this.options_.environment,
        };
    }
    async initiatePayment(context) {
        try {
            const { amount, currency_code, context: paymentContext } = context;
            const sessionId = `pagbank_session_${Date.now()}`;
            const pagbankResponse = {
                id: sessionId,
                transaction_id: `pagbank_txn_${Date.now()}`,
                charge_id: `pagbank_charge_${Date.now()}`,
                checkout_url: `${this.pagbankApiUrl}/checkout/${sessionId}`,
                amount,
                currency_code,
                status: "pending",
            };
            // Armazenar sessão em memória (em produção, usar Redis ou banco)
            this.paymentSessions.set(sessionId, pagbankResponse);
            return {
                data: pagbankResponse,
            };
        }
        catch (error) {
            return {
                error: error.message,
                code: "PAGBANK_INITIATE_ERROR",
                detail: error,
            };
        }
    }
    async authorizePayment(paymentSessionData, context) {
        try {
            const session = this.paymentSessions.get(paymentSessionData.id);
            if (session) {
                session.status = "authorized";
                this.paymentSessions.set(paymentSessionData.id, session);
            }
            return {
                status: utils_1.PaymentSessionStatus.AUTHORIZED,
                data: paymentSessionData,
            };
        }
        catch (error) {
            return {
                error: error.message,
                code: "PAGBANK_AUTHORIZE_ERROR",
                detail: error,
            };
        }
    }
    async capturePayment(paymentData) {
        try {
            const session = this.paymentSessions.get(paymentData.id);
            if (session) {
                session.status = "paid";
                this.paymentSessions.set(paymentData.id, session);
            }
            return paymentData;
        }
        catch (error) {
            return {
                error: error.message,
                code: "PAGBANK_CAPTURE_ERROR",
                detail: error,
            };
        }
    }
    async cancelPayment(paymentData) {
        try {
            const session = this.paymentSessions.get(paymentData.id);
            if (session) {
                session.status = "cancelled";
                this.paymentSessions.set(paymentData.id, session);
            }
            return paymentData;
        }
        catch (error) {
            return {
                error: error.message,
                code: "PAGBANK_CANCEL_ERROR",
                detail: error,
            };
        }
    }
    async refundPayment(paymentData, refundAmount) {
        try {
            const session = this.paymentSessions.get(paymentData.id);
            if (session) {
                session.status = "refunded";
                session.refund_amount = refundAmount;
                session.refunded_at = new Date().toISOString();
                this.paymentSessions.set(paymentData.id, session);
            }
            return paymentData;
        }
        catch (error) {
            return {
                error: error.message,
                code: "PAGBANK_REFUND_ERROR",
                detail: error,
            };
        }
    }
    async getPaymentStatus(paymentData) {
        try {
            const session = this.paymentSessions.get(paymentData.id);
            if (!session) {
                return utils_1.PaymentSessionStatus.PENDING;
            }
            const statusMap = {
                "pending": utils_1.PaymentSessionStatus.PENDING,
                "authorized": utils_1.PaymentSessionStatus.AUTHORIZED,
                "paid": utils_1.PaymentSessionStatus.AUTHORIZED,
                "declined": utils_1.PaymentSessionStatus.ERROR,
                "refunded": utils_1.PaymentSessionStatus.CANCELED,
                "cancelled": utils_1.PaymentSessionStatus.CANCELED,
            };
            return statusMap[session.status] || utils_1.PaymentSessionStatus.PENDING;
        }
        catch (error) {
            return utils_1.PaymentSessionStatus.ERROR;
        }
    }
    async updatePayment(context) {
        return {
            data: context.data,
        };
    }
    async deletePayment(paymentData) {
        return paymentData;
    }
    async getWebhookActionAndData(data) {
        return {
            action: "not_supported",
        };
    }
}
PagBankProviderService.identifier = "pagbank";
exports.default = PagBankProviderService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL3BhZ2JhbmtfcGF5bWVudC9zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEscURBTWtDO0FBY2xDLE1BQU0sc0JBQXVCLFNBQVEsK0JBQXVDO0lBUTFFLFlBQVksU0FBUyxFQUFFLE9BQXVCO1FBQzVDLEtBQUssQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUE7UUFFekIsSUFBSSxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUMsT0FBTyxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZ0IsQ0FBQTtRQUM3RCxJQUFJLENBQUMsU0FBUyxHQUFHLE9BQU8sQ0FBQyxVQUFVLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBbUIsQ0FBQTtRQUV0RSxJQUFJLENBQUMsYUFBYSxHQUFHLE9BQU8sQ0FBQyxXQUFXLEtBQUssWUFBWTtZQUN2RCxDQUFDLENBQUMsMkJBQTJCO1lBQzdCLENBQUMsQ0FBQyxtQ0FBbUMsQ0FBQTtRQUV2QyxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksR0FBRyxFQUFFLENBQUE7SUFDbEMsQ0FBQztJQUVELEtBQUssQ0FBQyxjQUFjLENBQUMsT0FBTztRQUMxQixPQUFPO1lBQ0wsT0FBTyxFQUFFLElBQUksQ0FBQyxNQUFNO1lBQ3BCLFdBQVcsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVc7U0FDdkMsQ0FBQTtJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsZUFBZSxDQUFDLE9BQU87UUFDM0IsSUFBSSxDQUFDO1lBQ0gsTUFBTSxFQUFFLE1BQU0sRUFBRSxhQUFhLEVBQUUsT0FBTyxFQUFFLGNBQWMsRUFBRSxHQUFHLE9BQU8sQ0FBQTtZQUVsRSxNQUFNLFNBQVMsR0FBRyxtQkFBbUIsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUE7WUFFakQsTUFBTSxlQUFlLEdBQUc7Z0JBQ3RCLEVBQUUsRUFBRSxTQUFTO2dCQUNiLGNBQWMsRUFBRSxlQUFlLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRTtnQkFDM0MsU0FBUyxFQUFFLGtCQUFrQixJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUU7Z0JBQ3pDLFlBQVksRUFBRSxHQUFHLElBQUksQ0FBQyxhQUFhLGFBQWEsU0FBUyxFQUFFO2dCQUMzRCxNQUFNO2dCQUNOLGFBQWE7Z0JBQ2IsTUFBTSxFQUFFLFNBQVM7YUFDbEIsQ0FBQTtZQUVELGlFQUFpRTtZQUNqRSxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsZUFBZSxDQUFDLENBQUE7WUFFcEQsT0FBTztnQkFDTCxJQUFJLEVBQUUsZUFBZTthQUN0QixDQUFBO1FBRUgsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixPQUFPO2dCQUNMLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTztnQkFDcEIsSUFBSSxFQUFFLHdCQUF3QjtnQkFDOUIsTUFBTSxFQUFFLEtBQUs7YUFDZCxDQUFBO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsZ0JBQWdCLENBQUMsa0JBQWtCLEVBQUUsT0FBTztRQUNoRCxJQUFJLENBQUM7WUFDSCxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLENBQUMsQ0FBQTtZQUUvRCxJQUFJLE9BQU8sRUFBRSxDQUFDO2dCQUNaLE9BQU8sQ0FBQyxNQUFNLEdBQUcsWUFBWSxDQUFBO2dCQUM3QixJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLENBQUE7WUFDMUQsQ0FBQztZQUVELE9BQU87Z0JBQ0wsTUFBTSxFQUFFLDRCQUFvQixDQUFDLFVBQVU7Z0JBQ3ZDLElBQUksRUFBRSxrQkFBa0I7YUFDekIsQ0FBQTtRQUVILENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsT0FBTztnQkFDTCxLQUFLLEVBQUUsS0FBSyxDQUFDLE9BQU87Z0JBQ3BCLElBQUksRUFBRSx5QkFBeUI7Z0JBQy9CLE1BQU0sRUFBRSxLQUFLO2FBQ2QsQ0FBQTtRQUNILENBQUM7SUFDSCxDQUFDO0lBRUQsS0FBSyxDQUFDLGNBQWMsQ0FBQyxXQUFXO1FBQzlCLElBQUksQ0FBQztZQUNILE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQTtZQUV4RCxJQUFJLE9BQU8sRUFBRSxDQUFDO2dCQUNaLE9BQU8sQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFBO2dCQUN2QixJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxDQUFBO1lBQ25ELENBQUM7WUFFRCxPQUFPLFdBQVcsQ0FBQTtRQUVwQixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU87Z0JBQ0wsS0FBSyxFQUFFLEtBQUssQ0FBQyxPQUFPO2dCQUNwQixJQUFJLEVBQUUsdUJBQXVCO2dCQUM3QixNQUFNLEVBQUUsS0FBSzthQUNkLENBQUE7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUVELEtBQUssQ0FBQyxhQUFhLENBQUMsV0FBVztRQUM3QixJQUFJLENBQUM7WUFDSCxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUE7WUFFeEQsSUFBSSxPQUFPLEVBQUUsQ0FBQztnQkFDWixPQUFPLENBQUMsTUFBTSxHQUFHLFdBQVcsQ0FBQTtnQkFDNUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLEVBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQTtZQUNuRCxDQUFDO1lBRUQsT0FBTyxXQUFXLENBQUE7UUFFcEIsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixPQUFPO2dCQUNMLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTztnQkFDcEIsSUFBSSxFQUFFLHNCQUFzQjtnQkFDNUIsTUFBTSxFQUFFLEtBQUs7YUFDZCxDQUFBO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsYUFBYSxDQUFDLFdBQVcsRUFBRSxZQUFZO1FBQzNDLElBQUksQ0FBQztZQUNILE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQTtZQUV4RCxJQUFJLE9BQU8sRUFBRSxDQUFDO2dCQUNaLE9BQU8sQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFBO2dCQUMzQixPQUFPLENBQUMsYUFBYSxHQUFHLFlBQVksQ0FBQTtnQkFDcEMsT0FBTyxDQUFDLFdBQVcsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFBO2dCQUM5QyxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxDQUFBO1lBQ25ELENBQUM7WUFFRCxPQUFPLFdBQVcsQ0FBQTtRQUVwQixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU87Z0JBQ0wsS0FBSyxFQUFFLEtBQUssQ0FBQyxPQUFPO2dCQUNwQixJQUFJLEVBQUUsc0JBQXNCO2dCQUM1QixNQUFNLEVBQUUsS0FBSzthQUNkLENBQUE7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUVELEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXO1FBQ2hDLElBQUksQ0FBQztZQUNILE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQTtZQUV4RCxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQ2IsT0FBTyw0QkFBb0IsQ0FBQyxPQUFPLENBQUE7WUFDckMsQ0FBQztZQUVELE1BQU0sU0FBUyxHQUFHO2dCQUNoQixTQUFTLEVBQUUsNEJBQW9CLENBQUMsT0FBTztnQkFDdkMsWUFBWSxFQUFFLDRCQUFvQixDQUFDLFVBQVU7Z0JBQzdDLE1BQU0sRUFBRSw0QkFBb0IsQ0FBQyxVQUFVO2dCQUN2QyxVQUFVLEVBQUUsNEJBQW9CLENBQUMsS0FBSztnQkFDdEMsVUFBVSxFQUFFLDRCQUFvQixDQUFDLFFBQVE7Z0JBQ3pDLFdBQVcsRUFBRSw0QkFBb0IsQ0FBQyxRQUFRO2FBQzNDLENBQUE7WUFFRCxPQUFPLFNBQVMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksNEJBQW9CLENBQUMsT0FBTyxDQUFBO1FBRWxFLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsT0FBTyw0QkFBb0IsQ0FBQyxLQUFLLENBQUE7UUFDbkMsQ0FBQztJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsYUFBYSxDQUFDLE9BQU87UUFDekIsT0FBTztZQUNMLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSTtTQUNuQixDQUFBO0lBQ0gsQ0FBQztJQUVELEtBQUssQ0FBQyxhQUFhLENBQUMsV0FBVztRQUM3QixPQUFPLFdBQVcsQ0FBQTtJQUNwQixDQUFDO0lBRUQsS0FBSyxDQUFDLHVCQUF1QixDQUFDLElBQUk7UUFDaEMsT0FBTztZQUNMLE1BQU0sRUFBRSxlQUFzQjtTQUMvQixDQUFBO0lBQ0gsQ0FBQzs7QUF0TE0saUNBQVUsR0FBRyxTQUFTLENBQUE7QUF5TC9CLGtCQUFlLHNCQUFzQixDQUFBIn0=