"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OficinaStatus = void 0;
const utils_1 = require("@medusajs/framework/utils");
/**
 * Módulo Oficina - Representa uma Oficina parceira no marketplace MECA
 *
 * Estende o conceito de Store do Medusa para adicionar campos específicos
 * de oficinas automotivas como CNPJ, dados bancários, horário de funcionamento, etc.
 */
var OficinaStatus;
(function (OficinaStatus) {
    OficinaStatus["PENDENTE"] = "pendente";
    OficinaStatus["APROVADO"] = "aprovado";
    OficinaStatus["REJEITADO"] = "rejeitado";
    OficinaStatus["SUSPENSO"] = "suspenso";
})(OficinaStatus || (exports.OficinaStatus = OficinaStatus = {}));
const Oficina = utils_1.model.define("oficina", {
    id: utils_1.model.id().primaryKey(),
    // Informações Básicas
    name: utils_1.model.text(),
    cnpj: utils_1.model.text().unique(),
    email: utils_1.model.text(),
    phone: utils_1.model.text(),
    // Endereço completo
    address: utils_1.model.json().nullable(), // { rua, numero, bairro, cidade, estado, cep, lat, lng }
    // Informações Visuais
    logo_url: utils_1.model.text().nullable(),
    photo_urls: utils_1.model.json().nullable(), // array de URLs de fotos da oficina
    // Informações Operacionais
    description: utils_1.model.text().nullable(),
    dados_bancarios: utils_1.model.json().nullable(), // { banco, agencia, conta, tipo_conta, titular }
    horario_funcionamento: utils_1.model.json().nullable(), // { seg: { inicio: "08:00", fim: "18:00" }, ... }
    // Status de Aprovação (fluxo de onboarding)
    status: utils_1.model.enum(OficinaStatus).default(OficinaStatus.PENDENTE),
    status_reason: utils_1.model.text().nullable(), // motivo de rejeição/suspensão
    // created_at, updated_at, deleted_at são implícitos no Medusa
});
exports.default = Oficina;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib2ZpY2luYS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL29maWNpbmEvbW9kZWxzL29maWNpbmEudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBQWlEO0FBRWpEOzs7OztHQUtHO0FBRUgsSUFBWSxhQUtYO0FBTEQsV0FBWSxhQUFhO0lBQ3ZCLHNDQUFxQixDQUFBO0lBQ3JCLHNDQUFxQixDQUFBO0lBQ3JCLHdDQUF1QixDQUFBO0lBQ3ZCLHNDQUFxQixDQUFBO0FBQ3ZCLENBQUMsRUFMVyxhQUFhLDZCQUFiLGFBQWEsUUFLeEI7QUFFRCxNQUFNLE9BQU8sR0FBRyxhQUFLLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRTtJQUN0QyxFQUFFLEVBQUUsYUFBSyxDQUFDLEVBQUUsRUFBRSxDQUFDLFVBQVUsRUFBRTtJQUUzQixzQkFBc0I7SUFDdEIsSUFBSSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUU7SUFDbEIsSUFBSSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLEVBQUU7SUFDM0IsS0FBSyxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUU7SUFDbkIsS0FBSyxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUU7SUFFbkIsb0JBQW9CO0lBQ3BCLE9BQU8sRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFLEVBQUUseURBQXlEO0lBRTNGLHNCQUFzQjtJQUN0QixRQUFRLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUNqQyxVQUFVLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRSxFQUFFLG9DQUFvQztJQUV6RSwyQkFBMkI7SUFDM0IsV0FBVyxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDcEMsZUFBZSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUUsRUFBRSxpREFBaUQ7SUFDM0YscUJBQXFCLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRSxFQUFFLGtEQUFrRDtJQUVsRyw0Q0FBNEM7SUFDNUMsTUFBTSxFQUFFLGFBQUssQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUM7SUFDakUsYUFBYSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUUsRUFBRSwrQkFBK0I7SUFFdkUsOERBQThEO0NBQy9ELENBQUMsQ0FBQTtBQUVGLGtCQUFlLE9BQU8sQ0FBQSJ9