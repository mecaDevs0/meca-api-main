"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const oficina_1 = __importDefault(require("./models/oficina"));
/**
 * OficinaModuleService
 *
 * Serviço principal do módulo Oficina.
 * Fornece métodos CRUD automáticos através do MedusaService.
 */
class OficinaModuleService extends (0, utils_1.MedusaService)({ Oficina: oficina_1.default }) {
}
exports.default = OficinaModuleService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL29maWNpbmEvc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUFBLHFEQUF5RDtBQUN6RCwrREFBc0M7QUFFdEM7Ozs7O0dBS0c7QUFFSCxNQUFNLG9CQUFxQixTQUFRLElBQUEscUJBQWEsRUFBQyxFQUFFLE9BQU8sRUFBUCxpQkFBTyxFQUFFLENBQUM7Q0FBRztBQUVoRSxrQkFBZSxvQkFBb0IsQ0FBQSJ9