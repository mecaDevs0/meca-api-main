"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Migration20251016154013 = void 0;
const migrations_1 = require("@mikro-orm/migrations");
class Migration20251016154013 extends migrations_1.Migration {
    async up() {
        this.addSql(`alter table if exists "oficina" drop constraint if exists "oficina_cnpj_unique";`);
        this.addSql(`create table if not exists "oficina" ("id" text not null, "name" text not null, "cnpj" text not null, "email" text not null, "phone" text not null, "address" jsonb null, "logo_url" text null, "photo_urls" jsonb null, "description" text null, "dados_bancarios" jsonb null, "horario_funcionamento" jsonb null, "status" text check ("status" in ('pendente', 'aprovado', 'rejeitado', 'suspenso')) not null default 'pendente', "status_reason" text null, "created_at" timestamptz not null default now(), "updated_at" timestamptz not null default now(), "deleted_at" timestamptz null, constraint "oficina_pkey" primary key ("id"));`);
        this.addSql(`CREATE UNIQUE INDEX IF NOT EXISTS "IDX_oficina_cnpj_unique" ON "oficina" (cnpj) WHERE deleted_at IS NULL;`);
        this.addSql(`CREATE INDEX IF NOT EXISTS "IDX_oficina_deleted_at" ON "oficina" (deleted_at) WHERE deleted_at IS NULL;`);
    }
    async down() {
        this.addSql(`drop table if exists "oficina" cascade;`);
    }
}
exports.Migration20251016154013 = Migration20251016154013;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTWlncmF0aW9uMjAyNTEwMTYxNTQwMTMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9vZmljaW5hL21pZ3JhdGlvbnMvTWlncmF0aW9uMjAyNTEwMTYxNTQwMTMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsc0RBQWtEO0FBRWxELE1BQWEsdUJBQXdCLFNBQVEsc0JBQVM7SUFFM0MsS0FBSyxDQUFDLEVBQUU7UUFDZixJQUFJLENBQUMsTUFBTSxDQUFDLGtGQUFrRixDQUFDLENBQUM7UUFDaEcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpbkJBQWluQixDQUFDLENBQUM7UUFDL25CLElBQUksQ0FBQyxNQUFNLENBQUMsMkdBQTJHLENBQUMsQ0FBQztRQUN6SCxJQUFJLENBQUMsTUFBTSxDQUFDLHlHQUF5RyxDQUFDLENBQUM7SUFDekgsQ0FBQztJQUVRLEtBQUssQ0FBQyxJQUFJO1FBQ2pCLElBQUksQ0FBQyxNQUFNLENBQUMseUNBQXlDLENBQUMsQ0FBQztJQUN6RCxDQUFDO0NBRUY7QUFiRCwwREFhQyJ9