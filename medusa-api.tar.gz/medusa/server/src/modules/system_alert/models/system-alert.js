"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlertCategory = exports.AlertSeverity = exports.AlertType = void 0;
const utils_1 = require("@medusajs/framework/utils");
/**
 * System Alert - Alertas Automáticos do Sistema
 * Monitora anomalias e eventos importantes
 */
var AlertType;
(function (AlertType) {
    AlertType["ANOMALY"] = "anomaly";
    AlertType["WARNING"] = "warning";
    AlertType["ERROR"] = "error";
    AlertType["INFO"] = "info";
    AlertType["SECURITY"] = "security"; // Segurança
})(AlertType || (exports.AlertType = AlertType = {}));
var AlertSeverity;
(function (AlertSeverity) {
    AlertSeverity["LOW"] = "low";
    AlertSeverity["MEDIUM"] = "medium";
    AlertSeverity["HIGH"] = "high";
    AlertSeverity["CRITICAL"] = "critical";
})(AlertSeverity || (exports.AlertSeverity = AlertSeverity = {}));
var AlertCategory;
(function (AlertCategory) {
    AlertCategory["WORKSHOP"] = "workshop";
    AlertCategory["CLIENT"] = "client";
    AlertCategory["BOOKING"] = "booking";
    AlertCategory["PAYMENT"] = "payment";
    AlertCategory["REVIEW"] = "review";
    AlertCategory["SYSTEM"] = "system"; // Sistema geral
})(AlertCategory || (exports.AlertCategory = AlertCategory = {}));
const SystemAlert = utils_1.model.define("system_alert", {
    id: utils_1.model.id().primaryKey(),
    // Classificação
    type: utils_1.model.enum(AlertType),
    severity: utils_1.model.enum(AlertSeverity),
    category: utils_1.model.enum(AlertCategory),
    // Conteúdo
    title: utils_1.model.text(),
    message: utils_1.model.text(),
    details: utils_1.model.json().nullable(), // Dados adicionais
    // Contexto
    entity_type: utils_1.model.text().nullable(), // workshop, client, booking
    entity_id: utils_1.model.text().nullable(),
    // Ações
    action_required: utils_1.model.boolean().default(false),
    action_url: utils_1.model.text().nullable(), // URL para resolver
    // Controle
    is_read: utils_1.model.boolean().default(false),
    is_resolved: utils_1.model.boolean().default(false),
    resolved_at: utils_1.model.dateTime().nullable(),
    resolved_by: utils_1.model.text().nullable(),
    // Automação
    auto_generated: utils_1.model.boolean().default(true),
    triggered_by: utils_1.model.text().nullable(), // Regra que gerou o alerta
});
exports.default = SystemAlert;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3lzdGVtLWFsZXJ0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vc3JjL21vZHVsZXMvc3lzdGVtX2FsZXJ0L21vZGVscy9zeXN0ZW0tYWxlcnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBQWlEO0FBRWpEOzs7R0FHRztBQUNILElBQVksU0FNWDtBQU5ELFdBQVksU0FBUztJQUNuQixnQ0FBbUIsQ0FBQTtJQUNuQixnQ0FBbUIsQ0FBQTtJQUNuQiw0QkFBZSxDQUFBO0lBQ2YsMEJBQWEsQ0FBQTtJQUNiLGtDQUFxQixDQUFBLENBQUMsWUFBWTtBQUNwQyxDQUFDLEVBTlcsU0FBUyx5QkFBVCxTQUFTLFFBTXBCO0FBRUQsSUFBWSxhQUtYO0FBTEQsV0FBWSxhQUFhO0lBQ3ZCLDRCQUFXLENBQUE7SUFDWCxrQ0FBaUIsQ0FBQTtJQUNqQiw4QkFBYSxDQUFBO0lBQ2Isc0NBQXFCLENBQUE7QUFDdkIsQ0FBQyxFQUxXLGFBQWEsNkJBQWIsYUFBYSxRQUt4QjtBQUVELElBQVksYUFPWDtBQVBELFdBQVksYUFBYTtJQUN2QixzQ0FBcUIsQ0FBQTtJQUNyQixrQ0FBaUIsQ0FBQTtJQUNqQixvQ0FBbUIsQ0FBQTtJQUNuQixvQ0FBbUIsQ0FBQTtJQUNuQixrQ0FBaUIsQ0FBQTtJQUNqQixrQ0FBaUIsQ0FBQSxDQUFDLGdCQUFnQjtBQUNwQyxDQUFDLEVBUFcsYUFBYSw2QkFBYixhQUFhLFFBT3hCO0FBRUQsTUFBTSxXQUFXLEdBQUcsYUFBSyxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUU7SUFDL0MsRUFBRSxFQUFFLGFBQUssQ0FBQyxFQUFFLEVBQUUsQ0FBQyxVQUFVLEVBQUU7SUFFM0IsZ0JBQWdCO0lBQ2hCLElBQUksRUFBRSxhQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztJQUMzQixRQUFRLEVBQUUsYUFBSyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7SUFDbkMsUUFBUSxFQUFFLGFBQUssQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO0lBRW5DLFdBQVc7SUFDWCxLQUFLLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRTtJQUNuQixPQUFPLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRTtJQUNyQixPQUFPLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRSxFQUFFLG1CQUFtQjtJQUVyRCxXQUFXO0lBQ1gsV0FBVyxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUUsRUFBRSw0QkFBNEI7SUFDbEUsU0FBUyxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFFbEMsUUFBUTtJQUNSLGVBQWUsRUFBRSxhQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztJQUMvQyxVQUFVLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRSxFQUFFLG9CQUFvQjtJQUV6RCxXQUFXO0lBQ1gsT0FBTyxFQUFFLGFBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO0lBQ3ZDLFdBQVcsRUFBRSxhQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztJQUMzQyxXQUFXLEVBQUUsYUFBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUN4QyxXQUFXLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUVwQyxZQUFZO0lBQ1osY0FBYyxFQUFFLGFBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDO0lBQzdDLFlBQVksRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFLEVBQUUsMkJBQTJCO0NBQ25FLENBQUMsQ0FBQTtBQUVGLGtCQUFlLFdBQVcsQ0FBQSJ9