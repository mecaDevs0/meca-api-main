"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const system_alert_1 = __importDefault(require("./models/system-alert"));
class SystemAlertModuleService extends (0, utils_1.MedusaService)({
    SystemAlert: system_alert_1.default,
}) {
}
exports.default = SystemAlertModuleService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL3N5c3RlbV9hbGVydC9zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEscURBQXlEO0FBQ3pELHlFQUErQztBQUUvQyxNQUFNLHdCQUF5QixTQUFRLElBQUEscUJBQWEsRUFBQztJQUNuRCxXQUFXLEVBQVgsc0JBQVc7Q0FDWixDQUFDO0NBQUc7QUFFTCxrQkFBZSx3QkFBd0IsQ0FBQSJ9