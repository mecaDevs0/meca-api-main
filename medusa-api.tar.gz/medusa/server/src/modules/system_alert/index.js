"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SYSTEM_ALERT_MODULE = void 0;
const service_1 = __importDefault(require("./service"));
const utils_1 = require("@medusajs/framework/utils");
exports.SYSTEM_ALERT_MODULE = "system_alert";
exports.default = (0, utils_1.Module)(exports.SYSTEM_ALERT_MODULE, {
    service: service_1.default,
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9zeXN0ZW1fYWxlcnQvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEsd0RBQWdEO0FBQ2hELHFEQUFrRDtBQUVyQyxRQUFBLG1CQUFtQixHQUFHLGNBQWMsQ0FBQTtBQUVqRCxrQkFBZSxJQUFBLGNBQU0sRUFBQywyQkFBbUIsRUFBRTtJQUN6QyxPQUFPLEVBQUUsaUJBQXdCO0NBQ2xDLENBQUMsQ0FBQSJ9