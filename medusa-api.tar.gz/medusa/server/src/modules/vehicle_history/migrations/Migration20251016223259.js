"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Migration20251016223259 = void 0;
const migrations_1 = require("@mikro-orm/migrations");
class Migration20251016223259 extends migrations_1.Migration {
    async up() {
        this.addSql(`create table if not exists "vehicle_history" ("id" text not null, "vehicle_id" text not null, "booking_id" text not null, "service_name" text not null, "workshop_name" text not null, "service_date" timestamptz not null, "odometer_reading" integer null, "next_service_km" integer null, "next_service_date" timestamptz null, "notes" text null, "parts_replaced" jsonb null, "labor_hours" integer null, "parts_cost" integer not null, "labor_cost" integer not null, "total_cost" integer not null, "warranty_months" integer not null default 3, "warranty_expires_at" timestamptz null, "created_at" timestamptz not null default now(), "updated_at" timestamptz not null default now(), "deleted_at" timestamptz null, constraint "vehicle_history_pkey" primary key ("id"));`);
        this.addSql(`CREATE INDEX IF NOT EXISTS "IDX_vehicle_history_deleted_at" ON "vehicle_history" (deleted_at) WHERE deleted_at IS NULL;`);
    }
    async down() {
        this.addSql(`drop table if exists "vehicle_history" cascade;`);
    }
}
exports.Migration20251016223259 = Migration20251016223259;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTWlncmF0aW9uMjAyNTEwMTYyMjMyNTkuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy92ZWhpY2xlX2hpc3RvcnkvbWlncmF0aW9ucy9NaWdyYXRpb24yMDI1MTAxNjIyMzI1OS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxzREFBa0Q7QUFFbEQsTUFBYSx1QkFBd0IsU0FBUSxzQkFBUztJQUUzQyxLQUFLLENBQUMsRUFBRTtRQUNmLElBQUksQ0FBQyxNQUFNLENBQUMsMnZCQUEydkIsQ0FBQyxDQUFDO1FBQ3p3QixJQUFJLENBQUMsTUFBTSxDQUFDLHlIQUF5SCxDQUFDLENBQUM7SUFDekksQ0FBQztJQUVRLEtBQUssQ0FBQyxJQUFJO1FBQ2pCLElBQUksQ0FBQyxNQUFNLENBQUMsaURBQWlELENBQUMsQ0FBQztJQUNqRSxDQUFDO0NBRUY7QUFYRCwwREFXQyJ9