"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
/**
 * Vehicle History - Histórico Completo de Manutenção
 * Cada entrada representa um serviço realizado
 */
const VehicleHistory = utils_1.model.define("vehicle_history", {
    id: utils_1.model.id().primaryKey(),
    // Relacionamentos
    vehicle_id: utils_1.model.text(),
    booking_id: utils_1.model.text(),
    service_name: utils_1.model.text(),
    workshop_name: utils_1.model.text(),
    // Detalhes do Serviço
    service_date: utils_1.model.dateTime(),
    odometer_reading: utils_1.model.number().nullable(), // KM do veículo
    next_service_km: utils_1.model.number().nullable(), // Próxima manutenção em X km
    next_service_date: utils_1.model.dateTime().nullable(),
    // Documentação
    notes: utils_1.model.text().nullable(),
    parts_replaced: utils_1.model.json().nullable(), // Array de peças trocadas
    labor_hours: utils_1.model.number().nullable(),
    // Custos
    parts_cost: utils_1.model.number(), // Custo de peças em centavos
    labor_cost: utils_1.model.number(), // Custo de mão de obra
    total_cost: utils_1.model.number(), // Custo total
    // Garantia
    warranty_months: utils_1.model.number().default(3),
    warranty_expires_at: utils_1.model.dateTime().nullable(),
});
exports.default = VehicleHistory;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmVoaWNsZS1oaXN0b3J5LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vc3JjL21vZHVsZXMvdmVoaWNsZV9oaXN0b3J5L21vZGVscy92ZWhpY2xlLWhpc3RvcnkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxxREFBaUQ7QUFFakQ7OztHQUdHO0FBQ0gsTUFBTSxjQUFjLEdBQUcsYUFBSyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRTtJQUNyRCxFQUFFLEVBQUUsYUFBSyxDQUFDLEVBQUUsRUFBRSxDQUFDLFVBQVUsRUFBRTtJQUUzQixrQkFBa0I7SUFDbEIsVUFBVSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUU7SUFDeEIsVUFBVSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUU7SUFDeEIsWUFBWSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUU7SUFDMUIsYUFBYSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUU7SUFFM0Isc0JBQXNCO0lBQ3RCLFlBQVksRUFBRSxhQUFLLENBQUMsUUFBUSxFQUFFO0lBQzlCLGdCQUFnQixFQUFFLGFBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxRQUFRLEVBQUUsRUFBRSxnQkFBZ0I7SUFDN0QsZUFBZSxFQUFFLGFBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxRQUFRLEVBQUUsRUFBRSw2QkFBNkI7SUFDekUsaUJBQWlCLEVBQUUsYUFBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUU5QyxlQUFlO0lBQ2YsS0FBSyxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDOUIsY0FBYyxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUUsRUFBRSwwQkFBMEI7SUFDbkUsV0FBVyxFQUFFLGFBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFFdEMsU0FBUztJQUNULFVBQVUsRUFBRSxhQUFLLENBQUMsTUFBTSxFQUFFLEVBQUUsNkJBQTZCO0lBQ3pELFVBQVUsRUFBRSxhQUFLLENBQUMsTUFBTSxFQUFFLEVBQUUsdUJBQXVCO0lBQ25ELFVBQVUsRUFBRSxhQUFLLENBQUMsTUFBTSxFQUFFLEVBQUUsY0FBYztJQUUxQyxXQUFXO0lBQ1gsZUFBZSxFQUFFLGFBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0lBQzFDLG1CQUFtQixFQUFFLGFBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQyxRQUFRLEVBQUU7Q0FDakQsQ0FBQyxDQUFBO0FBRUYsa0JBQWUsY0FBYyxDQUFBIn0=