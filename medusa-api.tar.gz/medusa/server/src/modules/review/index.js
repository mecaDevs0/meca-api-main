"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.linkable = exports.REVIEW_MODULE = void 0;
const utils_1 = require("@medusajs/framework/utils");
const review_1 = __importDefault(require("./models/review"));
const service_1 = __importDefault(require("./service"));
exports.REVIEW_MODULE = "review";
const reviewModule = (0, utils_1.Module)(exports.REVIEW_MODULE, {
    service: service_1.default,
});
exports.default = reviewModule;
// Exportar linkable para uso em Module Links
exports.linkable = {
    review: {
        serviceName: exports.REVIEW_MODULE,
        primaryKey: "id",
        model: review_1.default,
    },
};
__exportStar(require("./models/review"), exports);
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9yZXZpZXcvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxxREFBa0Q7QUFDbEQsNkRBQW9DO0FBQ3BDLHdEQUEyQztBQUU5QixRQUFBLGFBQWEsR0FBRyxRQUFRLENBQUE7QUFFckMsTUFBTSxZQUFZLEdBQUcsSUFBQSxjQUFNLEVBQUMscUJBQWEsRUFBRTtJQUN6QyxPQUFPLEVBQUUsaUJBQW1CO0NBQzdCLENBQUMsQ0FBQTtBQUVGLGtCQUFlLFlBQVksQ0FBQTtBQUUzQiw2Q0FBNkM7QUFDaEMsUUFBQSxRQUFRLEdBQUc7SUFDdEIsTUFBTSxFQUFFO1FBQ04sV0FBVyxFQUFFLHFCQUFhO1FBQzFCLFVBQVUsRUFBRSxJQUFJO1FBQ2hCLEtBQUssRUFBRSxnQkFBTTtLQUNkO0NBQ0YsQ0FBQTtBQUVELGtEQUErQiJ9