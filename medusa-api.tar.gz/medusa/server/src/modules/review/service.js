"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const review_1 = __importDefault(require("./models/review"));
/**
 * ReviewModuleService
 *
 * Gerencia avaliações de oficinas e serviços
 */
class ReviewModuleService extends (0, utils_1.MedusaService)({ Review: review_1.default }) {
}
exports.default = ReviewModuleService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL3Jldmlldy9zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEscURBQXlEO0FBQ3pELDZEQUFvQztBQUVwQzs7OztHQUlHO0FBRUgsTUFBTSxtQkFBb0IsU0FBUSxJQUFBLHFCQUFhLEVBQUMsRUFBRSxNQUFNLEVBQU4sZ0JBQU0sRUFBRSxDQUFDO0NBQUc7QUFFOUQsa0JBQWUsbUJBQW1CLENBQUEifQ==