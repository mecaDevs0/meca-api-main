"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
/**
 * Módulo Review - Sistema de Avaliações
 *
 * Permite clientes avaliarem oficinas e serviços após a conclusão
 */
const Review = utils_1.model.define("review", {
    id: utils_1.model.id().primaryKey(),
    // Relações
    customer_id: utils_1.model.text(),
    oficina_id: utils_1.model.text(),
    booking_id: utils_1.model.text(), // Avaliação específica de um agendamento
    product_id: utils_1.model.text().nullable(), // Serviço avaliado
    // Avaliação
    rating: utils_1.model.number(), // 1 a 5 estrelas
    title: utils_1.model.text().nullable(),
    comment: utils_1.model.text().nullable(),
    // Resposta da Oficina
    oficina_response: utils_1.model.text().nullable(),
    oficina_response_at: utils_1.model.dateTime().nullable(),
    // Moderação
    is_approved: utils_1.model.boolean().default(true),
    is_flagged: utils_1.model.boolean().default(false),
    moderator_notes: utils_1.model.text().nullable(),
});
exports.default = Review;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmV2aWV3LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vc3JjL21vZHVsZXMvcmV2aWV3L21vZGVscy9yZXZpZXcudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxxREFBaUQ7QUFFakQ7Ozs7R0FJRztBQUVILE1BQU0sTUFBTSxHQUFHLGFBQUssQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFO0lBQ3BDLEVBQUUsRUFBRSxhQUFLLENBQUMsRUFBRSxFQUFFLENBQUMsVUFBVSxFQUFFO0lBRTNCLFdBQVc7SUFDWCxXQUFXLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRTtJQUN6QixVQUFVLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRTtJQUN4QixVQUFVLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxFQUFFLHlDQUF5QztJQUNuRSxVQUFVLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRSxFQUFFLG1CQUFtQjtJQUV4RCxZQUFZO0lBQ1osTUFBTSxFQUFFLGFBQUssQ0FBQyxNQUFNLEVBQUUsRUFBRSxpQkFBaUI7SUFDekMsS0FBSyxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDOUIsT0FBTyxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFFaEMsc0JBQXNCO0lBQ3RCLGdCQUFnQixFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDekMsbUJBQW1CLEVBQUUsYUFBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUVoRCxZQUFZO0lBQ1osV0FBVyxFQUFFLGFBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDO0lBQzFDLFVBQVUsRUFBRSxhQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztJQUMxQyxlQUFlLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtDQUN6QyxDQUFDLENBQUE7QUFFRixrQkFBZSxNQUFNLENBQUEifQ==