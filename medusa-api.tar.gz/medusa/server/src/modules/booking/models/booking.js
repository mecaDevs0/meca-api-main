"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BookingStatus = void 0;
const utils_1 = require("@medusajs/framework/utils");
/**
 * Módulo Booking - Representa um Agendamento de Serviço
 *
 * Esta é a entidade central do MECA que conecta:
 * - Cliente (Customer)
 * - Veículo (Vehicle)
 * - Oficina (Oficina)
 * - Serviço (Product)
 * - Pedido (Order)
 */
var BookingStatus;
(function (BookingStatus) {
    BookingStatus["PENDENTE_OFICINA"] = "pendente_oficina";
    BookingStatus["CONFIRMADO"] = "confirmado";
    BookingStatus["RECUSADO"] = "recusado";
    BookingStatus["FINALIZADO_MECANICO"] = "finalizado_mecanico";
    BookingStatus["FINALIZADO_CLIENTE"] = "finalizado_cliente";
    BookingStatus["CANCELADO"] = "cancelado";
    BookingStatus["NAO_COMPARECEU"] = "nao_compareceu"; // Cliente não compareceu
})(BookingStatus || (exports.BookingStatus = BookingStatus = {}));
const Booking = utils_1.model.define("booking", {
    id: utils_1.model.id().primaryKey(),
    // Data e Hora do Agendamento
    appointment_date: utils_1.model.dateTime(),
    // Relações (serão criadas via Module Links)
    customer_id: utils_1.model.text(),
    vehicle_id: utils_1.model.text(),
    oficina_id: utils_1.model.text(),
    product_id: utils_1.model.text(), // Serviço agendado
    order_id: utils_1.model.text().nullable(), // Pedido gerado a partir deste agendamento
    // Status do Agendamento
    status: utils_1.model.enum(BookingStatus).default(BookingStatus.PENDENTE_OFICINA),
    status_history: utils_1.model.json().nullable(), // histórico de mudanças de status
    // Informações do Veículo no momento do agendamento (snapshot)
    vehicle_snapshot: utils_1.model.json().nullable(), // { marca, modelo, ano, placa, km }
    // Observações
    customer_notes: utils_1.model.text().nullable(), // Observações do cliente
    oficina_notes: utils_1.model.text().nullable(), // Observações da oficina
    // Informações de Preço (podem mudar após agendamento)
    estimated_price: utils_1.model.number().nullable(),
    final_price: utils_1.model.number().nullable(),
    // Timestamps Customizados (created_at, updated_at, deleted_at são implícitos)
    confirmed_at: utils_1.model.dateTime().nullable(),
    completed_at: utils_1.model.dateTime().nullable(),
    cancelled_at: utils_1.model.dateTime().nullable(),
});
exports.default = Booking;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYm9va2luZy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL2Jvb2tpbmcvbW9kZWxzL2Jvb2tpbmcudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBQWlEO0FBRWpEOzs7Ozs7Ozs7R0FTRztBQUVILElBQVksYUFRWDtBQVJELFdBQVksYUFBYTtJQUN2QixzREFBcUMsQ0FBQTtJQUNyQywwQ0FBeUIsQ0FBQTtJQUN6QixzQ0FBcUIsQ0FBQTtJQUNyQiw0REFBMkMsQ0FBQTtJQUMzQywwREFBeUMsQ0FBQTtJQUN6Qyx3Q0FBdUIsQ0FBQTtJQUN2QixrREFBaUMsQ0FBQSxDQUFhLHlCQUF5QjtBQUN6RSxDQUFDLEVBUlcsYUFBYSw2QkFBYixhQUFhLFFBUXhCO0FBRUQsTUFBTSxPQUFPLEdBQUcsYUFBSyxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUU7SUFDdEMsRUFBRSxFQUFFLGFBQUssQ0FBQyxFQUFFLEVBQUUsQ0FBQyxVQUFVLEVBQUU7SUFFM0IsNkJBQTZCO0lBQzdCLGdCQUFnQixFQUFFLGFBQUssQ0FBQyxRQUFRLEVBQUU7SUFFbEMsNENBQTRDO0lBQzVDLFdBQVcsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFO0lBQ3pCLFVBQVUsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFO0lBQ3hCLFVBQVUsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFO0lBQ3hCLFVBQVUsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLEVBQUcsbUJBQW1CO0lBQzlDLFFBQVEsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFLEVBQUcsMkNBQTJDO0lBRS9FLHdCQUF3QjtJQUN4QixNQUFNLEVBQUUsYUFBSyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDO0lBQ3pFLGNBQWMsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFLEVBQUUsa0NBQWtDO0lBRTNFLDhEQUE4RDtJQUM5RCxnQkFBZ0IsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFLEVBQUUsb0NBQW9DO0lBRS9FLGNBQWM7SUFDZCxjQUFjLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRSxFQUFHLHlCQUF5QjtJQUNuRSxhQUFhLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRSxFQUFJLHlCQUF5QjtJQUVuRSxzREFBc0Q7SUFDdEQsZUFBZSxFQUFFLGFBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDMUMsV0FBVyxFQUFFLGFBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFFdEMsOEVBQThFO0lBQzlFLFlBQVksRUFBRSxhQUFLLENBQUMsUUFBUSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQ3pDLFlBQVksRUFBRSxhQUFLLENBQUMsUUFBUSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQ3pDLFlBQVksRUFBRSxhQUFLLENBQUMsUUFBUSxFQUFFLENBQUMsUUFBUSxFQUFFO0NBQzFDLENBQUMsQ0FBQTtBQUVGLGtCQUFlLE9BQU8sQ0FBQSJ9