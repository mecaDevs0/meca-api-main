"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
class FcmNotificationService extends utils_1.AbstractNotificationProviderService {
    constructor(container, options) {
        super(container);
        this.serverKey = options.server_key || process.env.FCM_SERVER_KEY;
        this.projectId = options.project_id || process.env.FCM_PROJECT_ID;
        this.deviceTokens = new Map();
    }
    async send(notification) {
        try {
            const { to, title, body, data } = notification;
            const tokens = await this.getDeviceTokens(to);
            if (tokens.length === 0) {
                return {
                    to: Array.isArray(to) ? to.join(", ") : to,
                    status: "no_tokens",
                    data: {}
                };
            }
            console.log(`[FCM] Enviando notificação para ${tokens.length} dispositivo(s):`, {
                title,
                body,
                recipients: Array.isArray(to) ? to : [to]
            });
            return {
                to: Array.isArray(to) ? to.join(", ") : to,
                status: "sent",
                data: {
                    tokens_sent: tokens.length,
                }
            };
        }
        catch (error) {
            console.error("[FCM] Erro ao enviar notificação:", error);
            return {
                to: Array.isArray(to) ? to.join(", ") : to,
                status: "error",
                data: {
                    error: error.message
                }
            };
        }
    }
    async getDeviceTokens(recipients) {
        const recipientArray = Array.isArray(recipients) ? recipients : [recipients];
        // Em memória por enquanto (em produção, buscar do banco)
        const tokens = [];
        for (const recipient of recipientArray) {
            const userTokens = this.deviceTokens.get(recipient);
            if (userTokens) {
                tokens.push(...userTokens);
            }
        }
        return tokens;
    }
    async registerDeviceToken(userId, isCustomer, token, platform, deviceName) {
        try {
            // Armazenar em memória (em produção, salvar no banco)
            const existingTokens = this.deviceTokens.get(userId) || [];
            if (!existingTokens.includes(token)) {
                existingTokens.push(token);
                this.deviceTokens.set(userId, existingTokens);
            }
            console.log(`[FCM] Token registrado para usuário ${userId}: ${token.substring(0, 20)}...`);
            return {
                id: `device_${Date.now()}`,
                fcm_token: token,
                user_id: !isCustomer ? userId : null,
                customer_id: isCustomer ? userId : null,
                platform,
                device_name: deviceName,
                is_active: true,
            };
        }
        catch (error) {
            console.error("[FCM] Erro ao registrar token:", error);
            throw error;
        }
    }
}
FcmNotificationService.identifier = "fcm";
exports.default = FcmNotificationService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL2ZjbV9ub3RpZmljYXRpb24vc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHFEQUdrQztBQWNsQyxNQUFNLHNCQUF1QixTQUFRLDJDQUFtQztJQU90RSxZQUFZLFNBQTBCLEVBQUUsT0FBbUI7UUFDekQsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFBO1FBRWhCLElBQUksQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFDLFVBQVUsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWUsQ0FBQTtRQUNsRSxJQUFJLENBQUMsU0FBUyxHQUFHLE9BQU8sQ0FBQyxVQUFVLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFlLENBQUE7UUFFbEUsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFBO0lBQy9CLENBQUM7SUFFRCxLQUFLLENBQUMsSUFBSSxDQUFDLFlBQThCO1FBQ3ZDLElBQUksQ0FBQztZQUNILE1BQU0sRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsR0FBRyxZQUFZLENBQUE7WUFFOUMsTUFBTSxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUMsZUFBZSxDQUFDLEVBQUUsQ0FBQyxDQUFBO1lBRTdDLElBQUksTUFBTSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDeEIsT0FBTztvQkFDTCxFQUFFLEVBQUUsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtvQkFDMUMsTUFBTSxFQUFFLFdBQVc7b0JBQ25CLElBQUksRUFBRSxFQUFFO2lCQUNULENBQUE7WUFDSCxDQUFDO1lBRUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUMsTUFBTSxDQUFDLE1BQU0sa0JBQWtCLEVBQUU7Z0JBQzlFLEtBQUs7Z0JBQ0wsSUFBSTtnQkFDSixVQUFVLEVBQUUsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQzthQUMxQyxDQUFDLENBQUE7WUFFRixPQUFPO2dCQUNMLEVBQUUsRUFBRSxLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUMxQyxNQUFNLEVBQUUsTUFBTTtnQkFDZCxJQUFJLEVBQUU7b0JBQ0osV0FBVyxFQUFFLE1BQU0sQ0FBQyxNQUFNO2lCQUMzQjthQUNGLENBQUE7UUFFSCxDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsbUNBQW1DLEVBQUUsS0FBSyxDQUFDLENBQUE7WUFFekQsT0FBTztnQkFDTCxFQUFFLEVBQUUsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDMUMsTUFBTSxFQUFFLE9BQU87Z0JBQ2YsSUFBSSxFQUFFO29CQUNKLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTztpQkFDckI7YUFDRixDQUFBO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFFTyxLQUFLLENBQUMsZUFBZSxDQUFDLFVBQTZCO1FBQ3pELE1BQU0sY0FBYyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQTtRQUU1RSx5REFBeUQ7UUFDekQsTUFBTSxNQUFNLEdBQWEsRUFBRSxDQUFBO1FBRTNCLEtBQUssTUFBTSxTQUFTLElBQUksY0FBYyxFQUFFLENBQUM7WUFDdkMsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUE7WUFDbkQsSUFBSSxVQUFVLEVBQUUsQ0FBQztnQkFDZixNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsVUFBVSxDQUFDLENBQUE7WUFDNUIsQ0FBQztRQUNILENBQUM7UUFFRCxPQUFPLE1BQU0sQ0FBQTtJQUNmLENBQUM7SUFFRCxLQUFLLENBQUMsbUJBQW1CLENBQ3ZCLE1BQWMsRUFDZCxVQUFtQixFQUNuQixLQUFhLEVBQ2IsUUFBZ0IsRUFDaEIsVUFBbUI7UUFFbkIsSUFBSSxDQUFDO1lBQ0gsc0RBQXNEO1lBQ3RELE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQTtZQUUxRCxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUNwQyxjQUFjLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFBO2dCQUMxQixJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsY0FBYyxDQUFDLENBQUE7WUFDL0MsQ0FBQztZQUVELE9BQU8sQ0FBQyxHQUFHLENBQUMsdUNBQXVDLE1BQU0sS0FBSyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUE7WUFFMUYsT0FBTztnQkFDTCxFQUFFLEVBQUUsVUFBVSxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUU7Z0JBQzFCLFNBQVMsRUFBRSxLQUFLO2dCQUNoQixPQUFPLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSTtnQkFDcEMsV0FBVyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJO2dCQUN2QyxRQUFRO2dCQUNSLFdBQVcsRUFBRSxVQUFVO2dCQUN2QixTQUFTLEVBQUUsSUFBSTthQUNoQixDQUFBO1FBRUgsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLGdDQUFnQyxFQUFFLEtBQUssQ0FBQyxDQUFBO1lBQ3RELE1BQU0sS0FBSyxDQUFBO1FBQ2IsQ0FBQztJQUNILENBQUM7O0FBeEdNLGlDQUFVLEdBQUcsS0FBSyxDQUFBO0FBMkczQixrQkFBZSxzQkFBc0IsQ0FBQSJ9