"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DevicePlatform = void 0;
const utils_1 = require("@medusajs/framework/utils");
var DevicePlatform;
(function (DevicePlatform) {
    DevicePlatform["ANDROID"] = "android";
    DevicePlatform["IOS"] = "ios";
})(DevicePlatform || (exports.DevicePlatform = DevicePlatform = {}));
const DeviceToken = utils_1.model.define("device_token", {
    id: utils_1.model.id().primaryKey(),
    fcm_token: utils_1.model.text().unique(),
    user_id: utils_1.model.text().nullable(),
    customer_id: utils_1.model.text().nullable(),
    platform: utils_1.model.enum(DevicePlatform),
    device_name: utils_1.model.text().nullable(),
    app_version: utils_1.model.text().nullable(),
    is_active: utils_1.model.boolean().default(true),
    last_used_at: utils_1.model.dateTime().nullable(),
});
exports.default = DeviceToken;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGV2aWNlLXRva2VuLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vc3JjL21vZHVsZXMvZmNtX25vdGlmaWNhdGlvbi9tb2RlbHMvZGV2aWNlLXRva2VuLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFEQUFpRDtBQUVqRCxJQUFZLGNBR1g7QUFIRCxXQUFZLGNBQWM7SUFDeEIscUNBQW1CLENBQUE7SUFDbkIsNkJBQVcsQ0FBQTtBQUNiLENBQUMsRUFIVyxjQUFjLDhCQUFkLGNBQWMsUUFHekI7QUFFRCxNQUFNLFdBQVcsR0FBRyxhQUFLLENBQUMsTUFBTSxDQUFDLGNBQWMsRUFBRTtJQUMvQyxFQUFFLEVBQUUsYUFBSyxDQUFDLEVBQUUsRUFBRSxDQUFDLFVBQVUsRUFBRTtJQUUzQixTQUFTLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLE1BQU0sRUFBRTtJQUVoQyxPQUFPLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUNoQyxXQUFXLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUVwQyxRQUFRLEVBQUUsYUFBSyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUM7SUFDcEMsV0FBVyxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDcEMsV0FBVyxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFFcEMsU0FBUyxFQUFFLGFBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDO0lBQ3hDLFlBQVksRUFBRSxhQUFLLENBQUMsUUFBUSxFQUFFLENBQUMsUUFBUSxFQUFFO0NBQzFDLENBQUMsQ0FBQTtBQUVGLGtCQUFlLFdBQVcsQ0FBQSJ9