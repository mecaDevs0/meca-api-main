"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const vehicle_1 = __importDefault(require("./models/vehicle"));
/**
 * VehicleModuleService
 *
 * Serviço principal do módulo Vehicle.
 * Gerencia os veículos dos clientes.
 */
class VehicleModuleService extends (0, utils_1.MedusaService)({ Vehicle: vehicle_1.default }) {
}
exports.default = VehicleModuleService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL3ZlaGljbGUvc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUFBLHFEQUF5RDtBQUN6RCwrREFBc0M7QUFFdEM7Ozs7O0dBS0c7QUFFSCxNQUFNLG9CQUFxQixTQUFRLElBQUEscUJBQWEsRUFBQyxFQUFFLE9BQU8sRUFBUCxpQkFBTyxFQUFFLENBQUM7Q0FBRztBQUVoRSxrQkFBZSxvQkFBb0IsQ0FBQSJ9