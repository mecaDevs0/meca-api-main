"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
/**
 * Módulo Vehicle - Representa um veículo de um cliente
 *
 * Cada cliente pode cadastrar múltiplos veículos.
 * Os veículos são usados no agendamento de serviços.
 */
const Vehicle = utils_1.model.define("vehicle", {
    id: utils_1.model.id().primaryKey(),
    // Informações do Veículo
    marca: utils_1.model.text(), // ex: "Toyota"
    modelo: utils_1.model.text(), // ex: "Corolla"
    ano: utils_1.model.number(), // ex: 2020
    placa: utils_1.model.text(), // ex: "ABC-1234"
    cor: utils_1.model.text().nullable(),
    // Informações Adicionais
    km_atual: utils_1.model.number().nullable(),
    combustivel: utils_1.model.text().nullable(), // gasolina, etanol, diesel, flex, eletrico
    observacoes: utils_1.model.text().nullable(),
    // Relação com Customer (será criada via Module Link)
    customer_id: utils_1.model.text(),
    // created_at, updated_at, deleted_at são implícitos no Medusa
});
exports.default = Vehicle;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmVoaWNsZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL3ZlaGljbGUvbW9kZWxzL3ZlaGljbGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxxREFBaUQ7QUFFakQ7Ozs7O0dBS0c7QUFFSCxNQUFNLE9BQU8sR0FBRyxhQUFLLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRTtJQUN0QyxFQUFFLEVBQUUsYUFBSyxDQUFDLEVBQUUsRUFBRSxDQUFDLFVBQVUsRUFBRTtJQUUzQix5QkFBeUI7SUFDekIsS0FBSyxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsRUFBRSxlQUFlO0lBQ3BDLE1BQU0sRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLEVBQUUsZ0JBQWdCO0lBQ3RDLEdBQUcsRUFBRSxhQUFLLENBQUMsTUFBTSxFQUFFLEVBQUUsV0FBVztJQUNoQyxLQUFLLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxFQUFFLGlCQUFpQjtJQUN0QyxHQUFHLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUU1Qix5QkFBeUI7SUFDekIsUUFBUSxFQUFFLGFBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDbkMsV0FBVyxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUUsRUFBRSwyQ0FBMkM7SUFDakYsV0FBVyxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFFcEMscURBQXFEO0lBQ3JELFdBQVcsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFO0lBRXpCLDhEQUE4RDtDQUMvRCxDQUFDLENBQUE7QUFFRixrQkFBZSxPQUFPLENBQUEifQ==