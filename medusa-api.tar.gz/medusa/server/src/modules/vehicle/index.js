"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.linkable = exports.VEHICLE_MODULE = void 0;
const service_1 = __importDefault(require("./service"));
const utils_1 = require("@medusajs/framework/utils");
const vehicle_1 = __importDefault(require("./models/vehicle"));
/**
 * Definição do Módulo Vehicle
 *
 * Este módulo gerencia os veículos dos clientes
 */
exports.VEHICLE_MODULE = "vehicle";
const vehicleModule = (0, utils_1.Module)(exports.VEHICLE_MODULE, {
    service: service_1.default,
});
exports.default = vehicleModule;
// Exportar linkable para uso em Module Links
exports.linkable = {
    vehicle: {
        serviceName: exports.VEHICLE_MODULE,
        primaryKey: "id",
        model: vehicle_1.default,
    },
};
__exportStar(require("./models/vehicle"), exports);
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy92ZWhpY2xlL2luZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsd0RBQTRDO0FBQzVDLHFEQUFrRDtBQUNsRCwrREFBc0M7QUFFdEM7Ozs7R0FJRztBQUVVLFFBQUEsY0FBYyxHQUFHLFNBQVMsQ0FBQTtBQUV2QyxNQUFNLGFBQWEsR0FBRyxJQUFBLGNBQU0sRUFBQyxzQkFBYyxFQUFFO0lBQzNDLE9BQU8sRUFBRSxpQkFBb0I7Q0FDOUIsQ0FBQyxDQUFBO0FBRUYsa0JBQWUsYUFBYSxDQUFBO0FBRTVCLDZDQUE2QztBQUNoQyxRQUFBLFFBQVEsR0FBRztJQUN0QixPQUFPLEVBQUU7UUFDUCxXQUFXLEVBQUUsc0JBQWM7UUFDM0IsVUFBVSxFQUFFLElBQUk7UUFDaEIsS0FBSyxFQUFFLGlCQUFPO0tBQ2Y7Q0FDRixDQUFBO0FBRUQsbURBQWdDIn0=