"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Migration20251016223300 = void 0;
const migrations_1 = require("@mikro-orm/migrations");
class Migration20251016223300 extends migrations_1.Migration {
    async up() {
        this.addSql(`create table if not exists "service_photo" ("id" text not null, "booking_id" text not null, "workshop_id" text not null, "photo_type" text check ("photo_type" in ('before', 'after', 'parts', 'problem', 'inspection')) not null, "url" text not null, "thumbnail_url" text null, "caption" text null, "taken_at" timestamptz not null, "uploaded_by" text not null, "file_size" integer null, "mime_type" text null, "width" integer null, "height" integer null, "created_at" timestamptz not null default now(), "updated_at" timestamptz not null default now(), "deleted_at" timestamptz null, constraint "service_photo_pkey" primary key ("id"));`);
        this.addSql(`CREATE INDEX IF NOT EXISTS "IDX_service_photo_deleted_at" ON "service_photo" (deleted_at) WHERE deleted_at IS NULL;`);
    }
    async down() {
        this.addSql(`drop table if exists "service_photo" cascade;`);
    }
}
exports.Migration20251016223300 = Migration20251016223300;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTWlncmF0aW9uMjAyNTEwMTYyMjMzMDAuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9zZXJ2aWNlX3Bob3RvL21pZ3JhdGlvbnMvTWlncmF0aW9uMjAyNTEwMTYyMjMzMDAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsc0RBQWtEO0FBRWxELE1BQWEsdUJBQXdCLFNBQVEsc0JBQVM7SUFFM0MsS0FBSyxDQUFDLEVBQUU7UUFDZixJQUFJLENBQUMsTUFBTSxDQUFDLDJuQkFBMm5CLENBQUMsQ0FBQztRQUN6b0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxxSEFBcUgsQ0FBQyxDQUFDO0lBQ3JJLENBQUM7SUFFUSxLQUFLLENBQUMsSUFBSTtRQUNqQixJQUFJLENBQUMsTUFBTSxDQUFDLCtDQUErQyxDQUFDLENBQUM7SUFDL0QsQ0FBQztDQUVGO0FBWEQsMERBV0MifQ==