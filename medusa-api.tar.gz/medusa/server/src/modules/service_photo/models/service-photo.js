"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PhotoType = void 0;
const utils_1 = require("@medusajs/framework/utils");
/**
 * Service Photo - Fotos Antes/Depois do Serviço
 * Documentação visual do trabalho realizado
 */
var PhotoType;
(function (PhotoType) {
    PhotoType["BEFORE"] = "before";
    PhotoType["AFTER"] = "after";
    PhotoType["PARTS"] = "parts";
    PhotoType["PROBLEM"] = "problem";
    PhotoType["INSPECTION"] = "inspection"; // Inspeção geral
})(PhotoType || (exports.PhotoType = PhotoType = {}));
const ServicePhoto = utils_1.model.define("service_photo", {
    id: utils_1.model.id().primaryKey(),
    // Relacionamentos
    booking_id: utils_1.model.text(),
    workshop_id: utils_1.model.text(),
    // Detalhes da Foto
    photo_type: utils_1.model.enum(PhotoType),
    url: utils_1.model.text(), // URL da imagem no S3
    thumbnail_url: utils_1.model.text().nullable(),
    // Metadados
    caption: utils_1.model.text().nullable(), // Descrição/legenda
    taken_at: utils_1.model.dateTime(),
    uploaded_by: utils_1.model.text(), // ID do mecânico/oficina
    // Informações Técnicas
    file_size: utils_1.model.number().nullable(),
    mime_type: utils_1.model.text().nullable(),
    width: utils_1.model.number().nullable(),
    height: utils_1.model.number().nullable(),
});
exports.default = ServicePhoto;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS1waG90by5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL3NlcnZpY2VfcGhvdG8vbW9kZWxzL3NlcnZpY2UtcGhvdG8udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBQWlEO0FBRWpEOzs7R0FHRztBQUNILElBQVksU0FNWDtBQU5ELFdBQVksU0FBUztJQUNuQiw4QkFBaUIsQ0FBQTtJQUNqQiw0QkFBZSxDQUFBO0lBQ2YsNEJBQWUsQ0FBQTtJQUNmLGdDQUFtQixDQUFBO0lBQ25CLHNDQUF5QixDQUFBLENBQUMsaUJBQWlCO0FBQzdDLENBQUMsRUFOVyxTQUFTLHlCQUFULFNBQVMsUUFNcEI7QUFFRCxNQUFNLFlBQVksR0FBRyxhQUFLLENBQUMsTUFBTSxDQUFDLGVBQWUsRUFBRTtJQUNqRCxFQUFFLEVBQUUsYUFBSyxDQUFDLEVBQUUsRUFBRSxDQUFDLFVBQVUsRUFBRTtJQUUzQixrQkFBa0I7SUFDbEIsVUFBVSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUU7SUFDeEIsV0FBVyxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUU7SUFFekIsbUJBQW1CO0lBQ25CLFVBQVUsRUFBRSxhQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztJQUNqQyxHQUFHLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxFQUFFLHNCQUFzQjtJQUN6QyxhQUFhLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUV0QyxZQUFZO0lBQ1osT0FBTyxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUUsRUFBRSxvQkFBb0I7SUFDdEQsUUFBUSxFQUFFLGFBQUssQ0FBQyxRQUFRLEVBQUU7SUFDMUIsV0FBVyxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsRUFBRSx5QkFBeUI7SUFFcEQsdUJBQXVCO0lBQ3ZCLFNBQVMsRUFBRSxhQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQ3BDLFNBQVMsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQ2xDLEtBQUssRUFBRSxhQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQ2hDLE1BQU0sRUFBRSxhQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsUUFBUSxFQUFFO0NBQ2xDLENBQUMsQ0FBQTtBQUVGLGtCQUFlLFlBQVksQ0FBQSJ9