"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const master_service_1 = __importDefault(require("./models/master-service"));
/**
 * MasterServiceModuleService
 *
 * Gerencia o catálogo de serviços base
 */
class MasterServiceModuleService extends (0, utils_1.MedusaService)({ MasterService: master_service_1.default }) {
}
exports.default = MasterServiceModuleService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL21hc3Rlcl9zZXJ2aWNlL3NlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSxxREFBeUQ7QUFDekQsNkVBQW1EO0FBRW5EOzs7O0dBSUc7QUFFSCxNQUFNLDBCQUEyQixTQUFRLElBQUEscUJBQWEsRUFBQyxFQUFFLGFBQWEsRUFBYix3QkFBYSxFQUFFLENBQUM7Q0FBRztBQUU1RSxrQkFBZSwwQkFBMEIsQ0FBQSJ9