"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceCategory = void 0;
const utils_1 = require("@medusajs/framework/utils");
/**
 * Módulo MasterService - Lista Mestra de Serviços
 *
 * Catálogo de serviços base que oficinas podem oferecer
 * Gerenciado pelo Admin
 */
var ServiceCategory;
(function (ServiceCategory) {
    ServiceCategory["MANUTENCAO_PREVENTIVA"] = "manutencao_preventiva";
    ServiceCategory["MANUTENCAO_CORRETIVA"] = "manutencao_corretiva";
    ServiceCategory["TROCA_OLEO"] = "troca_oleo";
    ServiceCategory["FREIOS"] = "freios";
    ServiceCategory["SUSPENSAO"] = "suspensao";
    ServiceCategory["MOTOR"] = "motor";
    ServiceCategory["ELETRICA"] = "eletrica";
    ServiceCategory["AR_CONDICIONADO"] = "ar_condicionado";
    ServiceCategory["ALINHAMENTO_BALANCEAMENTO"] = "alinhamento_balanceamento";
    ServiceCategory["OUTROS"] = "outros";
})(ServiceCategory || (exports.ServiceCategory = ServiceCategory = {}));
const MasterService = utils_1.model.define("master_service", {
    id: utils_1.model.id().primaryKey(),
    // Informações Básicas
    name: utils_1.model.text(),
    description: utils_1.model.text().nullable(),
    category: utils_1.model.enum(ServiceCategory),
    // Informações Técnicas
    estimated_duration_minutes: utils_1.model.number().nullable(), // Duração estimada
    icon_url: utils_1.model.text().nullable(),
    image_url: utils_1.model.text().nullable(),
    // Preço Sugerido (orientação para oficinas)
    suggested_price_min: utils_1.model.number().nullable(),
    suggested_price_max: utils_1.model.number().nullable(),
    // Controle
    is_active: utils_1.model.boolean().default(true),
    display_order: utils_1.model.number().default(0),
});
exports.default = MasterService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFzdGVyLXNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9tYXN0ZXJfc2VydmljZS9tb2RlbHMvbWFzdGVyLXNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBQWlEO0FBRWpEOzs7OztHQUtHO0FBRUgsSUFBWSxlQVdYO0FBWEQsV0FBWSxlQUFlO0lBQ3pCLGtFQUErQyxDQUFBO0lBQy9DLGdFQUE2QyxDQUFBO0lBQzdDLDRDQUF5QixDQUFBO0lBQ3pCLG9DQUFpQixDQUFBO0lBQ2pCLDBDQUF1QixDQUFBO0lBQ3ZCLGtDQUFlLENBQUE7SUFDZix3Q0FBcUIsQ0FBQTtJQUNyQixzREFBbUMsQ0FBQTtJQUNuQywwRUFBdUQsQ0FBQTtJQUN2RCxvQ0FBaUIsQ0FBQTtBQUNuQixDQUFDLEVBWFcsZUFBZSwrQkFBZixlQUFlLFFBVzFCO0FBRUQsTUFBTSxhQUFhLEdBQUcsYUFBSyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRTtJQUNuRCxFQUFFLEVBQUUsYUFBSyxDQUFDLEVBQUUsRUFBRSxDQUFDLFVBQVUsRUFBRTtJQUUzQixzQkFBc0I7SUFDdEIsSUFBSSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUU7SUFDbEIsV0FBVyxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDcEMsUUFBUSxFQUFFLGFBQUssQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDO0lBRXJDLHVCQUF1QjtJQUN2QiwwQkFBMEIsRUFBRSxhQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsUUFBUSxFQUFFLEVBQUUsbUJBQW1CO0lBQzFFLFFBQVEsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQ2pDLFNBQVMsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBRWxDLDRDQUE0QztJQUM1QyxtQkFBbUIsRUFBRSxhQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQzlDLG1CQUFtQixFQUFFLGFBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFFOUMsV0FBVztJQUNYLFNBQVMsRUFBRSxhQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQztJQUN4QyxhQUFhLEVBQUUsYUFBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7Q0FDekMsQ0FBQyxDQUFBO0FBRUYsa0JBQWUsYUFBYSxDQUFBIn0=