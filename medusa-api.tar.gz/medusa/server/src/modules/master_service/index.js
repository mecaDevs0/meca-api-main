"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MASTER_SERVICE_MODULE = void 0;
const service_1 = __importDefault(require("./service"));
const utils_1 = require("@medusajs/framework/utils");
exports.MASTER_SERVICE_MODULE = "master_service";
exports.default = (0, utils_1.Module)(exports.MASTER_SERVICE_MODULE, {
    service: service_1.default,
});
__exportStar(require("./models/master-service"), exports);
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9tYXN0ZXJfc2VydmljZS9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLHdEQUFrRDtBQUNsRCxxREFBa0Q7QUFFckMsUUFBQSxxQkFBcUIsR0FBRyxnQkFBZ0IsQ0FBQTtBQUVyRCxrQkFBZSxJQUFBLGNBQU0sRUFBQyw2QkFBcUIsRUFBRTtJQUMzQyxPQUFPLEVBQUUsaUJBQTBCO0NBQ3BDLENBQUMsQ0FBQTtBQUVGLDBEQUF1QyJ9