"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Migration20251016174844 = void 0;
const migrations_1 = require("@mikro-orm/migrations");
class Migration20251016174844 extends migrations_1.Migration {
    async up() {
        this.addSql(`create table if not exists "master_service" ("id" text not null, "name" text not null, "description" text null, "category" text check ("category" in ('manutencao_preventiva', 'manutencao_corretiva', 'troca_oleo', 'freios', 'suspensao', 'motor', 'eletrica', 'ar_condicionado', 'alinhamento_balanceamento', 'outros')) not null, "estimated_duration_minutes" integer null, "icon_url" text null, "image_url" text null, "suggested_price_min" integer null, "suggested_price_max" integer null, "is_active" boolean not null default true, "display_order" integer not null default 0, "created_at" timestamptz not null default now(), "updated_at" timestamptz not null default now(), "deleted_at" timestamptz null, constraint "master_service_pkey" primary key ("id"));`);
        this.addSql(`CREATE INDEX IF NOT EXISTS "IDX_master_service_deleted_at" ON "master_service" (deleted_at) WHERE deleted_at IS NULL;`);
    }
    async down() {
        this.addSql(`drop table if exists "master_service" cascade;`);
    }
}
exports.Migration20251016174844 = Migration20251016174844;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTWlncmF0aW9uMjAyNTEwMTYxNzQ4NDQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9tYXN0ZXJfc2VydmljZS9taWdyYXRpb25zL01pZ3JhdGlvbjIwMjUxMDE2MTc0ODQ0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHNEQUFrRDtBQUVsRCxNQUFhLHVCQUF3QixTQUFRLHNCQUFTO0lBRTNDLEtBQUssQ0FBQyxFQUFFO1FBQ2YsSUFBSSxDQUFDLE1BQU0sQ0FBQyxxdkJBQXF2QixDQUFDLENBQUM7UUFDbndCLElBQUksQ0FBQyxNQUFNLENBQUMsdUhBQXVILENBQUMsQ0FBQztJQUN2SSxDQUFDO0lBRVEsS0FBSyxDQUFDLElBQUk7UUFDakIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxnREFBZ0QsQ0FBQyxDQUFDO0lBQ2hFLENBQUM7Q0FFRjtBQVhELDBEQVdDIn0=