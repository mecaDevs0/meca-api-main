"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const booking_1 = require("../../../../../modules/booking");
const oficina_1 = require("../../../../../modules/oficina");
/**
 * GET /store/workshops/me/bookings
 *
 * Lista todos os agendamentos recebidos pela oficina autenticada
 */
async function GET(req, res) {
    const bookingModuleService = req.scope.resolve(booking_1.BOOKING_MODULE);
    const oficinaModuleService = req.scope.resolve(oficina_1.OFICINA_MODULE);
    const userId = req.auth_context?.actor_id;
    if (!userId) {
        return res.status(401).json({ message: "Não autenticado" });
    }
    try {
        // Buscar oficina do usuário
        const oficinas = await oficinaModuleService.listOficinas({}, { take: 1 });
        if (!oficinas || oficinas.length === 0) {
            return res.status(404).json({
                message: "Oficina não encontrada"
            });
        }
        const oficinaId = oficinas[0].id;
        // Buscar agendamentos da oficina
        const { status, limit = 50, offset = 0 } = req.query;
        const filters = {
            oficina_id: oficinaId
        };
        if (status) {
            filters.status = status;
        }
        const bookings = await bookingModuleService.listBookings(filters, {
            take: Number(limit),
            skip: Number(offset),
            order: { appointment_date: "ASC" }
        });
        return res.json({
            bookings,
            count: bookings.length,
        });
    }
    catch (error) {
        console.error("Erro ao listar agendamentos:", error);
        return res.status(500).json({
            message: "Erro ao listar agendamentos",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3dvcmtzaG9wcy9tZS9ib29raW5ncy9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQVNBLGtCQXVEQztBQS9ERCw0REFBK0Q7QUFDL0QsNERBQStEO0FBRS9EOzs7O0dBSUc7QUFDSSxLQUFLLFVBQVUsR0FBRyxDQUN2QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixNQUFNLG9CQUFvQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHdCQUFjLENBQUMsQ0FBQTtJQUM5RCxNQUFNLG9CQUFvQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHdCQUFjLENBQUMsQ0FBQTtJQUU5RCxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsWUFBWSxFQUFFLFFBQVEsQ0FBQTtJQUV6QyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDWixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLGlCQUFpQixFQUFFLENBQUMsQ0FBQTtJQUM3RCxDQUFDO0lBRUQsSUFBSSxDQUFDO1FBQ0gsNEJBQTRCO1FBQzVCLE1BQU0sUUFBUSxHQUFHLE1BQU0sb0JBQW9CLENBQUMsWUFBWSxDQUFDLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFBO1FBRXpFLElBQUksQ0FBQyxRQUFRLElBQUksUUFBUSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUN2QyxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUMxQixPQUFPLEVBQUUsd0JBQXdCO2FBQ2xDLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFFRCxNQUFNLFNBQVMsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFBO1FBRWhDLGlDQUFpQztRQUNqQyxNQUFNLEVBQUUsTUFBTSxFQUFFLEtBQUssR0FBRyxFQUFFLEVBQUUsTUFBTSxHQUFHLENBQUMsRUFBRSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUE7UUFFcEQsTUFBTSxPQUFPLEdBQVE7WUFDbkIsVUFBVSxFQUFFLFNBQVM7U0FDdEIsQ0FBQTtRQUVELElBQUksTUFBTSxFQUFFLENBQUM7WUFDWCxPQUFPLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQTtRQUN6QixDQUFDO1FBRUQsTUFBTSxRQUFRLEdBQUcsTUFBTSxvQkFBb0IsQ0FBQyxZQUFZLENBQUMsT0FBTyxFQUFFO1lBQ2hFLElBQUksRUFBRSxNQUFNLENBQUMsS0FBSyxDQUFDO1lBQ25CLElBQUksRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDO1lBQ3BCLEtBQUssRUFBRSxFQUFFLGdCQUFnQixFQUFFLEtBQUssRUFBRTtTQUNuQyxDQUFDLENBQUE7UUFFRixPQUFPLEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDZCxRQUFRO1lBQ1IsS0FBSyxFQUFFLFFBQVEsQ0FBQyxNQUFNO1NBQ3ZCLENBQUMsQ0FBQTtJQUVKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyw4QkFBOEIsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUVwRCxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSw2QkFBNkI7WUFDdEMsS0FBSyxFQUFFLEtBQUssQ0FBQyxPQUFPO1NBQ3JCLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=