"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.PUT = PUT;
const oficina_1 = require("../../../../modules/oficina");
/**
 * GET /store/workshops/me
 *
 * Retorna os dados da oficina do usuário autenticado
 */
async function GET(req, res) {
    const oficinaModuleService = req.scope.resolve(oficina_1.OFICINA_MODULE);
    const userId = req.auth_context?.actor_id;
    if (!userId) {
        return res.status(401).json({ message: "Não autenticado" });
    }
    // Por enquanto, buscaremos pela primeira oficina
    // Quando os links estiverem funcionando, usaremos o link user->oficina
    const oficinas = await oficinaModuleService.listOficinas({}, { take: 1 });
    if (!oficinas || oficinas.length === 0) {
        return res.status(404).json({
            message: "Oficina não encontrada para este usuário"
        });
    }
    return res.json({ oficina: oficinas[0] });
}
/**
 * PUT /store/workshops/me
 *
 * Atualiza os dados da oficina do usuário autenticado
 */
async function PUT(req, res) {
    const oficinaModuleService = req.scope.resolve(oficina_1.OFICINA_MODULE);
    const userId = req.auth_context?.actor_id;
    if (!userId) {
        return res.status(401).json({ message: "Não autenticado" });
    }
    const { name, phone, address, description, logo_url, photo_urls, dados_bancarios, horario_funcionamento } = req.body;
    try {
        // Buscar oficina do usuário
        const oficinas = await oficinaModuleService.listOficinas({}, { take: 1 });
        if (!oficinas || oficinas.length === 0) {
            return res.status(404).json({
                message: "Oficina não encontrada"
            });
        }
        const oficinaId = oficinas[0].id;
        // Atualizar oficina
        const updatedOficina = await oficinaModuleService.updateOficinas(oficinaId, {
            name,
            phone,
            address,
            description,
            logo_url,
            photo_urls,
            dados_bancarios,
            horario_funcionamento,
        });
        return res.json({
            message: "Oficina atualizada com sucesso",
            oficina: updatedOficina
        });
    }
    catch (error) {
        console.error("Erro ao atualizar oficina:", error);
        return res.status(500).json({
            message: "Erro ao atualizar oficina",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3dvcmtzaG9wcy9tZS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQVFBLGtCQXVCQztBQU9ELGtCQTREQztBQWpHRCx5REFBNEQ7QUFFNUQ7Ozs7R0FJRztBQUNJLEtBQUssVUFBVSxHQUFHLENBQ3ZCLEdBQWtCLEVBQ2xCLEdBQW1CO0lBRW5CLE1BQU0sb0JBQW9CLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsd0JBQWMsQ0FBQyxDQUFBO0lBRTlELE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxZQUFZLEVBQUUsUUFBUSxDQUFBO0lBRXpDLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNaLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsQ0FBQyxDQUFBO0lBQzdELENBQUM7SUFFRCxpREFBaUQ7SUFDakQsdUVBQXVFO0lBQ3ZFLE1BQU0sUUFBUSxHQUFHLE1BQU0sb0JBQW9CLENBQUMsWUFBWSxDQUFDLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0lBRXpFLElBQUksQ0FBQyxRQUFRLElBQUksUUFBUSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztRQUN2QyxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSwwQ0FBMEM7U0FDcEQsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVELE9BQU8sR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFBO0FBQzNDLENBQUM7QUFFRDs7OztHQUlHO0FBQ0ksS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsTUFBTSxvQkFBb0IsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyx3QkFBYyxDQUFDLENBQUE7SUFFOUQsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFlBQVksRUFBRSxRQUFRLENBQUE7SUFFekMsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ1osT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxDQUFDLENBQUE7SUFDN0QsQ0FBQztJQUVELE1BQU0sRUFDSixJQUFJLEVBQ0osS0FBSyxFQUNMLE9BQU8sRUFDUCxXQUFXLEVBQ1gsUUFBUSxFQUNSLFVBQVUsRUFDVixlQUFlLEVBQ2YscUJBQXFCLEVBQ3RCLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQTtJQUVaLElBQUksQ0FBQztRQUNILDRCQUE0QjtRQUM1QixNQUFNLFFBQVEsR0FBRyxNQUFNLG9CQUFvQixDQUFDLFlBQVksQ0FBQyxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQTtRQUV6RSxJQUFJLENBQUMsUUFBUSxJQUFJLFFBQVEsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7WUFDdkMsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDMUIsT0FBTyxFQUFFLHdCQUF3QjthQUNsQyxDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQsTUFBTSxTQUFTLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQTtRQUVoQyxvQkFBb0I7UUFDcEIsTUFBTSxjQUFjLEdBQUcsTUFBTSxvQkFBb0IsQ0FBQyxjQUFjLENBQUMsU0FBUyxFQUFFO1lBQzFFLElBQUk7WUFDSixLQUFLO1lBQ0wsT0FBTztZQUNQLFdBQVc7WUFDWCxRQUFRO1lBQ1IsVUFBVTtZQUNWLGVBQWU7WUFDZixxQkFBcUI7U0FDdEIsQ0FBQyxDQUFBO1FBRUYsT0FBTyxHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ2QsT0FBTyxFQUFFLGdDQUFnQztZQUN6QyxPQUFPLEVBQUUsY0FBYztTQUN4QixDQUFDLENBQUE7SUFFSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsNEJBQTRCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFFbEQsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsMkJBQTJCO1lBQ3BDLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTztTQUNyQixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9