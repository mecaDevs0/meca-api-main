"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const booking_1 = require("../../../../../../../modules/booking");
const oficina_1 = require("../../../../../../../modules/oficina");
const booking_2 = require("../../../../../../../modules/booking/models/booking");
/**
 * POST /store/workshops/me/bookings/:id/confirm
 *
 * Confirma um agendamento recebido pela oficina
 */
async function POST(req, res) {
    const bookingModuleService = req.scope.resolve(booking_1.BOOKING_MODULE);
    const oficinaModuleService = req.scope.resolve(oficina_1.OFICINA_MODULE);
    const eventBusService = req.scope.resolve("eventBus");
    const userId = req.auth_context?.actor_id;
    const { id: bookingId } = req.params;
    if (!userId) {
        return res.status(401).json({ message: "Não autenticado" });
    }
    try {
        // Buscar oficina do usuário
        const oficinas = await oficinaModuleService.listOficinas({}, { take: 1 });
        if (!oficinas || oficinas.length === 0) {
            return res.status(404).json({ message: "Oficina não encontrada" });
        }
        const oficinaId = oficinas[0].id;
        // Buscar agendamento
        const booking = await bookingModuleService.retrieveBooking(bookingId);
        // Verificar se o agendamento pertence a esta oficina
        if (booking.oficina_id !== oficinaId) {
            return res.status(403).json({ message: "Acesso negado" });
        }
        // Verificar se o status permite confirmação
        if (booking.status !== booking_2.BookingStatus.PENDENTE_OFICINA) {
            return res.status(400).json({
                message: "Este agendamento não pode ser confirmado. Status atual: " + booking.status
            });
        }
        // Atualizar status para confirmado
        const updatedBooking = await bookingModuleService.updateBookings(bookingId, {
            status: booking_2.BookingStatus.CONFIRMADO,
            confirmed_at: new Date(),
        });
        // Emitir evento para notificar o cliente
        await eventBusService.emit("booking.confirmed", {
            booking_id: bookingId,
            customer_id: booking.customer_id,
            oficina_id: oficinaId,
        });
        return res.json({
            message: "Agendamento confirmado com sucesso",
            booking: updatedBooking
        });
    }
    catch (error) {
        console.error("Erro ao confirmar agendamento:", error);
        return res.status(500).json({
            message: "Erro ao confirmar agendamento",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3dvcmtzaG9wcy9tZS9ib29raW5ncy9baWRdL2NvbmZpcm0vcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFVQSxvQkFrRUM7QUEzRUQsa0VBQXFFO0FBQ3JFLGtFQUFxRTtBQUNyRSxpRkFBbUY7QUFFbkY7Ozs7R0FJRztBQUNJLEtBQUssVUFBVSxJQUFJLENBQ3hCLEdBQWtCLEVBQ2xCLEdBQW1CO0lBRW5CLE1BQU0sb0JBQW9CLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsd0JBQWMsQ0FBQyxDQUFBO0lBQzlELE1BQU0sb0JBQW9CLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsd0JBQWMsQ0FBQyxDQUFBO0lBQzlELE1BQU0sZUFBZSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFBO0lBRXJELE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxZQUFZLEVBQUUsUUFBUSxDQUFBO0lBQ3pDLE1BQU0sRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQTtJQUVwQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDWixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLGlCQUFpQixFQUFFLENBQUMsQ0FBQTtJQUM3RCxDQUFDO0lBRUQsSUFBSSxDQUFDO1FBQ0gsNEJBQTRCO1FBQzVCLE1BQU0sUUFBUSxHQUFHLE1BQU0sb0JBQW9CLENBQUMsWUFBWSxDQUFDLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFBO1FBRXpFLElBQUksQ0FBQyxRQUFRLElBQUksUUFBUSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUN2QyxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLHdCQUF3QixFQUFFLENBQUMsQ0FBQTtRQUNwRSxDQUFDO1FBRUQsTUFBTSxTQUFTLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQTtRQUVoQyxxQkFBcUI7UUFDckIsTUFBTSxPQUFPLEdBQUcsTUFBTSxvQkFBb0IsQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLENBQUE7UUFFckUscURBQXFEO1FBQ3JELElBQUksT0FBTyxDQUFDLFVBQVUsS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUNyQyxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLGVBQWUsRUFBRSxDQUFDLENBQUE7UUFDM0QsQ0FBQztRQUVELDRDQUE0QztRQUM1QyxJQUFJLE9BQU8sQ0FBQyxNQUFNLEtBQUssdUJBQWEsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBQ3RELE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQzFCLE9BQU8sRUFBRSwwREFBMEQsR0FBRyxPQUFPLENBQUMsTUFBTTthQUNyRixDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQsbUNBQW1DO1FBQ25DLE1BQU0sY0FBYyxHQUFHLE1BQU0sb0JBQW9CLENBQUMsY0FBYyxDQUFDLFNBQVMsRUFBRTtZQUMxRSxNQUFNLEVBQUUsdUJBQWEsQ0FBQyxVQUFVO1lBQ2hDLFlBQVksRUFBRSxJQUFJLElBQUksRUFBRTtTQUN6QixDQUFDLENBQUE7UUFFRix5Q0FBeUM7UUFDekMsTUFBTSxlQUFlLENBQUMsSUFBSSxDQUFDLG1CQUFtQixFQUFFO1lBQzlDLFVBQVUsRUFBRSxTQUFTO1lBQ3JCLFdBQVcsRUFBRSxPQUFPLENBQUMsV0FBVztZQUNoQyxVQUFVLEVBQUUsU0FBUztTQUN0QixDQUFDLENBQUE7UUFFRixPQUFPLEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDZCxPQUFPLEVBQUUsb0NBQW9DO1lBQzdDLE9BQU8sRUFBRSxjQUFjO1NBQ3hCLENBQUMsQ0FBQTtJQUVKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyxnQ0FBZ0MsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUV0RCxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSwrQkFBK0I7WUFDeEMsS0FBSyxFQUFFLEtBQUssQ0FBQyxPQUFPO1NBQ3JCLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=