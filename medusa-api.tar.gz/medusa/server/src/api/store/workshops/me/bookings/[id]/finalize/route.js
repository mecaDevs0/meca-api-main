"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const booking_1 = require("../../../../../../../modules/booking");
const oficina_1 = require("../../../../../../../modules/oficina");
const booking_2 = require("../../../../../../../modules/booking/models/booking");
/**
 * POST /store/workshops/me/bookings/:id/finalize
 *
 * Marca um agendamento como finalizado pelo mecânico
 * Notifica o cliente para confirmar e realizar o pagamento
 */
async function POST(req, res) {
    const bookingModuleService = req.scope.resolve(booking_1.BOOKING_MODULE);
    const oficinaModuleService = req.scope.resolve(oficina_1.OFICINA_MODULE);
    const eventBusService = req.scope.resolve("eventBus");
    const userId = req.auth_context?.actor_id;
    const { id: bookingId } = req.params;
    const { final_price, oficina_notes } = req.body;
    if (!userId) {
        return res.status(401).json({ message: "Não autenticado" });
    }
    try {
        // Buscar oficina do usuário
        const oficinas = await oficinaModuleService.listOficinas({}, { take: 1 });
        if (!oficinas || oficinas.length === 0) {
            return res.status(404).json({ message: "Oficina não encontrada" });
        }
        const oficinaId = oficinas[0].id;
        // Buscar agendamento
        const booking = await bookingModuleService.retrieveBooking(bookingId);
        // Verificar se o agendamento pertence a esta oficina
        if (booking.oficina_id !== oficinaId) {
            return res.status(403).json({ message: "Acesso negado" });
        }
        // Verificar se o status permite finalização
        if (booking.status !== booking_2.BookingStatus.CONFIRMADO) {
            return res.status(400).json({
                message: "Apenas agendamentos confirmados podem ser finalizados. Status atual: " + booking.status
            });
        }
        // Atualizar status para finalizado pelo mecânico
        const updatedBooking = await bookingModuleService.updateBookings(bookingId, {
            status: booking_2.BookingStatus.FINALIZADO_MECANICO,
            final_price: final_price || booking.estimated_price,
            oficina_notes,
            completed_at: new Date(),
        });
        // Emitir evento para notificar o cliente para confirmar e pagar
        await eventBusService.emit("booking.finalized_by_workshop", {
            booking_id: bookingId,
            customer_id: booking.customer_id,
            oficina_id: oficinaId,
            final_price: final_price || booking.estimated_price,
        });
        return res.json({
            message: "Serviço finalizado com sucesso. Aguardando confirmação e pagamento do cliente.",
            booking: updatedBooking
        });
    }
    catch (error) {
        console.error("Erro ao finalizar agendamento:", error);
        return res.status(500).json({
            message: "Erro ao finalizar agendamento",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3dvcmtzaG9wcy9tZS9ib29raW5ncy9baWRdL2ZpbmFsaXplL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBV0Esb0JBc0VDO0FBaEZELGtFQUFxRTtBQUNyRSxrRUFBcUU7QUFDckUsaUZBQW1GO0FBRW5GOzs7OztHQUtHO0FBQ0ksS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsTUFBTSxvQkFBb0IsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyx3QkFBYyxDQUFDLENBQUE7SUFDOUQsTUFBTSxvQkFBb0IsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyx3QkFBYyxDQUFDLENBQUE7SUFDOUQsTUFBTSxlQUFlLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUE7SUFFckQsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFlBQVksRUFBRSxRQUFRLENBQUE7SUFDekMsTUFBTSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFBO0lBQ3BDLE1BQU0sRUFBRSxXQUFXLEVBQUUsYUFBYSxFQUFFLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQTtJQUUvQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDWixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLGlCQUFpQixFQUFFLENBQUMsQ0FBQTtJQUM3RCxDQUFDO0lBRUQsSUFBSSxDQUFDO1FBQ0gsNEJBQTRCO1FBQzVCLE1BQU0sUUFBUSxHQUFHLE1BQU0sb0JBQW9CLENBQUMsWUFBWSxDQUFDLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFBO1FBRXpFLElBQUksQ0FBQyxRQUFRLElBQUksUUFBUSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUN2QyxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLHdCQUF3QixFQUFFLENBQUMsQ0FBQTtRQUNwRSxDQUFDO1FBRUQsTUFBTSxTQUFTLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQTtRQUVoQyxxQkFBcUI7UUFDckIsTUFBTSxPQUFPLEdBQUcsTUFBTSxvQkFBb0IsQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLENBQUE7UUFFckUscURBQXFEO1FBQ3JELElBQUksT0FBTyxDQUFDLFVBQVUsS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUNyQyxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLGVBQWUsRUFBRSxDQUFDLENBQUE7UUFDM0QsQ0FBQztRQUVELDRDQUE0QztRQUM1QyxJQUFJLE9BQU8sQ0FBQyxNQUFNLEtBQUssdUJBQWEsQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNoRCxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUMxQixPQUFPLEVBQUUsdUVBQXVFLEdBQUcsT0FBTyxDQUFDLE1BQU07YUFDbEcsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUVELGlEQUFpRDtRQUNqRCxNQUFNLGNBQWMsR0FBRyxNQUFNLG9CQUFvQixDQUFDLGNBQWMsQ0FBQyxTQUFTLEVBQUU7WUFDMUUsTUFBTSxFQUFFLHVCQUFhLENBQUMsbUJBQW1CO1lBQ3pDLFdBQVcsRUFBRSxXQUFXLElBQUksT0FBTyxDQUFDLGVBQWU7WUFDbkQsYUFBYTtZQUNiLFlBQVksRUFBRSxJQUFJLElBQUksRUFBRTtTQUN6QixDQUFDLENBQUE7UUFFRixnRUFBZ0U7UUFDaEUsTUFBTSxlQUFlLENBQUMsSUFBSSxDQUFDLCtCQUErQixFQUFFO1lBQzFELFVBQVUsRUFBRSxTQUFTO1lBQ3JCLFdBQVcsRUFBRSxPQUFPLENBQUMsV0FBVztZQUNoQyxVQUFVLEVBQUUsU0FBUztZQUNyQixXQUFXLEVBQUUsV0FBVyxJQUFJLE9BQU8sQ0FBQyxlQUFlO1NBQ3BELENBQUMsQ0FBQTtRQUVGLE9BQU8sR0FBRyxDQUFDLElBQUksQ0FBQztZQUNkLE9BQU8sRUFBRSxnRkFBZ0Y7WUFDekYsT0FBTyxFQUFFLGNBQWM7U0FDeEIsQ0FBQyxDQUFBO0lBRUosQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLGdDQUFnQyxFQUFFLEtBQUssQ0FBQyxDQUFBO1FBRXRELE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLCtCQUErQjtZQUN4QyxLQUFLLEVBQUUsS0FBSyxDQUFDLE9BQU87U0FDckIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUMifQ==