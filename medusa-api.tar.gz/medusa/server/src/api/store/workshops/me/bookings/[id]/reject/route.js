"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const booking_1 = require("../../../../../../../modules/booking");
const oficina_1 = require("../../../../../../../modules/oficina");
const booking_2 = require("../../../../../../../modules/booking/models/booking");
/**
 * POST /store/workshops/me/bookings/:id/reject
 *
 * Rejeita um agendamento recebido pela oficina
 */
async function POST(req, res) {
    const bookingModuleService = req.scope.resolve(booking_1.BOOKING_MODULE);
    const oficinaModuleService = req.scope.resolve(oficina_1.OFICINA_MODULE);
    const eventBusService = req.scope.resolve("eventBus");
    const userId = req.auth_context?.actor_id;
    const { id: bookingId } = req.params;
    const { reason } = req.body;
    if (!userId) {
        return res.status(401).json({ message: "Não autenticado" });
    }
    try {
        // Buscar oficina do usuário
        const oficinas = await oficinaModuleService.listOficinas({}, { take: 1 });
        if (!oficinas || oficinas.length === 0) {
            return res.status(404).json({ message: "Oficina não encontrada" });
        }
        const oficinaId = oficinas[0].id;
        // Buscar agendamento
        const booking = await bookingModuleService.retrieveBooking(bookingId);
        // Verificar se o agendamento pertence a esta oficina
        if (booking.oficina_id !== oficinaId) {
            return res.status(403).json({ message: "Acesso negado" });
        }
        // Atualizar status para recusado
        const updatedBooking = await bookingModuleService.updateBookings(bookingId, {
            status: booking_2.BookingStatus.RECUSADO,
            oficina_notes: reason || "Agendamento recusado pela oficina",
        });
        // Emitir evento para notificar o cliente
        await eventBusService.emit("booking.rejected", {
            booking_id: bookingId,
            customer_id: booking.customer_id,
            oficina_id: oficinaId,
            reason: reason || "Agendamento recusado pela oficina",
        });
        return res.json({
            message: "Agendamento recusado",
            booking: updatedBooking
        });
    }
    catch (error) {
        console.error("Erro ao rejeitar agendamento:", error);
        return res.status(500).json({
            message: "Erro ao rejeitar agendamento",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3dvcmtzaG9wcy9tZS9ib29raW5ncy9baWRdL3JlamVjdC9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQVVBLG9CQTZEQztBQXRFRCxrRUFBcUU7QUFDckUsa0VBQXFFO0FBQ3JFLGlGQUFtRjtBQUVuRjs7OztHQUlHO0FBQ0ksS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsTUFBTSxvQkFBb0IsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyx3QkFBYyxDQUFDLENBQUE7SUFDOUQsTUFBTSxvQkFBb0IsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyx3QkFBYyxDQUFDLENBQUE7SUFDOUQsTUFBTSxlQUFlLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUE7SUFFckQsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFlBQVksRUFBRSxRQUFRLENBQUE7SUFDekMsTUFBTSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFBO0lBQ3BDLE1BQU0sRUFBRSxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFBO0lBRTNCLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNaLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsQ0FBQyxDQUFBO0lBQzdELENBQUM7SUFFRCxJQUFJLENBQUM7UUFDSCw0QkFBNEI7UUFDNUIsTUFBTSxRQUFRLEdBQUcsTUFBTSxvQkFBb0IsQ0FBQyxZQUFZLENBQUMsRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUE7UUFFekUsSUFBSSxDQUFDLFFBQVEsSUFBSSxRQUFRLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQ3ZDLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUsd0JBQXdCLEVBQUUsQ0FBQyxDQUFBO1FBQ3BFLENBQUM7UUFFRCxNQUFNLFNBQVMsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFBO1FBRWhDLHFCQUFxQjtRQUNyQixNQUFNLE9BQU8sR0FBRyxNQUFNLG9CQUFvQixDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUMsQ0FBQTtRQUVyRSxxREFBcUQ7UUFDckQsSUFBSSxPQUFPLENBQUMsVUFBVSxLQUFLLFNBQVMsRUFBRSxDQUFDO1lBQ3JDLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUsZUFBZSxFQUFFLENBQUMsQ0FBQTtRQUMzRCxDQUFDO1FBRUQsaUNBQWlDO1FBQ2pDLE1BQU0sY0FBYyxHQUFHLE1BQU0sb0JBQW9CLENBQUMsY0FBYyxDQUFDLFNBQVMsRUFBRTtZQUMxRSxNQUFNLEVBQUUsdUJBQWEsQ0FBQyxRQUFRO1lBQzlCLGFBQWEsRUFBRSxNQUFNLElBQUksbUNBQW1DO1NBQzdELENBQUMsQ0FBQTtRQUVGLHlDQUF5QztRQUN6QyxNQUFNLGVBQWUsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUU7WUFDN0MsVUFBVSxFQUFFLFNBQVM7WUFDckIsV0FBVyxFQUFFLE9BQU8sQ0FBQyxXQUFXO1lBQ2hDLFVBQVUsRUFBRSxTQUFTO1lBQ3JCLE1BQU0sRUFBRSxNQUFNLElBQUksbUNBQW1DO1NBQ3RELENBQUMsQ0FBQTtRQUVGLE9BQU8sR0FBRyxDQUFDLElBQUksQ0FBQztZQUNkLE9BQU8sRUFBRSxzQkFBc0I7WUFDL0IsT0FBTyxFQUFFLGNBQWM7U0FDeEIsQ0FBQyxDQUFBO0lBRUosQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLCtCQUErQixFQUFFLEtBQUssQ0FBQyxDQUFBO1FBRXJELE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLDhCQUE4QjtZQUN2QyxLQUFLLEVBQUUsS0FBSyxDQUFDLE9BQU87U0FDckIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUMifQ==