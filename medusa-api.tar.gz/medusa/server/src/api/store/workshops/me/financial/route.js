"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const utils_1 = require("@medusajs/framework/utils");
const oficina_1 = require("../../../../../modules/oficina");
const booking_1 = require("../../../../../modules/booking");
/**
 * GET /store/workshops/me/financial?start_date=&end_date=
 *
 * Histórico financeiro da oficina
 * Retorna todos os serviços pagos com valores e comissões
 */
async function GET(req, res) {
    const oficinaModuleService = req.scope.resolve(oficina_1.OFICINA_MODULE);
    const bookingModuleService = req.scope.resolve(booking_1.BOOKING_MODULE);
    const orderModuleService = req.scope.resolve(utils_1.Modules.ORDER);
    const userId = req.auth_context?.actor_id;
    if (!userId) {
        return res.status(401).json({ message: "Não autenticado" });
    }
    const { start_date, end_date } = req.query;
    try {
        // Buscar oficina do usuário
        const oficinas = await oficinaModuleService.listOficinas({}, { take: 1 });
        if (!oficinas || oficinas.length === 0) {
            return res.status(404).json({ message: "Oficina não encontrada" });
        }
        const oficinaId = oficinas[0].id;
        // Buscar bookings finalizados e pagos
        const filters = {
            oficina_id: oficinaId,
            status: "finalizado_cliente"
        };
        if (start_date) {
            filters.completed_at = { $gte: new Date(start_date) };
        }
        if (end_date) {
            filters.completed_at = {
                ...(filters.completed_at || {}),
                $lte: new Date(end_date)
            };
        }
        const bookings = await bookingModuleService.listBookings(filters, {
            order: { completed_at: "DESC" }
        });
        // Buscar orders associados e calcular totais
        const transactions = await Promise.all(bookings.map(async (booking) => {
            let order = null;
            let commission = 0;
            let netAmount = booking.final_price || booking.estimated_price || 0;
            if (booking.order_id) {
                try {
                    order = await orderModuleService.retrieveOrder(booking.order_id);
                    commission = order.metadata?.meca_commission_amount || 0;
                    netAmount = (booking.final_price || booking.estimated_price || 0) - commission;
                }
                catch (e) {
                    // Order não encontrado
                }
            }
            return {
                booking_id: booking.id,
                order_id: booking.order_id,
                appointment_date: booking.appointment_date,
                completed_at: booking.completed_at,
                gross_amount: booking.final_price || booking.estimated_price,
                commission_amount: commission,
                net_amount: netAmount,
                vehicle: booking.vehicle_snapshot,
                customer_notes: booking.customer_notes,
            };
        }));
        // Calcular totais
        const totalGross = transactions.reduce((sum, t) => sum + (t.gross_amount || 0), 0);
        const totalCommission = transactions.reduce((sum, t) => sum + t.commission_amount, 0);
        const totalNet = transactions.reduce((sum, t) => sum + t.net_amount, 0);
        return res.json({
            transactions,
            summary: {
                total_transactions: transactions.length,
                total_gross: totalGross,
                total_commission: totalCommission,
                total_net: totalNet,
                period: {
                    start: start_date || null,
                    end: end_date || null,
                }
            }
        });
    }
    catch (error) {
        console.error("Erro ao buscar histórico financeiro:", error);
        return res.status(500).json({
            message: "Erro ao buscar histórico financeiro",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3dvcmtzaG9wcy9tZS9maW5hbmNpYWwvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFXQSxrQkF5R0M7QUFuSEQscURBQW1EO0FBQ25ELDREQUErRDtBQUMvRCw0REFBK0Q7QUFFL0Q7Ozs7O0dBS0c7QUFDSSxLQUFLLFVBQVUsR0FBRyxDQUN2QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixNQUFNLG9CQUFvQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHdCQUFjLENBQUMsQ0FBQTtJQUM5RCxNQUFNLG9CQUFvQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHdCQUFjLENBQUMsQ0FBQTtJQUM5RCxNQUFNLGtCQUFrQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGVBQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUUzRCxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsWUFBWSxFQUFFLFFBQVEsQ0FBQTtJQUV6QyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDWixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLGlCQUFpQixFQUFFLENBQUMsQ0FBQTtJQUM3RCxDQUFDO0lBRUQsTUFBTSxFQUFFLFVBQVUsRUFBRSxRQUFRLEVBQUUsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFBO0lBRTFDLElBQUksQ0FBQztRQUNILDRCQUE0QjtRQUM1QixNQUFNLFFBQVEsR0FBRyxNQUFNLG9CQUFvQixDQUFDLFlBQVksQ0FBQyxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQTtRQUV6RSxJQUFJLENBQUMsUUFBUSxJQUFJLFFBQVEsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7WUFDdkMsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSx3QkFBd0IsRUFBRSxDQUFDLENBQUE7UUFDcEUsQ0FBQztRQUVELE1BQU0sU0FBUyxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUE7UUFFaEMsc0NBQXNDO1FBQ3RDLE1BQU0sT0FBTyxHQUFRO1lBQ25CLFVBQVUsRUFBRSxTQUFTO1lBQ3JCLE1BQU0sRUFBRSxvQkFBb0I7U0FDN0IsQ0FBQTtRQUVELElBQUksVUFBVSxFQUFFLENBQUM7WUFDZixPQUFPLENBQUMsWUFBWSxHQUFHLEVBQUUsSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQW9CLENBQUMsRUFBRSxDQUFBO1FBQ2pFLENBQUM7UUFFRCxJQUFJLFFBQVEsRUFBRSxDQUFDO1lBQ2IsT0FBTyxDQUFDLFlBQVksR0FBRztnQkFDckIsR0FBRyxDQUFDLE9BQU8sQ0FBQyxZQUFZLElBQUksRUFBRSxDQUFDO2dCQUMvQixJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsUUFBa0IsQ0FBQzthQUNuQyxDQUFBO1FBQ0gsQ0FBQztRQUVELE1BQU0sUUFBUSxHQUFHLE1BQU0sb0JBQW9CLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRTtZQUNoRSxLQUFLLEVBQUUsRUFBRSxZQUFZLEVBQUUsTUFBTSxFQUFFO1NBQ2hDLENBQUMsQ0FBQTtRQUVGLDZDQUE2QztRQUM3QyxNQUFNLFlBQVksR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQ3BDLFFBQVEsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxFQUFFO1lBQzdCLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQTtZQUNoQixJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUE7WUFDbEIsSUFBSSxTQUFTLEdBQUcsT0FBTyxDQUFDLFdBQVcsSUFBSSxPQUFPLENBQUMsZUFBZSxJQUFJLENBQUMsQ0FBQTtZQUVuRSxJQUFJLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQztnQkFDckIsSUFBSSxDQUFDO29CQUNILEtBQUssR0FBRyxNQUFNLGtCQUFrQixDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUE7b0JBQ2hFLFVBQVUsR0FBRyxLQUFLLENBQUMsUUFBUSxFQUFFLHNCQUFzQixJQUFJLENBQUMsQ0FBQTtvQkFDeEQsU0FBUyxHQUFHLENBQUMsT0FBTyxDQUFDLFdBQVcsSUFBSSxPQUFPLENBQUMsZUFBZSxJQUFJLENBQUMsQ0FBQyxHQUFHLFVBQVUsQ0FBQTtnQkFDaEYsQ0FBQztnQkFBQyxPQUFPLENBQUMsRUFBRSxDQUFDO29CQUNYLHVCQUF1QjtnQkFDekIsQ0FBQztZQUNILENBQUM7WUFFRCxPQUFPO2dCQUNMLFVBQVUsRUFBRSxPQUFPLENBQUMsRUFBRTtnQkFDdEIsUUFBUSxFQUFFLE9BQU8sQ0FBQyxRQUFRO2dCQUMxQixnQkFBZ0IsRUFBRSxPQUFPLENBQUMsZ0JBQWdCO2dCQUMxQyxZQUFZLEVBQUUsT0FBTyxDQUFDLFlBQVk7Z0JBQ2xDLFlBQVksRUFBRSxPQUFPLENBQUMsV0FBVyxJQUFJLE9BQU8sQ0FBQyxlQUFlO2dCQUM1RCxpQkFBaUIsRUFBRSxVQUFVO2dCQUM3QixVQUFVLEVBQUUsU0FBUztnQkFDckIsT0FBTyxFQUFFLE9BQU8sQ0FBQyxnQkFBZ0I7Z0JBQ2pDLGNBQWMsRUFBRSxPQUFPLENBQUMsY0FBYzthQUN2QyxDQUFBO1FBQ0gsQ0FBQyxDQUFDLENBQ0gsQ0FBQTtRQUVELGtCQUFrQjtRQUNsQixNQUFNLFVBQVUsR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLFlBQVksSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQTtRQUNsRixNQUFNLGVBQWUsR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLENBQUMsQ0FBQTtRQUNyRixNQUFNLFFBQVEsR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUE7UUFFdkUsT0FBTyxHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ2QsWUFBWTtZQUNaLE9BQU8sRUFBRTtnQkFDUCxrQkFBa0IsRUFBRSxZQUFZLENBQUMsTUFBTTtnQkFDdkMsV0FBVyxFQUFFLFVBQVU7Z0JBQ3ZCLGdCQUFnQixFQUFFLGVBQWU7Z0JBQ2pDLFNBQVMsRUFBRSxRQUFRO2dCQUNuQixNQUFNLEVBQUU7b0JBQ04sS0FBSyxFQUFFLFVBQVUsSUFBSSxJQUFJO29CQUN6QixHQUFHLEVBQUUsUUFBUSxJQUFJLElBQUk7aUJBQ3RCO2FBQ0Y7U0FDRixDQUFDLENBQUE7SUFFSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsc0NBQXNDLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFFNUQsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUscUNBQXFDO1lBQzlDLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTztTQUNyQixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9