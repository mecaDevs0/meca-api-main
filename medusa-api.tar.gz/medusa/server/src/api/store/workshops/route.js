"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AUTHENTICATE = void 0;
exports.GET = GET;
exports.POST = POST;
const oficina_1 = require("../../../modules/oficina");
exports.AUTHENTICATE = false;
/**
 * GET /store/workshops
 *
 * Lista oficinas aprovadas para clientes
 */
async function GET(req, res) {
    const oficinaModuleService = req.scope.resolve(oficina_1.OFICINA_MODULE);
    const { limit = 50, offset = 0, q } = req.query;
    const filters = {
        status: "aprovado" // Apenas oficinas aprovadas
    };
    if (q) {
        filters.$or = [
            { name: { $ilike: `%${q}%` } },
            { 'address.cidade': { $ilike: `%${q}%` } }
        ];
    }
    try {
        const workshops = await oficinaModuleService.listOficinas(filters, {
            take: Number(limit),
            skip: Number(offset),
            order: { created_at: "DESC" }
        });
        return res.json({
            workshops,
            count: workshops.length,
            limit: Number(limit),
            offset: Number(offset),
        });
    }
    catch (error) {
        console.error("Erro ao listar oficinas:", error);
        return res.status(500).json({
            message: "Erro ao listar oficinas",
            error: error.message
        });
    }
}
/**
 * POST /store/workshops
 *
 * Cadastro de uma nova oficina (já existe)
 */
async function POST(req, res) {
    // Mantém funcionalidade existente de cadastro
    const oficinaModuleService = req.scope.resolve(oficina_1.OFICINA_MODULE);
    const { name, cnpj, email, phone, address, description, logo_url, photo_urls, horario_funcionamento } = req.body;
    if (!email || !name || !cnpj) {
        return res.status(400).json({
            message: "Email, nome da oficina e CNPJ são obrigatórios"
        });
    }
    try {
        const oficina = await oficinaModuleService.createOficinas({
            name,
            cnpj,
            email,
            phone,
            address,
            description,
            logo_url,
            photo_urls,
            horario_funcionamento,
            status: "pendente",
        });
        return res.status(201).json({
            message: "Oficina cadastrada com sucesso! Aguardando aprovação.",
            oficina
        });
    }
    catch (error) {
        console.error("Erro ao cadastrar oficina:", error);
        return res.status(500).json({
            message: "Erro ao cadastrar oficina",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3dvcmtzaG9wcy9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFVQSxrQkF5Q0M7QUFPRCxvQkFvREM7QUE3R0Qsc0RBQXlEO0FBRTVDLFFBQUEsWUFBWSxHQUFHLEtBQUssQ0FBQTtBQUVqQzs7OztHQUlHO0FBQ0ksS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsTUFBTSxvQkFBb0IsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyx3QkFBYyxDQUFDLENBQUE7SUFFOUQsTUFBTSxFQUFFLEtBQUssR0FBRyxFQUFFLEVBQUUsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFBO0lBRS9DLE1BQU0sT0FBTyxHQUFRO1FBQ25CLE1BQU0sRUFBRSxVQUFVLENBQUMsNEJBQTRCO0tBQ2hELENBQUE7SUFFRCxJQUFJLENBQUMsRUFBRSxDQUFDO1FBQ04sT0FBTyxDQUFDLEdBQUcsR0FBRztZQUNaLEVBQUUsSUFBSSxFQUFFLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRTtZQUM5QixFQUFFLGdCQUFnQixFQUFFLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRTtTQUMzQyxDQUFBO0lBQ0gsQ0FBQztJQUVELElBQUksQ0FBQztRQUNILE1BQU0sU0FBUyxHQUFHLE1BQU0sb0JBQW9CLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRTtZQUNqRSxJQUFJLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQztZQUNuQixJQUFJLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQztZQUNwQixLQUFLLEVBQUUsRUFBRSxVQUFVLEVBQUUsTUFBTSxFQUFFO1NBQzlCLENBQUMsQ0FBQTtRQUVGLE9BQU8sR0FBRyxDQUFDLElBQUksQ0FBQztZQUNkLFNBQVM7WUFDVCxLQUFLLEVBQUUsU0FBUyxDQUFDLE1BQU07WUFDdkIsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUM7WUFDcEIsTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUM7U0FDdkIsQ0FBQyxDQUFBO0lBRUosQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLDBCQUEwQixFQUFFLEtBQUssQ0FBQyxDQUFBO1FBRWhELE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLHlCQUF5QjtZQUNsQyxLQUFLLEVBQUUsS0FBSyxDQUFDLE9BQU87U0FDckIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUM7QUFFRDs7OztHQUlHO0FBQ0ksS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsOENBQThDO0lBQzlDLE1BQU0sb0JBQW9CLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsd0JBQWMsQ0FBQyxDQUFBO0lBRTlELE1BQU0sRUFDSixJQUFJLEVBQ0osSUFBSSxFQUNKLEtBQUssRUFDTCxLQUFLLEVBQ0wsT0FBTyxFQUNQLFdBQVcsRUFDWCxRQUFRLEVBQ1IsVUFBVSxFQUNWLHFCQUFxQixFQUN0QixHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUE7SUFFWixJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDN0IsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsZ0RBQWdEO1NBQzFELENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxJQUFJLENBQUM7UUFDSCxNQUFNLE9BQU8sR0FBRyxNQUFNLG9CQUFvQixDQUFDLGNBQWMsQ0FBQztZQUN4RCxJQUFJO1lBQ0osSUFBSTtZQUNKLEtBQUs7WUFDTCxLQUFLO1lBQ0wsT0FBTztZQUNQLFdBQVc7WUFDWCxRQUFRO1lBQ1IsVUFBVTtZQUNWLHFCQUFxQjtZQUNyQixNQUFNLEVBQUUsVUFBVTtTQUNuQixDQUFDLENBQUE7UUFFRixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSx1REFBdUQ7WUFDaEUsT0FBTztTQUNSLENBQUMsQ0FBQTtJQUVKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyw0QkFBNEIsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUVsRCxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSwyQkFBMkI7WUFDcEMsS0FBSyxFQUFFLEtBQUssQ0FBQyxPQUFPO1NBQ3JCLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=