"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const oficina_1 = require("../../../../../modules/oficina");
const booking_1 = require("../../../../../modules/booking");
/**
 * GET /store/workshops/:id/availability?date=2025-10-20
 *
 * Retorna horários disponíveis para agendamento em uma data específica
 *
 * Query params:
 * - date: Data no formato YYYY-MM-DD
 */
async function GET(req, res) {
    const oficinaModuleService = req.scope.resolve(oficina_1.OFICINA_MODULE);
    const bookingModuleService = req.scope.resolve(booking_1.BOOKING_MODULE);
    const { id: oficinaId } = req.params;
    const { date } = req.query;
    if (!date) {
        return res.status(400).json({
            message: "Parâmetro 'date' é obrigatório (formato: YYYY-MM-DD)"
        });
    }
    try {
        // Buscar oficina
        const oficina = await oficinaModuleService.retrieveOficina(oficinaId);
        if (!oficina || oficina.status !== "aprovado") {
            return res.status(404).json({
                message: "Oficina não encontrada ou não está disponível"
            });
        }
        // Verificar se oficina configurou horário de funcionamento
        if (!oficina.horario_funcionamento) {
            return res.status(400).json({
                message: "Oficina ainda não configurou horário de funcionamento"
            });
        }
        // Obter dia da semana da data solicitada
        const targetDate = new Date(date);
        const dayOfWeek = targetDate.toLocaleDateString('pt-BR', { weekday: 'short' }).toLowerCase();
        // Mapear dias da semana
        const dayMap = {
            'dom': 'dom',
            'seg': 'seg',
            'ter': 'ter',
            'qua': 'qua',
            'qui': 'qui',
            'sex': 'sex',
            'sáb': 'sab'
        };
        const dayKey = dayMap[dayOfWeek] || dayOfWeek;
        // Verificar se oficina trabalha neste dia
        const horarioDoDia = oficina.horario_funcionamento[dayKey];
        if (!horarioDoDia || horarioDoDia === null) {
            return res.json({
                available_slots: [],
                message: "Oficina não funciona neste dia"
            });
        }
        // Gerar slots de horário (a cada 30 minutos)
        const { inicio, fim, pause_inicio, pause_fim } = horarioDoDia;
        const slots = [];
        let currentTime = inicio; // ex: "08:00"
        const endTime = fim; // ex: "18:00"
        while (currentTime < endTime) {
            // Verificar se não está no horário de pausa
            if (pause_inicio && pause_fim) {
                if (currentTime >= pause_inicio && currentTime < pause_fim) {
                    currentTime = addMinutes(currentTime, 30);
                    continue;
                }
            }
            slots.push(currentTime);
            currentTime = addMinutes(currentTime, 30);
        }
        // Buscar agendamentos já existentes para este dia
        const startOfDay = new Date(targetDate);
        startOfDay.setHours(0, 0, 0, 0);
        const endOfDay = new Date(targetDate);
        endOfDay.setHours(23, 59, 59, 999);
        const bookings = await bookingModuleService.listBookings({
            oficina_id: oficinaId,
            appointment_date: {
                $gte: startOfDay,
                $lte: endOfDay
            },
            status: {
                $in: ["pendente_oficina", "confirmado"]
            }
        });
        // Remover horários já agendados
        const bookedSlots = bookings.map(b => {
            const time = new Date(b.appointment_date);
            return `${time.getHours().toString().padStart(2, '0')}:${time.getMinutes().toString().padStart(2, '0')}`;
        });
        const availableSlots = slots.filter(slot => !bookedSlots.includes(slot));
        return res.json({
            date: date,
            day_of_week: dayKey,
            working_hours: horarioDoDia,
            available_slots: availableSlots,
            total_slots: slots.length,
            booked_slots: bookedSlots.length,
        });
    }
    catch (error) {
        console.error("Erro ao verificar disponibilidade:", error);
        return res.status(500).json({
            message: "Erro ao verificar disponibilidade",
            error: error.message
        });
    }
}
// Helper para adicionar minutos a um horário "HH:MM"
function addMinutes(time, minutes) {
    const [hours, mins] = time.split(':').map(Number);
    const totalMinutes = hours * 60 + mins + minutes;
    const newHours = Math.floor(totalMinutes / 60);
    const newMins = totalMinutes % 60;
    return `${newHours.toString().padStart(2, '0')}:${newMins.toString().padStart(2, '0')}`;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3dvcmtzaG9wcy9baWRdL2F2YWlsYWJpbGl0eS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQVlBLGtCQTJIQztBQXRJRCw0REFBK0Q7QUFDL0QsNERBQStEO0FBRS9EOzs7Ozs7O0dBT0c7QUFDSSxLQUFLLFVBQVUsR0FBRyxDQUN2QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixNQUFNLG9CQUFvQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHdCQUFjLENBQUMsQ0FBQTtJQUM5RCxNQUFNLG9CQUFvQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHdCQUFjLENBQUMsQ0FBQTtJQUU5RCxNQUFNLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUE7SUFDcEMsTUFBTSxFQUFFLElBQUksRUFBRSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUE7SUFFMUIsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ1YsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsc0RBQXNEO1NBQ2hFLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxJQUFJLENBQUM7UUFDSCxpQkFBaUI7UUFDakIsTUFBTSxPQUFPLEdBQUcsTUFBTSxvQkFBb0IsQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLENBQUE7UUFFckUsSUFBSSxDQUFDLE9BQU8sSUFBSSxPQUFPLENBQUMsTUFBTSxLQUFLLFVBQVUsRUFBRSxDQUFDO1lBQzlDLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQzFCLE9BQU8sRUFBRSwrQ0FBK0M7YUFDekQsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUVELDJEQUEyRDtRQUMzRCxJQUFJLENBQUMsT0FBTyxDQUFDLHFCQUFxQixFQUFFLENBQUM7WUFDbkMsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDMUIsT0FBTyxFQUFFLHVEQUF1RDthQUNqRSxDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQseUNBQXlDO1FBQ3pDLE1BQU0sVUFBVSxHQUFHLElBQUksSUFBSSxDQUFDLElBQWMsQ0FBQyxDQUFBO1FBQzNDLE1BQU0sU0FBUyxHQUFHLFVBQVUsQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLEVBQUUsRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQTtRQUU1Rix3QkFBd0I7UUFDeEIsTUFBTSxNQUFNLEdBQUc7WUFDYixLQUFLLEVBQUUsS0FBSztZQUNaLEtBQUssRUFBRSxLQUFLO1lBQ1osS0FBSyxFQUFFLEtBQUs7WUFDWixLQUFLLEVBQUUsS0FBSztZQUNaLEtBQUssRUFBRSxLQUFLO1lBQ1osS0FBSyxFQUFFLEtBQUs7WUFDWixLQUFLLEVBQUUsS0FBSztTQUNiLENBQUE7UUFFRCxNQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksU0FBUyxDQUFBO1FBRTdDLDBDQUEwQztRQUMxQyxNQUFNLFlBQVksR0FBRyxPQUFPLENBQUMscUJBQXFCLENBQUMsTUFBTSxDQUFDLENBQUE7UUFFMUQsSUFBSSxDQUFDLFlBQVksSUFBSSxZQUFZLEtBQUssSUFBSSxFQUFFLENBQUM7WUFDM0MsT0FBTyxHQUFHLENBQUMsSUFBSSxDQUFDO2dCQUNkLGVBQWUsRUFBRSxFQUFFO2dCQUNuQixPQUFPLEVBQUUsZ0NBQWdDO2FBQzFDLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFFRCw2Q0FBNkM7UUFDN0MsTUFBTSxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUUsWUFBWSxFQUFFLFNBQVMsRUFBRSxHQUFHLFlBQVksQ0FBQTtRQUM3RCxNQUFNLEtBQUssR0FBYSxFQUFFLENBQUE7UUFFMUIsSUFBSSxXQUFXLEdBQUcsTUFBTSxDQUFBLENBQUMsY0FBYztRQUN2QyxNQUFNLE9BQU8sR0FBRyxHQUFHLENBQUEsQ0FBQyxjQUFjO1FBRWxDLE9BQU8sV0FBVyxHQUFHLE9BQU8sRUFBRSxDQUFDO1lBQzdCLDRDQUE0QztZQUM1QyxJQUFJLFlBQVksSUFBSSxTQUFTLEVBQUUsQ0FBQztnQkFDOUIsSUFBSSxXQUFXLElBQUksWUFBWSxJQUFJLFdBQVcsR0FBRyxTQUFTLEVBQUUsQ0FBQztvQkFDM0QsV0FBVyxHQUFHLFVBQVUsQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDLENBQUE7b0JBQ3pDLFNBQVE7Z0JBQ1YsQ0FBQztZQUNILENBQUM7WUFFRCxLQUFLLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFBO1lBQ3ZCLFdBQVcsR0FBRyxVQUFVLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FBQyxDQUFBO1FBQzNDLENBQUM7UUFFRCxrREFBa0Q7UUFDbEQsTUFBTSxVQUFVLEdBQUcsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUE7UUFDdkMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQTtRQUUvQixNQUFNLFFBQVEsR0FBRyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQTtRQUNyQyxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFBO1FBRWxDLE1BQU0sUUFBUSxHQUFHLE1BQU0sb0JBQW9CLENBQUMsWUFBWSxDQUFDO1lBQ3ZELFVBQVUsRUFBRSxTQUFTO1lBQ3JCLGdCQUFnQixFQUFFO2dCQUNoQixJQUFJLEVBQUUsVUFBVTtnQkFDaEIsSUFBSSxFQUFFLFFBQVE7YUFDZjtZQUNELE1BQU0sRUFBRTtnQkFDTixHQUFHLEVBQUUsQ0FBQyxrQkFBa0IsRUFBRSxZQUFZLENBQUM7YUFDeEM7U0FDRixDQUFDLENBQUE7UUFFRixnQ0FBZ0M7UUFDaEMsTUFBTSxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNuQyxNQUFNLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQTtZQUN6QyxPQUFPLEdBQUcsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQTtRQUMxRyxDQUFDLENBQUMsQ0FBQTtRQUVGLE1BQU0sY0FBYyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQTtRQUV4RSxPQUFPLEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDZCxJQUFJLEVBQUUsSUFBSTtZQUNWLFdBQVcsRUFBRSxNQUFNO1lBQ25CLGFBQWEsRUFBRSxZQUFZO1lBQzNCLGVBQWUsRUFBRSxjQUFjO1lBQy9CLFdBQVcsRUFBRSxLQUFLLENBQUMsTUFBTTtZQUN6QixZQUFZLEVBQUUsV0FBVyxDQUFDLE1BQU07U0FDakMsQ0FBQyxDQUFBO0lBRUosQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLG9DQUFvQyxFQUFFLEtBQUssQ0FBQyxDQUFBO1FBRTFELE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLG1DQUFtQztZQUM1QyxLQUFLLEVBQUUsS0FBSyxDQUFDLE9BQU87U0FDckIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUM7QUFFRCxxREFBcUQ7QUFDckQsU0FBUyxVQUFVLENBQUMsSUFBWSxFQUFFLE9BQWU7SUFDL0MsTUFBTSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQTtJQUNqRCxNQUFNLFlBQVksR0FBRyxLQUFLLEdBQUcsRUFBRSxHQUFHLElBQUksR0FBRyxPQUFPLENBQUE7SUFDaEQsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDLENBQUE7SUFDOUMsTUFBTSxPQUFPLEdBQUcsWUFBWSxHQUFHLEVBQUUsQ0FBQTtJQUVqQyxPQUFPLEdBQUcsUUFBUSxDQUFDLFFBQVEsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLElBQUksT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQTtBQUN6RixDQUFDIn0=