"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
/**
 * POST /store/workshops/lookup-by-cnpj
 *
 * Consulta dados de empresa por CNPJ
 * Mock implementado - pronto para integração com Serasa/Receita Federal
 */
async function POST(req, res) {
    const { cnpj } = req.body;
    if (!cnpj) {
        return res.status(400).json({
            message: "CNPJ é obrigatório"
        });
    }
    // Validação básica de CNPJ
    const cleanCnpj = cnpj.replace(/[^\d]/g, '');
    if (cleanCnpj.length !== 14) {
        return res.status(400).json({
            message: "CNPJ deve ter 14 dígitos"
        });
    }
    if (!isValidCNPJ(cleanCnpj)) {
        return res.status(400).json({
            message: "CNPJ inválido"
        });
    }
    try {
        // MOCK: Dados fictícios baseados no CNPJ
        // Em produção, aqui seria feita a consulta à API da Receita Federal/Serasa
        const mockData = generateMockCompanyData(cleanCnpj);
        return res.json({
            success: true,
            data: mockData,
            source: "mock", // Indica que são dados fictícios
            message: "Dados encontrados (mock - para desenvolvimento)"
        });
    }
    catch (error) {
        console.error("Erro ao consultar CNPJ:", error);
        return res.status(500).json({
            message: "Erro interno ao consultar CNPJ",
            error: error.message
        });
    }
}
/**
 * Valida CNPJ usando algoritmo oficial
 */
function isValidCNPJ(cnpj) {
    // Remove caracteres não numéricos
    cnpj = cnpj.replace(/[^\d]/g, '');
    // Verifica se tem 14 dígitos
    if (cnpj.length !== 14)
        return false;
    // Verifica se todos os dígitos são iguais
    if (/^(\d)\1+$/.test(cnpj))
        return false;
    // Validação do primeiro dígito verificador
    let sum = 0;
    let weight = 5;
    for (let i = 0; i < 12; i++) {
        sum += parseInt(cnpj[i]) * weight;
        weight = weight === 2 ? 9 : weight - 1;
    }
    let digit1 = sum % 11 < 2 ? 0 : 11 - (sum % 11);
    if (parseInt(cnpj[12]) !== digit1)
        return false;
    // Validação do segundo dígito verificador
    sum = 0;
    weight = 6;
    for (let i = 0; i < 13; i++) {
        sum += parseInt(cnpj[i]) * weight;
        weight = weight === 2 ? 9 : weight - 1;
    }
    let digit2 = sum % 11 < 2 ? 0 : 11 - (sum % 11);
    return parseInt(cnpj[13]) === digit2;
}
/**
 * Gera dados fictícios baseados no CNPJ
 * Simula resposta de API real de consulta empresarial
 */
function generateMockCompanyData(cnpj) {
    const companyTypes = [
        "Oficina Mecânica",
        "Auto Center",
        "Centro Automotivo",
        "Serviços Automotivos",
        "Mecânica Especializada",
        "Auto Peças e Serviços"
    ];
    const cities = [
        { name: "São Paulo", state: "SP", zip: "01000-000" },
        { name: "Rio de Janeiro", state: "RJ", zip: "20000-000" },
        { name: "Belo Horizonte", state: "MG", zip: "30000-000" },
        { name: "Salvador", state: "BA", zip: "40000-000" },
        { name: "Brasília", state: "DF", zip: "70000-000" },
        { name: "Fortaleza", state: "CE", zip: "60000-000" },
        { name: "Manaus", state: "AM", zip: "69000-000" },
        { name: "Curitiba", state: "PR", zip: "80000-000" }
    ];
    const streets = [
        "Rua das Flores", "Avenida Central", "Rua do Comércio", "Avenida Principal",
        "Rua da Paz", "Avenida Brasil", "Rua São João", "Avenida Paulista"
    ];
    // Usar CNPJ como seed para gerar dados consistentes
    const seed = parseInt(cnpj.substr(0, 8));
    const companyType = companyTypes[seed % companyTypes.length];
    const city = cities[seed % cities.length];
    const street = streets[seed % streets.length];
    const number = (seed % 9999) + 1;
    // Gerar razão social baseada no tipo
    const companyNames = {
        "Oficina Mecânica": ["Auto Mecânica Silva", "Oficina do João", "Mecânica Central", "Auto Serviços"],
        "Auto Center": ["Auto Center Premium", "Centro Automotivo Total", "Auto Center Express", "Centro do Carro"],
        "Centro Automotivo": ["Centro Auto Plus", "Automotivo Central", "Centro Car Service", "Auto Centro"],
        "Serviços Automotivos": ["Auto Serviços Pro", "Serviços do Carro", "Auto Manutenção", "Car Service"],
        "Mecânica Especializada": ["Mecânica Especial", "Auto Especializada", "Mecânica Pro", "Especial Auto"],
        "Auto Peças e Serviços": ["Auto Peças Total", "Peças e Serviços", "Auto Completo", "Peças Central"]
    };
    const nameOptions = companyNames[companyType] || companyNames["Oficina Mecânica"];
    const companyName = nameOptions[seed % nameOptions.length];
    return {
        cnpj: cnpj.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, "$1.$2.$3/$4-$5"),
        company_name: companyName,
        trade_name: companyName,
        company_type: companyType,
        status: "Ativa",
        opening_date: new Date(2010 + (seed % 14), seed % 12, (seed % 28) + 1).toISOString().split('T')[0],
        legal_nature: "Sociedade Empresária Limitada",
        main_activity: "4520-1/00 - Serviços de manutenção e reparação de veículos automotores",
        address: {
            street,
            number,
            complement: seed % 3 === 0 ? "Sala " + (seed % 10 + 1) : null,
            neighborhood: "Centro",
            city: city.name,
            state: city.state,
            zip_code: city.zip,
            country: "Brasil"
        },
        contact: {
            phone: `(${11 + (seed % 89)}) ${9000 + (seed % 9000)}-${1000 + (seed % 9000)}`,
            email: `contato@${companyName.toLowerCase().replace(/\s+/g, '')}.com.br`,
            website: `www.${companyName.toLowerCase().replace(/\s+/g, '')}.com.br`
        },
        financial: {
            capital: (10000 + (seed % 90000)).toFixed(2),
            revenue_range: seed % 3 === 0 ? "Até R$ 360.000" : seed % 3 === 1 ? "De R$ 360.000 a R$ 4.800.000" : "Acima de R$ 4.800.000",
            employees: (1 + (seed % 20)).toString()
        },
        registration: {
            state_registration: `${city.state}${seed.toString().padStart(8, '0')}`,
            municipal_registration: `${city.name.substr(0, 3).toUpperCase()}${seed.toString().padStart(6, '0')}`,
            suframa: null
        }
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3dvcmtzaG9wcy9sb29rdXAtYnktY25wai9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQVFBLG9CQWdEQztBQXRERDs7Ozs7R0FLRztBQUNJLEtBQUssVUFBVSxJQUFJLENBQ3hCLEdBQWtCLEVBQ2xCLEdBQW1CO0lBRW5CLE1BQU0sRUFBRSxJQUFJLEVBQUUsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFBO0lBRXpCLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNWLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLG9CQUFvQjtTQUM5QixDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsMkJBQTJCO0lBQzNCLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFBO0lBRTVDLElBQUksU0FBUyxDQUFDLE1BQU0sS0FBSyxFQUFFLEVBQUUsQ0FBQztRQUM1QixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSwwQkFBMEI7U0FDcEMsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVELElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztRQUM1QixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSxlQUFlO1NBQ3pCLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxJQUFJLENBQUM7UUFDSCx5Q0FBeUM7UUFDekMsMkVBQTJFO1FBRTNFLE1BQU0sUUFBUSxHQUFHLHVCQUF1QixDQUFDLFNBQVMsQ0FBQyxDQUFBO1FBRW5ELE9BQU8sR0FBRyxDQUFDLElBQUksQ0FBQztZQUNkLE9BQU8sRUFBRSxJQUFJO1lBQ2IsSUFBSSxFQUFFLFFBQVE7WUFDZCxNQUFNLEVBQUUsTUFBTSxFQUFFLGlDQUFpQztZQUNqRCxPQUFPLEVBQUUsaURBQWlEO1NBQzNELENBQUMsQ0FBQTtJQUVKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyx5QkFBeUIsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUUvQyxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSxnQ0FBZ0M7WUFDekMsS0FBSyxFQUFFLEtBQUssQ0FBQyxPQUFPO1NBQ3JCLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDO0FBRUQ7O0dBRUc7QUFDSCxTQUFTLFdBQVcsQ0FBQyxJQUFZO0lBQy9CLGtDQUFrQztJQUNsQyxJQUFJLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUE7SUFFakMsNkJBQTZCO0lBQzdCLElBQUksSUFBSSxDQUFDLE1BQU0sS0FBSyxFQUFFO1FBQUUsT0FBTyxLQUFLLENBQUE7SUFFcEMsMENBQTBDO0lBQzFDLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7UUFBRSxPQUFPLEtBQUssQ0FBQTtJQUV4QywyQ0FBMkM7SUFDM0MsSUFBSSxHQUFHLEdBQUcsQ0FBQyxDQUFBO0lBQ1gsSUFBSSxNQUFNLEdBQUcsQ0FBQyxDQUFBO0lBRWQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO1FBQzVCLEdBQUcsSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFBO1FBQ2pDLE1BQU0sR0FBRyxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUE7SUFDeEMsQ0FBQztJQUVELElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUMsQ0FBQTtJQUUvQyxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxNQUFNO1FBQUUsT0FBTyxLQUFLLENBQUE7SUFFL0MsMENBQTBDO0lBQzFDLEdBQUcsR0FBRyxDQUFDLENBQUE7SUFDUCxNQUFNLEdBQUcsQ0FBQyxDQUFBO0lBRVYsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO1FBQzVCLEdBQUcsSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFBO1FBQ2pDLE1BQU0sR0FBRyxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUE7SUFDeEMsQ0FBQztJQUVELElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUMsQ0FBQTtJQUUvQyxPQUFPLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxNQUFNLENBQUE7QUFDdEMsQ0FBQztBQUVEOzs7R0FHRztBQUNILFNBQVMsdUJBQXVCLENBQUMsSUFBWTtJQUMzQyxNQUFNLFlBQVksR0FBRztRQUNuQixrQkFBa0I7UUFDbEIsYUFBYTtRQUNiLG1CQUFtQjtRQUNuQixzQkFBc0I7UUFDdEIsd0JBQXdCO1FBQ3hCLHVCQUF1QjtLQUN4QixDQUFBO0lBRUQsTUFBTSxNQUFNLEdBQUc7UUFDYixFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsV0FBVyxFQUFFO1FBQ3BELEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFLFdBQVcsRUFBRTtRQUN6RCxFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxXQUFXLEVBQUU7UUFDekQsRUFBRSxJQUFJLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFLFdBQVcsRUFBRTtRQUNuRCxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsV0FBVyxFQUFFO1FBQ25ELEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxXQUFXLEVBQUU7UUFDcEQsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFLFdBQVcsRUFBRTtRQUNqRCxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsV0FBVyxFQUFFO0tBQ3BELENBQUE7SUFFRCxNQUFNLE9BQU8sR0FBRztRQUNkLGdCQUFnQixFQUFFLGlCQUFpQixFQUFFLGlCQUFpQixFQUFFLG1CQUFtQjtRQUMzRSxZQUFZLEVBQUUsZ0JBQWdCLEVBQUUsY0FBYyxFQUFFLGtCQUFrQjtLQUNuRSxDQUFBO0lBRUQsb0RBQW9EO0lBQ3BELE1BQU0sSUFBSSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFBO0lBQ3hDLE1BQU0sV0FBVyxHQUFHLFlBQVksQ0FBQyxJQUFJLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFBO0lBQzVELE1BQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFBO0lBQ3pDLE1BQU0sTUFBTSxHQUFHLE9BQU8sQ0FBQyxJQUFJLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFBO0lBQzdDLE1BQU0sTUFBTSxHQUFHLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQTtJQUVoQyxxQ0FBcUM7SUFDckMsTUFBTSxZQUFZLEdBQUc7UUFDbkIsa0JBQWtCLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRSxpQkFBaUIsRUFBRSxrQkFBa0IsRUFBRSxlQUFlLENBQUM7UUFDbkcsYUFBYSxFQUFFLENBQUMscUJBQXFCLEVBQUUseUJBQXlCLEVBQUUscUJBQXFCLEVBQUUsaUJBQWlCLENBQUM7UUFDM0csbUJBQW1CLEVBQUUsQ0FBQyxrQkFBa0IsRUFBRSxvQkFBb0IsRUFBRSxvQkFBb0IsRUFBRSxhQUFhLENBQUM7UUFDcEcsc0JBQXNCLEVBQUUsQ0FBQyxtQkFBbUIsRUFBRSxtQkFBbUIsRUFBRSxpQkFBaUIsRUFBRSxhQUFhLENBQUM7UUFDcEcsd0JBQXdCLEVBQUUsQ0FBQyxtQkFBbUIsRUFBRSxvQkFBb0IsRUFBRSxjQUFjLEVBQUUsZUFBZSxDQUFDO1FBQ3RHLHVCQUF1QixFQUFFLENBQUMsa0JBQWtCLEVBQUUsa0JBQWtCLEVBQUUsZUFBZSxFQUFFLGVBQWUsQ0FBQztLQUNwRyxDQUFBO0lBRUQsTUFBTSxXQUFXLEdBQUcsWUFBWSxDQUFDLFdBQVcsQ0FBQyxJQUFJLFlBQVksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFBO0lBQ2pGLE1BQU0sV0FBVyxHQUFHLFdBQVcsQ0FBQyxJQUFJLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFBO0lBRTFELE9BQU87UUFDTCxJQUFJLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyx1Q0FBdUMsRUFBRSxnQkFBZ0IsQ0FBQztRQUM3RSxZQUFZLEVBQUUsV0FBVztRQUN6QixVQUFVLEVBQUUsV0FBVztRQUN2QixZQUFZLEVBQUUsV0FBVztRQUN6QixNQUFNLEVBQUUsT0FBTztRQUNmLFlBQVksRUFBRSxJQUFJLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDLEVBQUUsSUFBSSxHQUFHLEVBQUUsRUFBRSxDQUFDLElBQUksR0FBRyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ2xHLFlBQVksRUFBRSwrQkFBK0I7UUFDN0MsYUFBYSxFQUFFLHdFQUF3RTtRQUN2RixPQUFPLEVBQUU7WUFDUCxNQUFNO1lBQ04sTUFBTTtZQUNOLFVBQVUsRUFBRSxJQUFJLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxHQUFHLENBQUMsSUFBSSxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtZQUM3RCxZQUFZLEVBQUUsUUFBUTtZQUN0QixJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7WUFDZixLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUs7WUFDakIsUUFBUSxFQUFFLElBQUksQ0FBQyxHQUFHO1lBQ2xCLE9BQU8sRUFBRSxRQUFRO1NBQ2xCO1FBQ0QsT0FBTyxFQUFFO1lBQ1AsS0FBSyxFQUFFLElBQUksRUFBRSxHQUFHLENBQUMsSUFBSSxHQUFHLEVBQUUsQ0FBQyxLQUFLLElBQUksR0FBRyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsSUFBSSxJQUFJLEdBQUcsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLEVBQUU7WUFDOUUsS0FBSyxFQUFFLFdBQVcsV0FBVyxDQUFDLFdBQVcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLFNBQVM7WUFDeEUsT0FBTyxFQUFFLE9BQU8sV0FBVyxDQUFDLFdBQVcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLFNBQVM7U0FDdkU7UUFDRCxTQUFTLEVBQUU7WUFDVCxPQUFPLEVBQUUsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1lBQzVDLGFBQWEsRUFBRSxJQUFJLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLElBQUksR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDLENBQUMsdUJBQXVCO1lBQzVILFNBQVMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRTtTQUN4QztRQUNELFlBQVksRUFBRTtZQUNaLGtCQUFrQixFQUFFLEdBQUcsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRTtZQUN0RSxzQkFBc0IsRUFBRSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUUsR0FBRyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRTtZQUNwRyxPQUFPLEVBQUUsSUFBSTtTQUNkO0tBQ0YsQ0FBQTtBQUNILENBQUMifQ==