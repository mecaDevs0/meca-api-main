"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const utils_1 = require("@medusajs/framework/utils");
const oficina_1 = require("../../../modules/oficina");
const oficina_2 = require("../../../modules/oficina/models/oficina");
/**
 * GET /store/services
 *
 * Busca serviços disponíveis com filtros opcionais
 *
 * Query params:
 * - q: termo de busca (nome do serviço)
 * - cidade: filtro por cidade
 * - estado: filtro por estado
 * - limit: limite de resultados (default: 20)
 * - offset: offset para paginação (default: 0)
 */
async function GET(req, res) {
    const productModuleService = req.scope.resolve(utils_1.Modules.PRODUCT);
    const oficinaModuleService = req.scope.resolve(oficina_1.OFICINA_MODULE);
    const query = req.scope.resolve("query");
    const { q, cidade, estado, limit = 20, offset = 0 } = req.query;
    // Buscar apenas oficinas aprovadas
    const oficinasAprovadas = await oficinaModuleService.listOficinas({
        status: oficina_2.OficinaStatus.APROVADO
    });
    const oficinaIds = oficinasAprovadas.map(o => o.id);
    // Se não houver oficinas aprovadas, retornar vazio
    if (oficinaIds.length === 0) {
        return res.json({
            services: [],
            count: 0,
            limit: Number(limit),
            offset: Number(offset)
        });
    }
    // Construir filtros de busca
    const filters = {};
    if (q) {
        filters.title = {
            $ilike: `%${q}%`
        };
    }
    // Buscar produtos/serviços
    const { data: products, metadata } = await productModuleService.listAndCountProducts(filters, {
        take: Number(limit),
        skip: Number(offset),
        relations: ["variants"]
    });
    // Enriquecer com dados da oficina usando o serviço de query
    const servicesWithOficina = await Promise.all(products.map(async (product) => {
        // Buscar oficina vinculada ao produto
        const { data } = await query.graph({
            entity: "product",
            fields: ["id", "title", "description", "thumbnail", "oficina.*"],
            filters: { id: product.id }
        });
        return {
            ...product,
            oficina: data[0]?.oficina || null
        };
    }));
    // Filtrar por localização se especificado
    let filteredServices = servicesWithOficina;
    if (cidade || estado) {
        filteredServices = servicesWithOficina.filter(service => {
            const oficina = service.oficina;
            if (!oficina?.address)
                return false;
            const matchCidade = cidade ? oficina.address.cidade?.toLowerCase() === cidade.toLowerCase() : true;
            const matchEstado = estado ? oficina.address.estado?.toLowerCase() === estado.toLowerCase() : true;
            return matchCidade && matchEstado;
        });
    }
    return res.json({
        services: filteredServices,
        count: metadata.count,
        limit: Number(limit),
        offset: Number(offset)
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3NlcnZpY2VzL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBaUJBLGtCQTBGQztBQTFHRCxxREFBbUQ7QUFDbkQsc0RBQXlEO0FBQ3pELHFFQUF1RTtBQUV2RTs7Ozs7Ozs7Ozs7R0FXRztBQUNJLEtBQUssVUFBVSxHQUFHLENBQ3ZCLEdBQWtCLEVBQ2xCLEdBQW1CO0lBRW5CLE1BQU0sb0JBQW9CLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBTyxDQUFDLE9BQU8sQ0FBQyxDQUFBO0lBQy9ELE1BQU0sb0JBQW9CLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsd0JBQWMsQ0FBQyxDQUFBO0lBQzlELE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFBO0lBRXhDLE1BQU0sRUFDSixDQUFDLEVBQ0QsTUFBTSxFQUNOLE1BQU0sRUFDTixLQUFLLEdBQUcsRUFBRSxFQUNWLE1BQU0sR0FBRyxDQUFDLEVBQ1gsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFBO0lBRWIsbUNBQW1DO0lBQ25DLE1BQU0saUJBQWlCLEdBQUcsTUFBTSxvQkFBb0IsQ0FBQyxZQUFZLENBQUM7UUFDaEUsTUFBTSxFQUFFLHVCQUFhLENBQUMsUUFBUTtLQUMvQixDQUFDLENBQUE7SUFFRixNQUFNLFVBQVUsR0FBRyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUE7SUFFbkQsbURBQW1EO0lBQ25ELElBQUksVUFBVSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztRQUM1QixPQUFPLEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDZCxRQUFRLEVBQUUsRUFBRTtZQUNaLEtBQUssRUFBRSxDQUFDO1lBQ1IsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUM7WUFDcEIsTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUM7U0FDdkIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVELDZCQUE2QjtJQUM3QixNQUFNLE9BQU8sR0FBUSxFQUFFLENBQUE7SUFFdkIsSUFBSSxDQUFDLEVBQUUsQ0FBQztRQUNOLE9BQU8sQ0FBQyxLQUFLLEdBQUc7WUFDZCxNQUFNLEVBQUUsSUFBSSxDQUFDLEdBQUc7U0FDakIsQ0FBQTtJQUNILENBQUM7SUFFRCwyQkFBMkI7SUFDM0IsTUFBTSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLEdBQUcsTUFBTSxvQkFBb0IsQ0FBQyxvQkFBb0IsQ0FDbEYsT0FBTyxFQUNQO1FBQ0UsSUFBSSxFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUM7UUFDbkIsSUFBSSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUM7UUFDcEIsU0FBUyxFQUFFLENBQUMsVUFBVSxDQUFDO0tBQ3hCLENBQ0YsQ0FBQTtJQUVELDREQUE0RDtJQUM1RCxNQUFNLG1CQUFtQixHQUFHLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FDM0MsUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLEVBQUU7UUFDN0Isc0NBQXNDO1FBQ3RDLE1BQU0sRUFBRSxJQUFJLEVBQUUsR0FBRyxNQUFNLEtBQUssQ0FBQyxLQUFLLENBQUM7WUFDakMsTUFBTSxFQUFFLFNBQVM7WUFDakIsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxhQUFhLEVBQUUsV0FBVyxFQUFFLFdBQVcsQ0FBQztZQUNoRSxPQUFPLEVBQUUsRUFBRSxFQUFFLEVBQUUsT0FBTyxDQUFDLEVBQUUsRUFBRTtTQUM1QixDQUFDLENBQUE7UUFFRixPQUFPO1lBQ0wsR0FBRyxPQUFPO1lBQ1YsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxPQUFPLElBQUksSUFBSTtTQUNsQyxDQUFBO0lBQ0gsQ0FBQyxDQUFDLENBQ0gsQ0FBQTtJQUVELDBDQUEwQztJQUMxQyxJQUFJLGdCQUFnQixHQUFHLG1CQUFtQixDQUFBO0lBRTFDLElBQUksTUFBTSxJQUFJLE1BQU0sRUFBRSxDQUFDO1FBQ3JCLGdCQUFnQixHQUFHLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUN0RCxNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFBO1lBQy9CLElBQUksQ0FBQyxPQUFPLEVBQUUsT0FBTztnQkFBRSxPQUFPLEtBQUssQ0FBQTtZQUVuQyxNQUFNLFdBQVcsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLFdBQVcsRUFBRSxLQUFLLE1BQU0sQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFBO1lBQ2xHLE1BQU0sV0FBVyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLEtBQUssTUFBTSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUE7WUFFbEcsT0FBTyxXQUFXLElBQUksV0FBVyxDQUFBO1FBQ25DLENBQUMsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVELE9BQU8sR0FBRyxDQUFDLElBQUksQ0FBQztRQUNkLFFBQVEsRUFBRSxnQkFBZ0I7UUFDMUIsS0FBSyxFQUFFLFFBQVEsQ0FBQyxLQUFLO1FBQ3JCLEtBQUssRUFBRSxNQUFNLENBQUMsS0FBSyxDQUFDO1FBQ3BCLE1BQU0sRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDO0tBQ3ZCLENBQUMsQ0FBQTtBQUNKLENBQUMifQ==