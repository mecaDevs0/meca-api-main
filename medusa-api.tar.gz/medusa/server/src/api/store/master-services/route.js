"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const master_service_1 = require("../../../modules/master_service");
/**
 * GET /store/master-services
 *
 * Lista serviços master disponíveis (para oficinas selecionarem)
 */
async function GET(req, res) {
    const masterServiceService = req.scope.resolve(master_service_1.MASTER_SERVICE_MODULE);
    const { category } = req.query;
    const filters = {
        is_active: true
    };
    if (category) {
        filters.category = category;
    }
    try {
        const services = await masterServiceService.listMasterServices(filters, {
            order: { display_order: "ASC", name: "ASC" }
        });
        return res.json({
            services,
            count: services.length,
        });
    }
    catch (error) {
        console.error("Erro ao listar serviços master:", error);
        return res.status(500).json({
            message: "Erro ao listar serviços",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL21hc3Rlci1zZXJ2aWNlcy9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQVFBLGtCQWtDQztBQXpDRCxvRUFBdUU7QUFFdkU7Ozs7R0FJRztBQUNJLEtBQUssVUFBVSxHQUFHLENBQ3ZCLEdBQWtCLEVBQ2xCLEdBQW1CO0lBRW5CLE1BQU0sb0JBQW9CLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsc0NBQXFCLENBQUMsQ0FBQTtJQUVyRSxNQUFNLEVBQUUsUUFBUSxFQUFFLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQTtJQUU5QixNQUFNLE9BQU8sR0FBUTtRQUNuQixTQUFTLEVBQUUsSUFBSTtLQUNoQixDQUFBO0lBRUQsSUFBSSxRQUFRLEVBQUUsQ0FBQztRQUNiLE9BQU8sQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFBO0lBQzdCLENBQUM7SUFFRCxJQUFJLENBQUM7UUFDSCxNQUFNLFFBQVEsR0FBRyxNQUFNLG9CQUFvQixDQUFDLGtCQUFrQixDQUFDLE9BQU8sRUFBRTtZQUN0RSxLQUFLLEVBQUUsRUFBRSxhQUFhLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUU7U0FDN0MsQ0FBQyxDQUFBO1FBRUYsT0FBTyxHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ2QsUUFBUTtZQUNSLEtBQUssRUFBRSxRQUFRLENBQUMsTUFBTTtTQUN2QixDQUFDLENBQUE7SUFFSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsaUNBQWlDLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFFdkQsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUseUJBQXlCO1lBQ2xDLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTztTQUNyQixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9