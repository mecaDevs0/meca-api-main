"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const utils_1 = require("@medusajs/framework/utils");
const booking_1 = require("../../../../../modules/booking");
const booking_2 = require("../../../../../modules/booking/models/booking");
/**
 * POST /store/bookings/:id/confirm-payment
 *
 * Cliente confirma o serviço finalizado e inicia o processo de pagamento
 */
async function POST(req, res) {
    const bookingModuleService = req.scope.resolve(booking_1.BOOKING_MODULE);
    const orderModuleService = req.scope.resolve(utils_1.Modules.ORDER);
    const paymentModuleService = req.scope.resolve(utils_1.Modules.PAYMENT);
    const eventBusService = req.scope.resolve("eventBus");
    const customerId = req.auth_context?.actor_id;
    const { id: bookingId } = req.params;
    if (!customerId) {
        return res.status(401).json({ message: "Não autenticado" });
    }
    try {
        // Buscar agendamento
        const booking = await bookingModuleService.retrieveBooking(bookingId);
        // Verificar se o agendamento pertence ao cliente
        if (booking.customer_id !== customerId) {
            return res.status(403).json({ message: "Acesso negado" });
        }
        // Verificar se o status permite pagamento
        if (booking.status !== booking_2.BookingStatus.FINALIZADO_MECANICO) {
            return res.status(400).json({
                message: "Este agendamento ainda não foi finalizado pela oficina. Status: " + booking.status
            });
        }
        // Buscar ou criar Order para este booking
        let order;
        if (booking.order_id) {
            order = await orderModuleService.retrieveOrder(booking.order_id);
        }
        else {
            // Criar Order se não existir
            order = await orderModuleService.createOrders({
                currency_code: "brl",
                email: req.auth_context?.actor_email || "",
                items: [{
                        variant_id: booking.product_id, // Seria o variant do product
                        quantity: 1,
                        unit_price: booking.final_price || booking.estimated_price,
                    }],
                metadata: {
                    booking_id: bookingId,
                    is_booking_payment: true,
                }
            });
            // Atualizar booking com order_id
            await bookingModuleService.updateBookings(bookingId, {
                order_id: order.id,
            });
        }
        // Criar Payment Session com PagBank
        const paymentSession = await paymentModuleService.createPaymentSession({
            amount: booking.final_price || booking.estimated_price,
            currency_code: "brl",
            provider_id: "pagbank", // ID do nosso provedor customizado
            data: {
                booking_id: bookingId,
                customer_id: customerId,
            }
        });
        // Emitir evento
        await eventBusService.emit("booking.payment_initiated", {
            booking_id: bookingId,
            customer_id: customerId,
            order_id: order.id,
            amount: booking.final_price || booking.estimated_price,
        });
        return res.json({
            message: "Sessão de pagamento criada",
            booking,
            order,
            payment_session: paymentSession,
        });
    }
    catch (error) {
        console.error("Erro ao confirmar pagamento:", error);
        return res.status(500).json({
            message: "Erro ao processar pagamento",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL2Jvb2tpbmdzL1tpZF0vY29uZmlybS1wYXltZW50L3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBVUEsb0JBNkZDO0FBdEdELHFEQUFtRDtBQUNuRCw0REFBK0Q7QUFDL0QsMkVBQTZFO0FBRTdFOzs7O0dBSUc7QUFDSSxLQUFLLFVBQVUsSUFBSSxDQUN4QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixNQUFNLG9CQUFvQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHdCQUFjLENBQUMsQ0FBQTtJQUM5RCxNQUFNLGtCQUFrQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGVBQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUMzRCxNQUFNLG9CQUFvQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGVBQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQTtJQUMvRCxNQUFNLGVBQWUsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQTtJQUVyRCxNQUFNLFVBQVUsR0FBRyxHQUFHLENBQUMsWUFBWSxFQUFFLFFBQVEsQ0FBQTtJQUM3QyxNQUFNLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUE7SUFFcEMsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2hCLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsQ0FBQyxDQUFBO0lBQzdELENBQUM7SUFFRCxJQUFJLENBQUM7UUFDSCxxQkFBcUI7UUFDckIsTUFBTSxPQUFPLEdBQUcsTUFBTSxvQkFBb0IsQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLENBQUE7UUFFckUsaURBQWlEO1FBQ2pELElBQUksT0FBTyxDQUFDLFdBQVcsS0FBSyxVQUFVLEVBQUUsQ0FBQztZQUN2QyxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLGVBQWUsRUFBRSxDQUFDLENBQUE7UUFDM0QsQ0FBQztRQUVELDBDQUEwQztRQUMxQyxJQUFJLE9BQU8sQ0FBQyxNQUFNLEtBQUssdUJBQWEsQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1lBQ3pELE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQzFCLE9BQU8sRUFBRSxrRUFBa0UsR0FBRyxPQUFPLENBQUMsTUFBTTthQUM3RixDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQsMENBQTBDO1FBQzFDLElBQUksS0FBSyxDQUFBO1FBRVQsSUFBSSxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDckIsS0FBSyxHQUFHLE1BQU0sa0JBQWtCLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQTtRQUNsRSxDQUFDO2FBQU0sQ0FBQztZQUNOLDZCQUE2QjtZQUM3QixLQUFLLEdBQUcsTUFBTSxrQkFBa0IsQ0FBQyxZQUFZLENBQUM7Z0JBQzVDLGFBQWEsRUFBRSxLQUFLO2dCQUNwQixLQUFLLEVBQUUsR0FBRyxDQUFDLFlBQVksRUFBRSxXQUFXLElBQUksRUFBRTtnQkFDMUMsS0FBSyxFQUFFLENBQUM7d0JBQ04sVUFBVSxFQUFFLE9BQU8sQ0FBQyxVQUFVLEVBQUUsNkJBQTZCO3dCQUM3RCxRQUFRLEVBQUUsQ0FBQzt3QkFDWCxVQUFVLEVBQUUsT0FBTyxDQUFDLFdBQVcsSUFBSSxPQUFPLENBQUMsZUFBZTtxQkFDM0QsQ0FBQztnQkFDRixRQUFRLEVBQUU7b0JBQ1IsVUFBVSxFQUFFLFNBQVM7b0JBQ3JCLGtCQUFrQixFQUFFLElBQUk7aUJBQ3pCO2FBQ0YsQ0FBQyxDQUFBO1lBRUYsaUNBQWlDO1lBQ2pDLE1BQU0sb0JBQW9CLENBQUMsY0FBYyxDQUFDLFNBQVMsRUFBRTtnQkFDbkQsUUFBUSxFQUFFLEtBQUssQ0FBQyxFQUFFO2FBQ25CLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFFRCxvQ0FBb0M7UUFDcEMsTUFBTSxjQUFjLEdBQUcsTUFBTSxvQkFBb0IsQ0FBQyxvQkFBb0IsQ0FBQztZQUNyRSxNQUFNLEVBQUUsT0FBTyxDQUFDLFdBQVcsSUFBSSxPQUFPLENBQUMsZUFBZTtZQUN0RCxhQUFhLEVBQUUsS0FBSztZQUNwQixXQUFXLEVBQUUsU0FBUyxFQUFFLG1DQUFtQztZQUMzRCxJQUFJLEVBQUU7Z0JBQ0osVUFBVSxFQUFFLFNBQVM7Z0JBQ3JCLFdBQVcsRUFBRSxVQUFVO2FBQ3hCO1NBQ0YsQ0FBQyxDQUFBO1FBRUYsZ0JBQWdCO1FBQ2hCLE1BQU0sZUFBZSxDQUFDLElBQUksQ0FBQywyQkFBMkIsRUFBRTtZQUN0RCxVQUFVLEVBQUUsU0FBUztZQUNyQixXQUFXLEVBQUUsVUFBVTtZQUN2QixRQUFRLEVBQUUsS0FBSyxDQUFDLEVBQUU7WUFDbEIsTUFBTSxFQUFFLE9BQU8sQ0FBQyxXQUFXLElBQUksT0FBTyxDQUFDLGVBQWU7U0FDdkQsQ0FBQyxDQUFBO1FBRUYsT0FBTyxHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ2QsT0FBTyxFQUFFLDRCQUE0QjtZQUNyQyxPQUFPO1lBQ1AsS0FBSztZQUNMLGVBQWUsRUFBRSxjQUFjO1NBQ2hDLENBQUMsQ0FBQTtJQUVKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyw4QkFBOEIsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUVwRCxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSw2QkFBNkI7WUFDdEMsS0FBSyxFQUFFLEtBQUssQ0FBQyxPQUFPO1NBQ3JCLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=