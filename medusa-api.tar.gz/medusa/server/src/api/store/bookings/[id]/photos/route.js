"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AUTHENTICATE = void 0;
exports.POST = POST;
exports.GET = GET;
const service_photo_1 = require("../../../../../modules/service_photo");
const utils_1 = require("@medusajs/framework/utils");
exports.AUTHENTICATE = false;
/**
 * POST /store/bookings/:id/photos
 *
 * Upload de fotos do serviço (antes/depois)
 * Oficina documenta o trabalho realizado
 */
async function POST(req, res) {
    const { id: bookingId } = req.params;
    const { photo_type, caption } = req.body;
    const servicePhotoService = req.scope.resolve(service_photo_1.SERVICE_PHOTO_MODULE);
    const fileService = req.scope.resolve(utils_1.Modules.FILE);
    try {
        const files = req.files;
        if (!files || files.length === 0) {
            return res.status(400).json({
                message: "Nenhuma foto enviada"
            });
        }
        if (!photo_type) {
            return res.status(400).json({
                message: "Tipo de foto é obrigatório (before/after/parts/problem/inspection)"
            });
        }
        const uploadedPhotos = [];
        for (const file of files) {
            // Validações
            if (file.size > 10 * 1024 * 1024) {
                return res.status(400).json({
                    message: `Arquivo ${file.originalname} excede 10MB`
                });
            }
            if (!file.mimetype.startsWith('image/')) {
                return res.status(400).json({
                    message: `Arquivo deve ser uma imagem`
                });
            }
            // Upload para S3
            const uploaded = await fileService.uploadFile({
                filename: `bookings/${bookingId}/${photo_type}/${Date.now()}-${file.originalname}`,
                mimeType: file.mimetype,
                content: file.buffer,
            });
            // Salvar no banco
            const photo = await servicePhotoService.createServicePhotos({
                booking_id: bookingId,
                workshop_id: req.body.workshop_id,
                photo_type,
                url: uploaded.url,
                caption,
                taken_at: new Date(),
                uploaded_by: req.body.uploaded_by || 'workshop',
                file_size: file.size,
                mime_type: file.mimetype,
            });
            uploadedPhotos.push(photo);
        }
        return res.status(201).json({
            message: `${uploadedPhotos.length} foto(s) enviada(s) com sucesso`,
            photos: uploadedPhotos
        });
    }
    catch (error) {
        console.error("Erro ao fazer upload de fotos:", error);
        return res.status(500).json({
            message: "Erro ao fazer upload",
            error: error.message
        });
    }
}
/**
 * GET /store/bookings/:id/photos
 *
 * Lista todas as fotos de um agendamento
 */
async function GET(req, res) {
    const { id: bookingId } = req.params;
    const { photo_type } = req.query;
    const servicePhotoService = req.scope.resolve(service_photo_1.SERVICE_PHOTO_MODULE);
    try {
        const filters = { booking_id: bookingId };
        if (photo_type) {
            filters.photo_type = photo_type;
        }
        const photos = await servicePhotoService.listServicePhotos(filters, {
            order: { taken_at: "ASC" }
        });
        // Agrupar por tipo
        const grouped = {
            before: photos.filter(p => p.photo_type === 'before'),
            after: photos.filter(p => p.photo_type === 'after'),
            parts: photos.filter(p => p.photo_type === 'parts'),
            problem: photos.filter(p => p.photo_type === 'problem'),
            inspection: photos.filter(p => p.photo_type === 'inspection'),
        };
        return res.json({
            booking_id: bookingId,
            total_photos: photos.length,
            photos,
            grouped
        });
    }
    catch (error) {
        console.error("Erro ao listar fotos:", error);
        return res.status(500).json({
            message: "Erro ao listar fotos",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL2Jvb2tpbmdzL1tpZF0vcGhvdG9zL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQVlBLG9CQTZFQztBQU9ELGtCQTJDQztBQTFJRCx3RUFBMkU7QUFDM0UscURBQW1EO0FBRXRDLFFBQUEsWUFBWSxHQUFHLEtBQUssQ0FBQTtBQUVqQzs7Ozs7R0FLRztBQUNJLEtBQUssVUFBVSxJQUFJLENBQ3hCLEdBQWtCLEVBQ2xCLEdBQW1CO0lBRW5CLE1BQU0sRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQTtJQUNwQyxNQUFNLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUE7SUFFeEMsTUFBTSxtQkFBbUIsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxvQ0FBb0IsQ0FBQyxDQUFBO0lBQ25FLE1BQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGVBQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQTtJQUVuRCxJQUFJLENBQUM7UUFDSCxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsS0FBOEIsQ0FBQTtRQUVoRCxJQUFJLENBQUMsS0FBSyxJQUFJLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7WUFDakMsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDMUIsT0FBTyxFQUFFLHNCQUFzQjthQUNoQyxDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ2hCLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQzFCLE9BQU8sRUFBRSxvRUFBb0U7YUFDOUUsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUVELE1BQU0sY0FBYyxHQUFHLEVBQUUsQ0FBQTtRQUV6QixLQUFLLE1BQU0sSUFBSSxJQUFJLEtBQUssRUFBRSxDQUFDO1lBQ3pCLGFBQWE7WUFDYixJQUFJLElBQUksQ0FBQyxJQUFJLEdBQUcsRUFBRSxHQUFHLElBQUksR0FBRyxJQUFJLEVBQUUsQ0FBQztnQkFDakMsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztvQkFDMUIsT0FBTyxFQUFFLFdBQVcsSUFBSSxDQUFDLFlBQVksY0FBYztpQkFDcEQsQ0FBQyxDQUFBO1lBQ0osQ0FBQztZQUVELElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDO2dCQUN4QyxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO29CQUMxQixPQUFPLEVBQUUsNkJBQTZCO2lCQUN2QyxDQUFDLENBQUE7WUFDSixDQUFDO1lBRUQsaUJBQWlCO1lBQ2pCLE1BQU0sUUFBUSxHQUFHLE1BQU0sV0FBVyxDQUFDLFVBQVUsQ0FBQztnQkFDNUMsUUFBUSxFQUFFLFlBQVksU0FBUyxJQUFJLFVBQVUsSUFBSSxJQUFJLENBQUMsR0FBRyxFQUFFLElBQUksSUFBSSxDQUFDLFlBQVksRUFBRTtnQkFDbEYsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRO2dCQUN2QixPQUFPLEVBQUUsSUFBSSxDQUFDLE1BQU07YUFDckIsQ0FBQyxDQUFBO1lBRUYsa0JBQWtCO1lBQ2xCLE1BQU0sS0FBSyxHQUFHLE1BQU0sbUJBQW1CLENBQUMsbUJBQW1CLENBQUM7Z0JBQzFELFVBQVUsRUFBRSxTQUFTO2dCQUNyQixXQUFXLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXO2dCQUNqQyxVQUFVO2dCQUNWLEdBQUcsRUFBRSxRQUFRLENBQUMsR0FBRztnQkFDakIsT0FBTztnQkFDUCxRQUFRLEVBQUUsSUFBSSxJQUFJLEVBQUU7Z0JBQ3BCLFdBQVcsRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLFdBQVcsSUFBSSxVQUFVO2dCQUMvQyxTQUFTLEVBQUUsSUFBSSxDQUFDLElBQUk7Z0JBQ3BCLFNBQVMsRUFBRSxJQUFJLENBQUMsUUFBUTthQUN6QixDQUFDLENBQUE7WUFFRixjQUFjLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFBO1FBQzVCLENBQUM7UUFFRCxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSxHQUFHLGNBQWMsQ0FBQyxNQUFNLGlDQUFpQztZQUNsRSxNQUFNLEVBQUUsY0FBYztTQUN2QixDQUFDLENBQUE7SUFFSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsZ0NBQWdDLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFFdEQsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsc0JBQXNCO1lBQy9CLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTztTQUNyQixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQztBQUVEOzs7O0dBSUc7QUFDSSxLQUFLLFVBQVUsR0FBRyxDQUN2QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixNQUFNLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUE7SUFDcEMsTUFBTSxFQUFFLFVBQVUsRUFBRSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUE7SUFFaEMsTUFBTSxtQkFBbUIsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxvQ0FBb0IsQ0FBQyxDQUFBO0lBRW5FLElBQUksQ0FBQztRQUNILE1BQU0sT0FBTyxHQUFRLEVBQUUsVUFBVSxFQUFFLFNBQVMsRUFBRSxDQUFBO1FBRTlDLElBQUksVUFBVSxFQUFFLENBQUM7WUFDZixPQUFPLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQTtRQUNqQyxDQUFDO1FBRUQsTUFBTSxNQUFNLEdBQUcsTUFBTSxtQkFBbUIsQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEVBQUU7WUFDbEUsS0FBSyxFQUFFLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRTtTQUMzQixDQUFDLENBQUE7UUFFRixtQkFBbUI7UUFDbkIsTUFBTSxPQUFPLEdBQUc7WUFDZCxNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxVQUFVLEtBQUssUUFBUSxDQUFDO1lBQ3JELEtBQUssRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFVBQVUsS0FBSyxPQUFPLENBQUM7WUFDbkQsS0FBSyxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsVUFBVSxLQUFLLE9BQU8sQ0FBQztZQUNuRCxPQUFPLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxVQUFVLEtBQUssU0FBUyxDQUFDO1lBQ3ZELFVBQVUsRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFVBQVUsS0FBSyxZQUFZLENBQUM7U0FDOUQsQ0FBQTtRQUVELE9BQU8sR0FBRyxDQUFDLElBQUksQ0FBQztZQUNkLFVBQVUsRUFBRSxTQUFTO1lBQ3JCLFlBQVksRUFBRSxNQUFNLENBQUMsTUFBTTtZQUMzQixNQUFNO1lBQ04sT0FBTztTQUNSLENBQUMsQ0FBQTtJQUVKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyx1QkFBdUIsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUM3QyxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSxzQkFBc0I7WUFDL0IsS0FBSyxFQUFFLEtBQUssQ0FBQyxPQUFPO1NBQ3JCLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=