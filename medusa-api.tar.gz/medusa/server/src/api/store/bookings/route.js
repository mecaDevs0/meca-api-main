"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.POST = POST;
const utils_1 = require("@medusajs/framework/utils");
const booking_1 = require("../../../modules/booking");
const vehicle_1 = require("../../../modules/vehicle");
const oficina_1 = require("../../../modules/oficina");
const booking_2 = require("../../../modules/booking/models/booking");
/**
 * GET /store/bookings
 *
 * Lista todos os agendamentos do cliente autenticado
 */
async function GET(req, res) {
    const bookingModuleService = req.scope.resolve(booking_1.BOOKING_MODULE);
    const customerId = req.auth_context?.actor_id;
    if (!customerId) {
        return res.status(401).json({ message: "Não autenticado" });
    }
    try {
        const { status, limit = 50, offset = 0 } = req.query;
        const filters = {
            customer_id: customerId
        };
        if (status) {
            filters.status = status;
        }
        const bookings = await bookingModuleService.listBookings(filters, {
            take: Number(limit),
            skip: Number(offset),
            order: { appointment_date: "DESC" }
        });
        return res.json({
            bookings,
            count: bookings.length,
        });
    }
    catch (error) {
        console.error("Erro ao listar agendamentos:", error);
        return res.status(500).json({
            message: "Erro ao listar agendamentos",
            error: error.message
        });
    }
}
/**
 * POST /store/bookings
 *
 * Cria um novo agendamento (fluxo principal do cliente)
 *
 * Body:
 * - vehicle_id: ID do veículo
 * - product_id: ID do serviço (Product)
 * - oficina_id: ID da oficina
 * - appointment_date: Data e hora do agendamento
 * - customer_notes: Observações do cliente (opcional)
 */
async function POST(req, res) {
    const bookingModuleService = req.scope.resolve(booking_1.BOOKING_MODULE);
    const vehicleModuleService = req.scope.resolve(vehicle_1.VEHICLE_MODULE);
    const oficinaModuleService = req.scope.resolve(oficina_1.OFICINA_MODULE);
    const productModuleService = req.scope.resolve(utils_1.Modules.PRODUCT);
    const cartModuleService = req.scope.resolve(utils_1.Modules.CART);
    const eventBusService = req.scope.resolve("eventBus");
    const customerId = req.auth_context?.actor_id;
    if (!customerId) {
        return res.status(401).json({ message: "Não autenticado" });
    }
    const { vehicle_id, product_id, oficina_id, appointment_date, customer_notes } = req.body;
    // Validações
    if (!vehicle_id || !product_id || !oficina_id || !appointment_date) {
        return res.status(400).json({
            message: "vehicle_id, product_id, oficina_id e appointment_date são obrigatórios"
        });
    }
    try {
        // 1. Validar que o veículo pertence ao cliente
        const vehicle = await vehicleModuleService.retrieveVehicle(vehicle_id);
        if (vehicle.customer_id !== customerId) {
            return res.status(403).json({
                message: "Este veículo não pertence a você"
            });
        }
        // 2. Validar que a oficina existe e está aprovada
        const oficina = await oficinaModuleService.retrieveOficina(oficina_id);
        if (oficina.status !== "aprovado") {
            return res.status(400).json({
                message: "Esta oficina não está disponível para agendamentos"
            });
        }
        // 3. Buscar o produto/serviço
        const product = await productModuleService.retrieveProduct(product_id, {
            relations: ["variants"]
        });
        if (!product || !product.variants || product.variants.length === 0) {
            return res.status(404).json({
                message: "Serviço não encontrado"
            });
        }
        const variant = product.variants[0];
        const price = variant.calculated_price?.amount || 0;
        // 4. Criar snapshot do veículo
        const vehicleSnapshot = {
            marca: vehicle.marca,
            modelo: vehicle.modelo,
            ano: vehicle.ano,
            placa: vehicle.placa,
            km_atual: vehicle.km_atual
        };
        // 5. Criar o Booking
        const booking = await bookingModuleService.createBookings({
            customer_id: customerId,
            vehicle_id,
            oficina_id,
            product_id,
            appointment_date: new Date(appointment_date),
            status: booking_2.BookingStatus.PENDENTE_OFICINA,
            vehicle_snapshot: vehicleSnapshot,
            customer_notes,
            estimated_price: price,
        });
        // 6. Criar Cart para este agendamento
        const cart = await cartModuleService.createCarts({
            currency_code: "brl",
            email: req.auth_context?.actor_email || "",
            metadata: {
                booking_id: booking.id,
                is_booking: true,
            }
        });
        // 7. Adicionar item ao carrinho
        await cartModuleService.addLineItems(cart.id, [{
                variant_id: variant.id,
                quantity: 1,
            }]);
        // 8. Emitir evento para notificar a oficina
        await eventBusService.emit("booking.created", {
            booking_id: booking.id,
            customer_id: customerId,
            oficina_id,
            product_id,
            appointment_date,
        });
        return res.status(201).json({
            message: "Agendamento criado com sucesso! Aguardando confirmação da oficina.",
            booking,
            cart_id: cart.id,
        });
    }
    catch (error) {
        console.error("Erro ao criar agendamento:", error);
        return res.status(500).json({
            message: "Erro ao criar agendamento",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL2Jvb2tpbmdzL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBWUEsa0JBeUNDO0FBY0Qsb0JBOEhDO0FBaE1ELHFEQUFtRDtBQUNuRCxzREFBeUQ7QUFDekQsc0RBQXlEO0FBQ3pELHNEQUF5RDtBQUN6RCxxRUFBdUU7QUFFdkU7Ozs7R0FJRztBQUNJLEtBQUssVUFBVSxHQUFHLENBQ3ZCLEdBQWtCLEVBQ2xCLEdBQW1CO0lBRW5CLE1BQU0sb0JBQW9CLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsd0JBQWMsQ0FBQyxDQUFBO0lBQzlELE1BQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQyxZQUFZLEVBQUUsUUFBUSxDQUFBO0lBRTdDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNoQixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLGlCQUFpQixFQUFFLENBQUMsQ0FBQTtJQUM3RCxDQUFDO0lBRUQsSUFBSSxDQUFDO1FBQ0gsTUFBTSxFQUFFLE1BQU0sRUFBRSxLQUFLLEdBQUcsRUFBRSxFQUFFLE1BQU0sR0FBRyxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFBO1FBRXBELE1BQU0sT0FBTyxHQUFRO1lBQ25CLFdBQVcsRUFBRSxVQUFVO1NBQ3hCLENBQUE7UUFFRCxJQUFJLE1BQU0sRUFBRSxDQUFDO1lBQ1gsT0FBTyxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUE7UUFDekIsQ0FBQztRQUVELE1BQU0sUUFBUSxHQUFHLE1BQU0sb0JBQW9CLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRTtZQUNoRSxJQUFJLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQztZQUNuQixJQUFJLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQztZQUNwQixLQUFLLEVBQUUsRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLEVBQUU7U0FDcEMsQ0FBQyxDQUFBO1FBRUYsT0FBTyxHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ2QsUUFBUTtZQUNSLEtBQUssRUFBRSxRQUFRLENBQUMsTUFBTTtTQUN2QixDQUFDLENBQUE7SUFFSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsOEJBQThCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFFcEQsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsNkJBQTZCO1lBQ3RDLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTztTQUNyQixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQztBQUVEOzs7Ozs7Ozs7OztHQVdHO0FBQ0ksS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsTUFBTSxvQkFBb0IsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyx3QkFBYyxDQUFDLENBQUE7SUFDOUQsTUFBTSxvQkFBb0IsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyx3QkFBYyxDQUFDLENBQUE7SUFDOUQsTUFBTSxvQkFBb0IsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyx3QkFBYyxDQUFDLENBQUE7SUFDOUQsTUFBTSxvQkFBb0IsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsT0FBTyxDQUFDLENBQUE7SUFDL0QsTUFBTSxpQkFBaUIsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsSUFBSSxDQUFDLENBQUE7SUFDekQsTUFBTSxlQUFlLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUE7SUFFckQsTUFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDLFlBQVksRUFBRSxRQUFRLENBQUE7SUFFN0MsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2hCLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsQ0FBQyxDQUFBO0lBQzdELENBQUM7SUFFRCxNQUFNLEVBQ0osVUFBVSxFQUNWLFVBQVUsRUFDVixVQUFVLEVBQ1YsZ0JBQWdCLEVBQ2hCLGNBQWMsRUFDZixHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUE7SUFFWixhQUFhO0lBQ2IsSUFBSSxDQUFDLFVBQVUsSUFBSSxDQUFDLFVBQVUsSUFBSSxDQUFDLFVBQVUsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDbkUsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsd0VBQXdFO1NBQ2xGLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxJQUFJLENBQUM7UUFDSCwrQ0FBK0M7UUFDL0MsTUFBTSxPQUFPLEdBQUcsTUFBTSxvQkFBb0IsQ0FBQyxlQUFlLENBQUMsVUFBVSxDQUFDLENBQUE7UUFFdEUsSUFBSSxPQUFPLENBQUMsV0FBVyxLQUFLLFVBQVUsRUFBRSxDQUFDO1lBQ3ZDLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQzFCLE9BQU8sRUFBRSxrQ0FBa0M7YUFDNUMsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUVELGtEQUFrRDtRQUNsRCxNQUFNLE9BQU8sR0FBRyxNQUFNLG9CQUFvQixDQUFDLGVBQWUsQ0FBQyxVQUFVLENBQUMsQ0FBQTtRQUV0RSxJQUFJLE9BQU8sQ0FBQyxNQUFNLEtBQUssVUFBVSxFQUFFLENBQUM7WUFDbEMsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDMUIsT0FBTyxFQUFFLG9EQUFvRDthQUM5RCxDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQsOEJBQThCO1FBQzlCLE1BQU0sT0FBTyxHQUFHLE1BQU0sb0JBQW9CLENBQUMsZUFBZSxDQUFDLFVBQVUsRUFBRTtZQUNyRSxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7U0FDeEIsQ0FBQyxDQUFBO1FBRUYsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLElBQUksT0FBTyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7WUFDbkUsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDMUIsT0FBTyxFQUFFLHdCQUF3QjthQUNsQyxDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQTtRQUNuQyxNQUFNLEtBQUssR0FBRyxPQUFPLENBQUMsZ0JBQWdCLEVBQUUsTUFBTSxJQUFJLENBQUMsQ0FBQTtRQUVuRCwrQkFBK0I7UUFDL0IsTUFBTSxlQUFlLEdBQUc7WUFDdEIsS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFLO1lBQ3BCLE1BQU0sRUFBRSxPQUFPLENBQUMsTUFBTTtZQUN0QixHQUFHLEVBQUUsT0FBTyxDQUFDLEdBQUc7WUFDaEIsS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFLO1lBQ3BCLFFBQVEsRUFBRSxPQUFPLENBQUMsUUFBUTtTQUMzQixDQUFBO1FBRUQscUJBQXFCO1FBQ3JCLE1BQU0sT0FBTyxHQUFHLE1BQU0sb0JBQW9CLENBQUMsY0FBYyxDQUFDO1lBQ3hELFdBQVcsRUFBRSxVQUFVO1lBQ3ZCLFVBQVU7WUFDVixVQUFVO1lBQ1YsVUFBVTtZQUNWLGdCQUFnQixFQUFFLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDO1lBQzVDLE1BQU0sRUFBRSx1QkFBYSxDQUFDLGdCQUFnQjtZQUN0QyxnQkFBZ0IsRUFBRSxlQUFlO1lBQ2pDLGNBQWM7WUFDZCxlQUFlLEVBQUUsS0FBSztTQUN2QixDQUFDLENBQUE7UUFFRixzQ0FBc0M7UUFDdEMsTUFBTSxJQUFJLEdBQUcsTUFBTSxpQkFBaUIsQ0FBQyxXQUFXLENBQUM7WUFDL0MsYUFBYSxFQUFFLEtBQUs7WUFDcEIsS0FBSyxFQUFFLEdBQUcsQ0FBQyxZQUFZLEVBQUUsV0FBVyxJQUFJLEVBQUU7WUFDMUMsUUFBUSxFQUFFO2dCQUNSLFVBQVUsRUFBRSxPQUFPLENBQUMsRUFBRTtnQkFDdEIsVUFBVSxFQUFFLElBQUk7YUFDakI7U0FDRixDQUFDLENBQUE7UUFFRixnQ0FBZ0M7UUFDaEMsTUFBTSxpQkFBaUIsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDO2dCQUM3QyxVQUFVLEVBQUUsT0FBTyxDQUFDLEVBQUU7Z0JBQ3RCLFFBQVEsRUFBRSxDQUFDO2FBQ1osQ0FBQyxDQUFDLENBQUE7UUFFSCw0Q0FBNEM7UUFDNUMsTUFBTSxlQUFlLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFO1lBQzVDLFVBQVUsRUFBRSxPQUFPLENBQUMsRUFBRTtZQUN0QixXQUFXLEVBQUUsVUFBVTtZQUN2QixVQUFVO1lBQ1YsVUFBVTtZQUNWLGdCQUFnQjtTQUNqQixDQUFDLENBQUE7UUFFRixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSxvRUFBb0U7WUFDN0UsT0FBTztZQUNQLE9BQU8sRUFBRSxJQUFJLENBQUMsRUFBRTtTQUNqQixDQUFDLENBQUE7SUFFSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsNEJBQTRCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFFbEQsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsMkJBQTJCO1lBQ3BDLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTztTQUNyQixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9