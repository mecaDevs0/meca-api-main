"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.POST = POST;
const review_1 = require("../../../modules/review");
const booking_1 = require("../../../modules/booking");
const booking_2 = require("../../../modules/booking/models/booking");
/**
 * GET /store/reviews?oficina_id={id}
 *
 * Lista avaliações de uma oficina
 */
async function GET(req, res) {
    const reviewModuleService = req.scope.resolve(review_1.REVIEW_MODULE);
    const { oficina_id, limit = 20, offset = 0 } = req.query;
    if (!oficina_id) {
        return res.status(400).json({
            message: "oficina_id é obrigatório"
        });
    }
    try {
        const reviews = await reviewModuleService.listReviews({
            oficina_id,
            is_approved: true,
        }, {
            take: Number(limit),
            skip: Number(offset),
            order: { created_at: "DESC" }
        });
        // Calcular média de avaliações
        const avgRating = reviews.length > 0
            ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length
            : 0;
        return res.json({
            reviews,
            count: reviews.length,
            average_rating: Number(avgRating.toFixed(1)),
        });
    }
    catch (error) {
        console.error("Erro ao listar avaliações:", error);
        return res.status(500).json({
            message: "Erro ao listar avaliações",
            error: error.message
        });
    }
}
/**
 * POST /store/reviews
 *
 * Cliente cria uma avaliação após serviço finalizado
 */
async function POST(req, res) {
    const reviewModuleService = req.scope.resolve(review_1.REVIEW_MODULE);
    const bookingModuleService = req.scope.resolve(booking_1.BOOKING_MODULE);
    const customerId = req.auth_context?.actor_id;
    if (!customerId) {
        return res.status(401).json({ message: "Não autenticado" });
    }
    const { booking_id, rating, title, comment } = req.body;
    // Validações
    if (!booking_id || !rating) {
        return res.status(400).json({
            message: "booking_id e rating são obrigatórios"
        });
    }
    if (rating < 1 || rating > 5) {
        return res.status(400).json({
            message: "Rating deve ser entre 1 e 5"
        });
    }
    try {
        // Buscar booking
        const booking = await bookingModuleService.retrieveBooking(booking_id);
        // Verificar se booking pertence ao cliente
        if (booking.customer_id !== customerId) {
            return res.status(403).json({ message: "Acesso negado" });
        }
        // Verificar se serviço foi finalizado
        if (booking.status !== booking_2.BookingStatus.FINALIZADO_CLIENTE &&
            booking.status !== booking_2.BookingStatus.FINALIZADO_MECANICO) {
            return res.status(400).json({
                message: "Só é possível avaliar serviços finalizados"
            });
        }
        // Verificar se já existe avaliação para este booking
        const existingReview = await reviewModuleService.listReviews({ booking_id });
        if (existingReview.length > 0) {
            return res.status(400).json({
                message: "Você já avaliou este serviço"
            });
        }
        // Criar avaliação
        const review = await reviewModuleService.createReviews({
            customer_id: customerId,
            oficina_id: booking.oficina_id,
            booking_id,
            product_id: booking.product_id,
            rating,
            title,
            comment,
            is_approved: true, // Auto-aprovar por padrão
        });
        return res.status(201).json({
            message: "Avaliação criada com sucesso",
            review
        });
    }
    catch (error) {
        console.error("Erro ao criar avaliação:", error);
        return res.status(500).json({
            message: "Erro ao criar avaliação",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3Jldmlld3Mvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFVQSxrQkEyQ0M7QUFPRCxvQkFvRkM7QUEvSUQsb0RBQXVEO0FBQ3ZELHNEQUF5RDtBQUN6RCxxRUFBdUU7QUFFdkU7Ozs7R0FJRztBQUNJLEtBQUssVUFBVSxHQUFHLENBQ3ZCLEdBQWtCLEVBQ2xCLEdBQW1CO0lBRW5CLE1BQU0sbUJBQW1CLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsc0JBQWEsQ0FBQyxDQUFBO0lBRTVELE1BQU0sRUFBRSxVQUFVLEVBQUUsS0FBSyxHQUFHLEVBQUUsRUFBRSxNQUFNLEdBQUcsQ0FBQyxFQUFFLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQTtJQUV4RCxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDaEIsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsMEJBQTBCO1NBQ3BDLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxJQUFJLENBQUM7UUFDSCxNQUFNLE9BQU8sR0FBRyxNQUFNLG1CQUFtQixDQUFDLFdBQVcsQ0FBQztZQUNwRCxVQUFVO1lBQ1YsV0FBVyxFQUFFLElBQUk7U0FDbEIsRUFBRTtZQUNELElBQUksRUFBRSxNQUFNLENBQUMsS0FBSyxDQUFDO1lBQ25CLElBQUksRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDO1lBQ3BCLEtBQUssRUFBRSxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUU7U0FDOUIsQ0FBQyxDQUFBO1FBRUYsK0JBQStCO1FBQy9CLE1BQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQztZQUNsQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxNQUFNO1lBQ2hFLENBQUMsQ0FBQyxDQUFDLENBQUE7UUFFTCxPQUFPLEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDZCxPQUFPO1lBQ1AsS0FBSyxFQUFFLE9BQU8sQ0FBQyxNQUFNO1lBQ3JCLGNBQWMsRUFBRSxNQUFNLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUM3QyxDQUFDLENBQUE7SUFFSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsNEJBQTRCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFFbEQsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsMkJBQTJCO1lBQ3BDLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTztTQUNyQixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQztBQUVEOzs7O0dBSUc7QUFDSSxLQUFLLFVBQVUsSUFBSSxDQUN4QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixNQUFNLG1CQUFtQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHNCQUFhLENBQUMsQ0FBQTtJQUM1RCxNQUFNLG9CQUFvQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHdCQUFjLENBQUMsQ0FBQTtJQUU5RCxNQUFNLFVBQVUsR0FBRyxHQUFHLENBQUMsWUFBWSxFQUFFLFFBQVEsQ0FBQTtJQUU3QyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDaEIsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxDQUFDLENBQUE7SUFDN0QsQ0FBQztJQUVELE1BQU0sRUFDSixVQUFVLEVBQ1YsTUFBTSxFQUNOLEtBQUssRUFDTCxPQUFPLEVBQ1IsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFBO0lBRVosYUFBYTtJQUNiLElBQUksQ0FBQyxVQUFVLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUMzQixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSxzQ0FBc0M7U0FDaEQsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVELElBQUksTUFBTSxHQUFHLENBQUMsSUFBSSxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7UUFDN0IsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsNkJBQTZCO1NBQ3ZDLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxJQUFJLENBQUM7UUFDSCxpQkFBaUI7UUFDakIsTUFBTSxPQUFPLEdBQUcsTUFBTSxvQkFBb0IsQ0FBQyxlQUFlLENBQUMsVUFBVSxDQUFDLENBQUE7UUFFdEUsMkNBQTJDO1FBQzNDLElBQUksT0FBTyxDQUFDLFdBQVcsS0FBSyxVQUFVLEVBQUUsQ0FBQztZQUN2QyxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLGVBQWUsRUFBRSxDQUFDLENBQUE7UUFDM0QsQ0FBQztRQUVELHNDQUFzQztRQUN0QyxJQUFJLE9BQU8sQ0FBQyxNQUFNLEtBQUssdUJBQWEsQ0FBQyxrQkFBa0I7WUFDbkQsT0FBTyxDQUFDLE1BQU0sS0FBSyx1QkFBYSxDQUFDLG1CQUFtQixFQUFFLENBQUM7WUFDekQsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDMUIsT0FBTyxFQUFFLDRDQUE0QzthQUN0RCxDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQscURBQXFEO1FBQ3JELE1BQU0sY0FBYyxHQUFHLE1BQU0sbUJBQW1CLENBQUMsV0FBVyxDQUFDLEVBQUUsVUFBVSxFQUFFLENBQUMsQ0FBQTtRQUU1RSxJQUFJLGNBQWMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDOUIsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDMUIsT0FBTyxFQUFFLDhCQUE4QjthQUN4QyxDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQsa0JBQWtCO1FBQ2xCLE1BQU0sTUFBTSxHQUFHLE1BQU0sbUJBQW1CLENBQUMsYUFBYSxDQUFDO1lBQ3JELFdBQVcsRUFBRSxVQUFVO1lBQ3ZCLFVBQVUsRUFBRSxPQUFPLENBQUMsVUFBVTtZQUM5QixVQUFVO1lBQ1YsVUFBVSxFQUFFLE9BQU8sQ0FBQyxVQUFVO1lBQzlCLE1BQU07WUFDTixLQUFLO1lBQ0wsT0FBTztZQUNQLFdBQVcsRUFBRSxJQUFJLEVBQUUsMEJBQTBCO1NBQzlDLENBQUMsQ0FBQTtRQUVGLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLDhCQUE4QjtZQUN2QyxNQUFNO1NBQ1AsQ0FBQyxDQUFBO0lBRUosQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLDBCQUEwQixFQUFFLEtBQUssQ0FBQyxDQUFBO1FBRWhELE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLHlCQUF5QjtZQUNsQyxLQUFLLEVBQUUsS0FBSyxDQUFDLE9BQU87U0FDckIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUMifQ==