"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const fcm_notification_1 = require("../../../modules/fcm_notification");
/**
 * POST /store/device-tokens
 *
 * Registra ou atualiza um token de dispositivo FCM para o usuário autenticado
 *
 * Body:
 * - fcm_token: Token do FCM
 * - platform: "android" ou "ios"
 * - device_name: Nome do dispositivo (opcional)
 * - app_version: Versão do app (opcional)
 */
async function POST(req, res) {
    const fcmService = req.scope.resolve(fcm_notification_1.FCM_MODULE);
    const userId = req.auth_context?.actor_id;
    const actorType = req.auth_context?.actor_type; // "customer" ou "user"
    if (!userId) {
        return res.status(401).json({ message: "Não autenticado" });
    }
    const { fcm_token, platform, device_name, app_version } = req.body;
    if (!fcm_token || !platform) {
        return res.status(400).json({
            message: "fcm_token e platform são obrigatórios"
        });
    }
    try {
        const isCustomer = actorType === "customer";
        const deviceToken = await fcmService.registerDeviceToken(userId, isCustomer, fcm_token, platform, device_name);
        return res.status(201).json({
            message: "Token de dispositivo registrado com sucesso",
            device_token: deviceToken
        });
    }
    catch (error) {
        console.error("Erro ao registrar token:", error);
        return res.status(500).json({
            message: "Erro ao registrar token de dispositivo",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL2RldmljZS10b2tlbnMvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFjQSxvQkFrREM7QUEvREQsd0VBQThEO0FBRTlEOzs7Ozs7Ozs7O0dBVUc7QUFDSSxLQUFLLFVBQVUsSUFBSSxDQUN4QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixNQUFNLFVBQVUsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyw2QkFBVSxDQUFDLENBQUE7SUFFaEQsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFlBQVksRUFBRSxRQUFRLENBQUE7SUFDekMsTUFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLFlBQVksRUFBRSxVQUFVLENBQUEsQ0FBQyx1QkFBdUI7SUFFdEUsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ1osT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxDQUFDLENBQUE7SUFDN0QsQ0FBQztJQUVELE1BQU0sRUFDSixTQUFTLEVBQ1QsUUFBUSxFQUNSLFdBQVcsRUFDWCxXQUFXLEVBQ1osR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFBO0lBRVosSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQzVCLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLHVDQUF1QztTQUNqRCxDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsSUFBSSxDQUFDO1FBQ0gsTUFBTSxVQUFVLEdBQUcsU0FBUyxLQUFLLFVBQVUsQ0FBQTtRQUUzQyxNQUFNLFdBQVcsR0FBRyxNQUFNLFVBQVUsQ0FBQyxtQkFBbUIsQ0FDdEQsTUFBTSxFQUNOLFVBQVUsRUFDVixTQUFTLEVBQ1QsUUFBUSxFQUNSLFdBQVcsQ0FDWixDQUFBO1FBRUQsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsNkNBQTZDO1lBQ3RELFlBQVksRUFBRSxXQUFXO1NBQzFCLENBQUMsQ0FBQTtJQUVKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQywwQkFBMEIsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUVoRCxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSx3Q0FBd0M7WUFDakQsS0FBSyxFQUFFLEtBQUssQ0FBQyxPQUFPO1NBQ3JCLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=