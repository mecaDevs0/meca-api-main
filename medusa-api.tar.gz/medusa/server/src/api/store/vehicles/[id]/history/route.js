"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AUTHENTICATE = void 0;
exports.GET = GET;
const vehicle_history_1 = require("../../../../../modules/vehicle_history");
exports.AUTHENTICATE = false;
/**
 * GET /store/vehicles/:id/history
 *
 * Retorna histórico completo de manutenção de um veículo
 * Timeline ordenada cronologicamente
 */
async function GET(req, res) {
    const { id } = req.params;
    const vehicleHistoryService = req.scope.resolve(vehicle_history_1.VEHICLE_HISTORY_MODULE);
    try {
        const history = await vehicleHistoryService.listVehicleHistories({ vehicle_id: id }, {
            select: [
                "id",
                "service_name",
                "workshop_name",
                "service_date",
                "odometer_reading",
                "next_service_km",
                "next_service_date",
                "notes",
                "parts_replaced",
                "parts_cost",
                "labor_cost",
                "total_cost",
                "warranty_months",
                "warranty_expires_at"
            ],
            order: { service_date: "DESC" }
        });
        // Calcular próximas manutenções recomendadas
        const recommendations = calculateMaintenanceRecommendations(history);
        return res.json({
            vehicle_id: id,
            total_services: history.length,
            history,
            recommendations,
            last_service: history[0] || null
        });
    }
    catch (error) {
        console.error("Erro ao buscar histórico:", error);
        return res.status(500).json({
            message: "Erro ao buscar histórico",
            error: error.message
        });
    }
}
function calculateMaintenanceRecommendations(history) {
    if (!history || history.length === 0) {
        return [
            {
                type: "oil_change",
                urgency: "medium",
                message: "Recomendamos fazer a primeira revisão"
            }
        ];
    }
    const recommendations = [];
    const lastService = history[0];
    const now = new Date();
    // Verificar garantias expirando
    history.forEach(service => {
        if (service.warranty_expires_at) {
            const expiryDate = new Date(service.warranty_expires_at);
            const daysUntilExpiry = Math.floor((expiryDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
            if (daysUntilExpiry > 0 && daysUntilExpiry <= 30) {
                recommendations.push({
                    type: "warranty_expiring",
                    urgency: "high",
                    message: `Garantia de "${service.service_name}" expira em ${daysUntilExpiry} dias`,
                    service_id: service.id
                });
            }
        }
    });
    // Verificar manutenção periódica
    if (lastService.next_service_date) {
        const nextDate = new Date(lastService.next_service_date);
        const daysUntilNext = Math.floor((nextDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
        if (daysUntilNext <= 7) {
            recommendations.push({
                type: "service_due",
                urgency: "high",
                message: `Próxima manutenção recomendada em ${daysUntilNext} dias`,
                due_date: lastService.next_service_date
            });
        }
    }
    return recommendations;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3ZlaGljbGVzL1tpZF0vaGlzdG9yeS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFXQSxrQkFpREM7QUEzREQsNEVBQStFO0FBRWxFLFFBQUEsWUFBWSxHQUFHLEtBQUssQ0FBQTtBQUVqQzs7Ozs7R0FLRztBQUNJLEtBQUssVUFBVSxHQUFHLENBQ3ZCLEdBQWtCLEVBQ2xCLEdBQW1CO0lBRW5CLE1BQU0sRUFBRSxFQUFFLEVBQUUsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFBO0lBQ3pCLE1BQU0scUJBQXFCLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsd0NBQXNCLENBQUMsQ0FBQTtJQUV2RSxJQUFJLENBQUM7UUFDSCxNQUFNLE9BQU8sR0FBRyxNQUFNLHFCQUFxQixDQUFDLG9CQUFvQixDQUM5RCxFQUFFLFVBQVUsRUFBRSxFQUFFLEVBQUUsRUFDbEI7WUFDRSxNQUFNLEVBQUU7Z0JBQ04sSUFBSTtnQkFDSixjQUFjO2dCQUNkLGVBQWU7Z0JBQ2YsY0FBYztnQkFDZCxrQkFBa0I7Z0JBQ2xCLGlCQUFpQjtnQkFDakIsbUJBQW1CO2dCQUNuQixPQUFPO2dCQUNQLGdCQUFnQjtnQkFDaEIsWUFBWTtnQkFDWixZQUFZO2dCQUNaLFlBQVk7Z0JBQ1osaUJBQWlCO2dCQUNqQixxQkFBcUI7YUFDdEI7WUFDRCxLQUFLLEVBQUUsRUFBRSxZQUFZLEVBQUUsTUFBTSxFQUFFO1NBQ2hDLENBQ0YsQ0FBQTtRQUVELDZDQUE2QztRQUM3QyxNQUFNLGVBQWUsR0FBRyxtQ0FBbUMsQ0FBQyxPQUFPLENBQUMsQ0FBQTtRQUVwRSxPQUFPLEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDZCxVQUFVLEVBQUUsRUFBRTtZQUNkLGNBQWMsRUFBRSxPQUFPLENBQUMsTUFBTTtZQUM5QixPQUFPO1lBQ1AsZUFBZTtZQUNmLFlBQVksRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSTtTQUNqQyxDQUFDLENBQUE7SUFFSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsMkJBQTJCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDakQsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsMEJBQTBCO1lBQ25DLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTztTQUNyQixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQztBQUVELFNBQVMsbUNBQW1DLENBQUMsT0FBYztJQUN6RCxJQUFJLENBQUMsT0FBTyxJQUFJLE9BQU8sQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7UUFDckMsT0FBTztZQUNMO2dCQUNFLElBQUksRUFBRSxZQUFZO2dCQUNsQixPQUFPLEVBQUUsUUFBUTtnQkFDakIsT0FBTyxFQUFFLHVDQUF1QzthQUNqRDtTQUNGLENBQUE7SUFDSCxDQUFDO0lBRUQsTUFBTSxlQUFlLEdBQUcsRUFBRSxDQUFBO0lBQzFCLE1BQU0sV0FBVyxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQTtJQUM5QixNQUFNLEdBQUcsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFBO0lBRXRCLGdDQUFnQztJQUNoQyxPQUFPLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFO1FBQ3hCLElBQUksT0FBTyxDQUFDLG1CQUFtQixFQUFFLENBQUM7WUFDaEMsTUFBTSxVQUFVLEdBQUcsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUE7WUFDeEQsTUFBTSxlQUFlLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsR0FBRyxHQUFHLENBQUMsT0FBTyxFQUFFLENBQUMsR0FBRyxDQUFDLElBQUksR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUE7WUFFbEcsSUFBSSxlQUFlLEdBQUcsQ0FBQyxJQUFJLGVBQWUsSUFBSSxFQUFFLEVBQUUsQ0FBQztnQkFDakQsZUFBZSxDQUFDLElBQUksQ0FBQztvQkFDbkIsSUFBSSxFQUFFLG1CQUFtQjtvQkFDekIsT0FBTyxFQUFFLE1BQU07b0JBQ2YsT0FBTyxFQUFFLGdCQUFnQixPQUFPLENBQUMsWUFBWSxlQUFlLGVBQWUsT0FBTztvQkFDbEYsVUFBVSxFQUFFLE9BQU8sQ0FBQyxFQUFFO2lCQUN2QixDQUFDLENBQUE7WUFDSixDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUMsQ0FBQyxDQUFBO0lBRUYsaUNBQWlDO0lBQ2pDLElBQUksV0FBVyxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDbEMsTUFBTSxRQUFRLEdBQUcsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLGlCQUFpQixDQUFDLENBQUE7UUFDeEQsTUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsR0FBRyxHQUFHLENBQUMsT0FBTyxFQUFFLENBQUMsR0FBRyxDQUFDLElBQUksR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUE7UUFFOUYsSUFBSSxhQUFhLElBQUksQ0FBQyxFQUFFLENBQUM7WUFDdkIsZUFBZSxDQUFDLElBQUksQ0FBQztnQkFDbkIsSUFBSSxFQUFFLGFBQWE7Z0JBQ25CLE9BQU8sRUFBRSxNQUFNO2dCQUNmLE9BQU8sRUFBRSxxQ0FBcUMsYUFBYSxPQUFPO2dCQUNsRSxRQUFRLEVBQUUsV0FBVyxDQUFDLGlCQUFpQjthQUN4QyxDQUFDLENBQUE7UUFDSixDQUFDO0lBQ0gsQ0FBQztJQUVELE9BQU8sZUFBZSxDQUFBO0FBQ3hCLENBQUMifQ==