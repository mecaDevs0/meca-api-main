"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.PUT = PUT;
exports.DELETE = DELETE;
const vehicle_1 = require("../../../../modules/vehicle");
/**
 * GET /store/vehicles/:id
 *
 * Busca um veículo específico do cliente autenticado
 */
async function GET(req, res) {
    const vehicleModuleService = req.scope.resolve(vehicle_1.VEHICLE_MODULE);
    const customerId = req.auth_context?.actor_id;
    const { id } = req.params;
    if (!customerId) {
        return res.status(401).json({ message: "Não autenticado" });
    }
    const vehicle = await vehicleModuleService.retrieveVehicle(id);
    // Verificar se o veículo pertence ao cliente
    if (vehicle.customer_id !== customerId) {
        return res.status(403).json({ message: "Acesso negado" });
    }
    return res.json({ vehicle });
}
/**
 * PUT /store/vehicles/:id
 *
 * Atualiza um veículo do cliente autenticado
 */
async function PUT(req, res) {
    const vehicleModuleService = req.scope.resolve(vehicle_1.VEHICLE_MODULE);
    const customerId = req.auth_context?.actor_id;
    const { id } = req.params;
    if (!customerId) {
        return res.status(401).json({ message: "Não autenticado" });
    }
    // Verificar propriedade do veículo
    const existingVehicle = await vehicleModuleService.retrieveVehicle(id);
    if (existingVehicle.customer_id !== customerId) {
        return res.status(403).json({ message: "Acesso negado" });
    }
    const { marca, modelo, ano, placa, cor, km_atual, combustivel, observacoes } = req.body;
    const vehicle = await vehicleModuleService.updateVehicles(id, {
        marca,
        modelo,
        ano,
        placa,
        cor,
        km_atual,
        combustivel,
        observacoes
    });
    return res.json({ vehicle });
}
/**
 * DELETE /store/vehicles/:id
 *
 * Remove um veículo do cliente autenticado
 */
async function DELETE(req, res) {
    const vehicleModuleService = req.scope.resolve(vehicle_1.VEHICLE_MODULE);
    const customerId = req.auth_context?.actor_id;
    const { id } = req.params;
    if (!customerId) {
        return res.status(401).json({ message: "Não autenticado" });
    }
    // Verificar propriedade do veículo
    const existingVehicle = await vehicleModuleService.retrieveVehicle(id);
    if (existingVehicle.customer_id !== customerId) {
        return res.status(403).json({ message: "Acesso negado" });
    }
    await vehicleModuleService.deleteVehicles(id);
    return res.status(204).send();
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3ZlaGljbGVzL1tpZF0vcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFRQSxrQkFvQkM7QUFPRCxrQkFpQ0M7QUFPRCx3QkFzQkM7QUFoR0QseURBQTREO0FBRTVEOzs7O0dBSUc7QUFDSSxLQUFLLFVBQVUsR0FBRyxDQUN2QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixNQUFNLG9CQUFvQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHdCQUFjLENBQUMsQ0FBQTtJQUM5RCxNQUFNLFVBQVUsR0FBRyxHQUFHLENBQUMsWUFBWSxFQUFFLFFBQVEsQ0FBQTtJQUM3QyxNQUFNLEVBQUUsRUFBRSxFQUFFLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQTtJQUV6QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDaEIsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxDQUFDLENBQUE7SUFDN0QsQ0FBQztJQUVELE1BQU0sT0FBTyxHQUFHLE1BQU0sb0JBQW9CLENBQUMsZUFBZSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0lBRTlELDZDQUE2QztJQUM3QyxJQUFJLE9BQU8sQ0FBQyxXQUFXLEtBQUssVUFBVSxFQUFFLENBQUM7UUFDdkMsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSxlQUFlLEVBQUUsQ0FBQyxDQUFBO0lBQzNELENBQUM7SUFFRCxPQUFPLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFBO0FBQzlCLENBQUM7QUFFRDs7OztHQUlHO0FBQ0ksS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsTUFBTSxvQkFBb0IsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyx3QkFBYyxDQUFDLENBQUE7SUFDOUQsTUFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDLFlBQVksRUFBRSxRQUFRLENBQUE7SUFDN0MsTUFBTSxFQUFFLEVBQUUsRUFBRSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUE7SUFFekIsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2hCLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsQ0FBQyxDQUFBO0lBQzdELENBQUM7SUFFRCxtQ0FBbUM7SUFDbkMsTUFBTSxlQUFlLEdBQUcsTUFBTSxvQkFBb0IsQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDLENBQUE7SUFFdEUsSUFBSSxlQUFlLENBQUMsV0FBVyxLQUFLLFVBQVUsRUFBRSxDQUFDO1FBQy9DLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUsZUFBZSxFQUFFLENBQUMsQ0FBQTtJQUMzRCxDQUFDO0lBRUQsTUFBTSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUUsUUFBUSxFQUFFLFdBQVcsRUFBRSxXQUFXLEVBQUUsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFBO0lBRXZGLE1BQU0sT0FBTyxHQUFHLE1BQU0sb0JBQW9CLENBQUMsY0FBYyxDQUFDLEVBQUUsRUFBRTtRQUM1RCxLQUFLO1FBQ0wsTUFBTTtRQUNOLEdBQUc7UUFDSCxLQUFLO1FBQ0wsR0FBRztRQUNILFFBQVE7UUFDUixXQUFXO1FBQ1gsV0FBVztLQUNaLENBQUMsQ0FBQTtJQUVGLE9BQU8sR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUE7QUFDOUIsQ0FBQztBQUVEOzs7O0dBSUc7QUFDSSxLQUFLLFVBQVUsTUFBTSxDQUMxQixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixNQUFNLG9CQUFvQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHdCQUFjLENBQUMsQ0FBQTtJQUM5RCxNQUFNLFVBQVUsR0FBRyxHQUFHLENBQUMsWUFBWSxFQUFFLFFBQVEsQ0FBQTtJQUM3QyxNQUFNLEVBQUUsRUFBRSxFQUFFLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQTtJQUV6QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDaEIsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxDQUFDLENBQUE7SUFDN0QsQ0FBQztJQUVELG1DQUFtQztJQUNuQyxNQUFNLGVBQWUsR0FBRyxNQUFNLG9CQUFvQixDQUFDLGVBQWUsQ0FBQyxFQUFFLENBQUMsQ0FBQTtJQUV0RSxJQUFJLGVBQWUsQ0FBQyxXQUFXLEtBQUssVUFBVSxFQUFFLENBQUM7UUFDL0MsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSxlQUFlLEVBQUUsQ0FBQyxDQUFBO0lBQzNELENBQUM7SUFFRCxNQUFNLG9CQUFvQixDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUMsQ0FBQTtJQUU3QyxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUE7QUFDL0IsQ0FBQyJ9