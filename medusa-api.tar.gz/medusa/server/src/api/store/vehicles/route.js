"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.POST = POST;
const vehicle_1 = require("../../../modules/vehicle");
/**
 * GET /store/vehicles
 *
 * Lista todos os veículos do cliente autenticado
 */
async function GET(req, res) {
    const vehicleModuleService = req.scope.resolve(vehicle_1.VEHICLE_MODULE);
    // Pegar customer_id do cliente autenticado
    const customerId = req.auth_context?.actor_id;
    if (!customerId) {
        return res.status(401).json({
            message: "Não autenticado"
        });
    }
    // Buscar veículos do cliente
    const vehicles = await vehicleModuleService.listVehicles({
        customer_id: customerId
    });
    return res.json({ vehicles });
}
/**
 * POST /store/vehicles
 *
 * Cadastra um novo veículo para o cliente autenticado
 */
async function POST(req, res) {
    const vehicleModuleService = req.scope.resolve(vehicle_1.VEHICLE_MODULE);
    const customerId = req.auth_context?.actor_id;
    if (!customerId) {
        return res.status(401).json({
            message: "Não autenticado"
        });
    }
    const { marca, modelo, ano, placa, cor, km_atual, combustivel, observacoes } = req.body;
    // Validação básica
    if (!marca || !modelo || !ano || !placa) {
        return res.status(400).json({
            message: "Marca, modelo, ano e placa são obrigatórios"
        });
    }
    // Criar veículo
    const vehicle = await vehicleModuleService.createVehicles({
        customer_id: customerId,
        marca,
        modelo,
        ano,
        placa,
        cor,
        km_atual,
        combustivel,
        observacoes
    });
    return res.status(201).json({ vehicle });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3ZlaGljbGVzL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBUUEsa0JBcUJDO0FBT0Qsb0JBcUNDO0FBeEVELHNEQUF5RDtBQUV6RDs7OztHQUlHO0FBQ0ksS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsTUFBTSxvQkFBb0IsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyx3QkFBYyxDQUFDLENBQUE7SUFFOUQsMkNBQTJDO0lBQzNDLE1BQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQyxZQUFZLEVBQUUsUUFBUSxDQUFBO0lBRTdDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNoQixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSxpQkFBaUI7U0FDM0IsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVELDZCQUE2QjtJQUM3QixNQUFNLFFBQVEsR0FBRyxNQUFNLG9CQUFvQixDQUFDLFlBQVksQ0FBQztRQUN2RCxXQUFXLEVBQUUsVUFBVTtLQUN4QixDQUFDLENBQUE7SUFFRixPQUFPLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFBO0FBQy9CLENBQUM7QUFFRDs7OztHQUlHO0FBQ0ksS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsTUFBTSxvQkFBb0IsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyx3QkFBYyxDQUFDLENBQUE7SUFFOUQsTUFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDLFlBQVksRUFBRSxRQUFRLENBQUE7SUFFN0MsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2hCLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLGlCQUFpQjtTQUMzQixDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsTUFBTSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUUsUUFBUSxFQUFFLFdBQVcsRUFBRSxXQUFXLEVBQUUsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFBO0lBRXZGLG1CQUFtQjtJQUNuQixJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsTUFBTSxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDeEMsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsNkNBQTZDO1NBQ3ZELENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxnQkFBZ0I7SUFDaEIsTUFBTSxPQUFPLEdBQUcsTUFBTSxvQkFBb0IsQ0FBQyxjQUFjLENBQUM7UUFDeEQsV0FBVyxFQUFFLFVBQVU7UUFDdkIsS0FBSztRQUNMLE1BQU07UUFDTixHQUFHO1FBQ0gsS0FBSztRQUNMLEdBQUc7UUFDSCxRQUFRO1FBQ1IsV0FBVztRQUNYLFdBQVc7S0FDWixDQUFDLENBQUE7SUFFRixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLENBQUMsQ0FBQTtBQUMxQyxDQUFDIn0=