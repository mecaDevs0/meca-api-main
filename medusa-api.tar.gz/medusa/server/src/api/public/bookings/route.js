"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AUTHENTICATE = void 0;
exports.POST = POST;
exports.GET = GET;
const utils_1 = require("@medusajs/framework/utils");
const booking_1 = require("../../../modules/booking");
exports.AUTHENTICATE = false;
/**
 * POST /public/bookings
 *
 * Criar novo agendamento
 */
async function POST(req, res) {
    const bookingService = req.scope.resolve(booking_1.BOOKING_MODULE);
    const orderService = req.scope.resolve(utils_1.Modules.ORDER);
    const { customer_id, oficina_id, vehicle_id, service_id, scheduled_date, scheduled_time, notes } = req.body;
    if (!customer_id || !oficina_id || !vehicle_id || !service_id || !scheduled_date) {
        return res.status(400).json({
            message: "Cliente, oficina, veículo, serviço e data são obrigatórios"
        });
    }
    try {
        // Criar pedido primeiro
        const order = await orderService.createOrders({
            currency_code: "BRL",
            email: "", // Será preenchido depois
            metadata: {
                customer_id,
                oficina_id,
                vehicle_id,
                service_id
            }
        });
        // Criar agendamento
        const booking = await bookingService.createBookings({
            customer_id,
            oficina_id,
            vehicle_id,
            order_id: order.id,
            scheduled_date: new Date(scheduled_date),
            scheduled_time,
            status: "pendente",
            notes
        });
        return res.status(201).json({
            message: "Agendamento criado com sucesso!",
            booking: {
                id: booking.id,
                scheduled_date: booking.scheduled_date,
                scheduled_time: booking.scheduled_time,
                status: booking.status,
                order_id: order.id
            }
        });
    }
    catch (error) {
        console.error("Erro ao criar agendamento:", error);
        return res.status(500).json({
            message: "Erro ao criar agendamento",
            error: error.message
        });
    }
}
/**
 * GET /public/bookings?customer_id=xxx
 *
 * Lista agendamentos do cliente
 */
async function GET(req, res) {
    const bookingService = req.scope.resolve(booking_1.BOOKING_MODULE);
    const { customer_id, oficina_id } = req.query;
    const filters = {};
    if (customer_id) {
        filters.customer_id = customer_id;
    }
    if (oficina_id) {
        filters.oficina_id = oficina_id;
    }
    try {
        const bookings = await bookingService.listBookings(filters, {
            order: { scheduled_date: "DESC" }
        });
        return res.json({
            bookings,
            count: bookings.length
        });
    }
    catch (error) {
        console.error("Erro ao listar agendamentos:", error);
        return res.status(500).json({
            message: "Erro ao listar agendamentos",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3B1YmxpYy9ib29raW5ncy9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFXQSxvQkFtRUM7QUFPRCxrQkFtQ0M7QUF2SEQscURBQW1EO0FBQ25ELHNEQUF5RDtBQUU1QyxRQUFBLFlBQVksR0FBRyxLQUFLLENBQUE7QUFFakM7Ozs7R0FJRztBQUNJLEtBQUssVUFBVSxJQUFJLENBQ3hCLEdBQWtCLEVBQ2xCLEdBQW1CO0lBRW5CLE1BQU0sY0FBYyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHdCQUFjLENBQUMsQ0FBQTtJQUN4RCxNQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsS0FBSyxDQUFDLENBQUE7SUFFckQsTUFBTSxFQUNKLFdBQVcsRUFDWCxVQUFVLEVBQ1YsVUFBVSxFQUNWLFVBQVUsRUFDVixjQUFjLEVBQ2QsY0FBYyxFQUNkLEtBQUssRUFDTixHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUE7SUFFWixJQUFJLENBQUMsV0FBVyxJQUFJLENBQUMsVUFBVSxJQUFJLENBQUMsVUFBVSxJQUFJLENBQUMsVUFBVSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDakYsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsNERBQTREO1NBQ3RFLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxJQUFJLENBQUM7UUFDSCx3QkFBd0I7UUFDeEIsTUFBTSxLQUFLLEdBQUcsTUFBTSxZQUFZLENBQUMsWUFBWSxDQUFDO1lBQzVDLGFBQWEsRUFBRSxLQUFLO1lBQ3BCLEtBQUssRUFBRSxFQUFFLEVBQUUseUJBQXlCO1lBQ3BDLFFBQVEsRUFBRTtnQkFDUixXQUFXO2dCQUNYLFVBQVU7Z0JBQ1YsVUFBVTtnQkFDVixVQUFVO2FBQ1g7U0FDRixDQUFDLENBQUE7UUFFRixvQkFBb0I7UUFDcEIsTUFBTSxPQUFPLEdBQUcsTUFBTSxjQUFjLENBQUMsY0FBYyxDQUFDO1lBQ2xELFdBQVc7WUFDWCxVQUFVO1lBQ1YsVUFBVTtZQUNWLFFBQVEsRUFBRSxLQUFLLENBQUMsRUFBRTtZQUNsQixjQUFjLEVBQUUsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDO1lBQ3hDLGNBQWM7WUFDZCxNQUFNLEVBQUUsVUFBVTtZQUNsQixLQUFLO1NBQ04sQ0FBQyxDQUFBO1FBRUYsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsaUNBQWlDO1lBQzFDLE9BQU8sRUFBRTtnQkFDUCxFQUFFLEVBQUUsT0FBTyxDQUFDLEVBQUU7Z0JBQ2QsY0FBYyxFQUFFLE9BQU8sQ0FBQyxjQUFjO2dCQUN0QyxjQUFjLEVBQUUsT0FBTyxDQUFDLGNBQWM7Z0JBQ3RDLE1BQU0sRUFBRSxPQUFPLENBQUMsTUFBTTtnQkFDdEIsUUFBUSxFQUFFLEtBQUssQ0FBQyxFQUFFO2FBQ25CO1NBQ0YsQ0FBQyxDQUFBO0lBRUosQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLDRCQUE0QixFQUFFLEtBQUssQ0FBQyxDQUFBO1FBRWxELE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLDJCQUEyQjtZQUNwQyxLQUFLLEVBQUUsS0FBSyxDQUFDLE9BQU87U0FDckIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUM7QUFFRDs7OztHQUlHO0FBQ0ksS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsTUFBTSxjQUFjLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsd0JBQWMsQ0FBQyxDQUFBO0lBQ3hELE1BQU0sRUFBRSxXQUFXLEVBQUUsVUFBVSxFQUFFLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQTtJQUU3QyxNQUFNLE9BQU8sR0FBUSxFQUFFLENBQUE7SUFFdkIsSUFBSSxXQUFXLEVBQUUsQ0FBQztRQUNoQixPQUFPLENBQUMsV0FBVyxHQUFHLFdBQXFCLENBQUE7SUFDN0MsQ0FBQztJQUVELElBQUksVUFBVSxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsVUFBVSxHQUFHLFVBQW9CLENBQUE7SUFDM0MsQ0FBQztJQUVELElBQUksQ0FBQztRQUNILE1BQU0sUUFBUSxHQUFHLE1BQU0sY0FBYyxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUU7WUFDMUQsS0FBSyxFQUFFLEVBQUUsY0FBYyxFQUFFLE1BQU0sRUFBRTtTQUNsQyxDQUFDLENBQUE7UUFFRixPQUFPLEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDZCxRQUFRO1lBQ1IsS0FBSyxFQUFFLFFBQVEsQ0FBQyxNQUFNO1NBQ3ZCLENBQUMsQ0FBQTtJQUVKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyw4QkFBOEIsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUVwRCxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSw2QkFBNkI7WUFDdEMsS0FBSyxFQUFFLEtBQUssQ0FBQyxPQUFPO1NBQ3JCLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=