"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AUTHENTICATE = void 0;
exports.PUT = PUT;
exports.GET = GET;
const booking_1 = require("../../../../modules/booking");
exports.AUTHENTICATE = false;
/**
 * PUT /public/bookings/:id
 *
 * Atualizar status do agendamento (aceitar/rejeitar)
 */
async function PUT(req, res) {
    const bookingService = req.scope.resolve(booking_1.BOOKING_MODULE);
    const id = req.params.id;
    const { status, rejection_reason } = req.body;
    if (!status) {
        return res.status(400).json({
            message: "Status é obrigatório"
        });
    }
    if (!['pendente', 'confirmado', 'cancelado', 'concluido'].includes(status)) {
        return res.status(400).json({
            message: "Status inválido. Use: pendente, confirmado, cancelado ou concluido"
        });
    }
    try {
        const booking = await bookingService.retrieveBooking(id);
        if (!booking) {
            return res.status(404).json({
                message: "Agendamento não encontrado"
            });
        }
        const updatedBooking = await bookingService.updateBookings(id, {
            status,
            metadata: {
                ...booking.metadata,
                rejection_reason: rejection_reason || undefined
            }
        });
        return res.json({
            message: "Agendamento atualizado com sucesso!",
            booking: updatedBooking
        });
    }
    catch (error) {
        console.error("Erro ao atualizar agendamento:", error);
        return res.status(500).json({
            message: "Erro ao atualizar agendamento",
            error: error.message
        });
    }
}
/**
 * GET /public/bookings/:id
 *
 * Buscar agendamento por ID
 */
async function GET(req, res) {
    const bookingService = req.scope.resolve(booking_1.BOOKING_MODULE);
    const id = req.params.id;
    try {
        const booking = await bookingService.retrieveBooking(id);
        if (!booking) {
            return res.status(404).json({
                message: "Agendamento não encontrado"
            });
        }
        return res.json({
            booking
        });
    }
    catch (error) {
        console.error("Erro ao buscar agendamento:", error);
        return res.status(500).json({
            message: "Erro ao buscar agendamento",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3B1YmxpYy9ib29raW5ncy9baWRdL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQVVBLGtCQWtEQztBQU9ELGtCQTRCQztBQTlGRCx5REFBNEQ7QUFFL0MsUUFBQSxZQUFZLEdBQUcsS0FBSyxDQUFBO0FBRWpDOzs7O0dBSUc7QUFDSSxLQUFLLFVBQVUsR0FBRyxDQUN2QixHQUFrQyxFQUNsQyxHQUFtQjtJQUVuQixNQUFNLGNBQWMsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyx3QkFBYyxDQUFDLENBQUE7SUFDeEQsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUE7SUFDeEIsTUFBTSxFQUFFLE1BQU0sRUFBRSxnQkFBZ0IsRUFBRSxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUE7SUFFN0MsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ1osT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsc0JBQXNCO1NBQ2hDLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxJQUFJLENBQUMsQ0FBQyxVQUFVLEVBQUUsWUFBWSxFQUFFLFdBQVcsRUFBRSxXQUFXLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUMzRSxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSxvRUFBb0U7U0FDOUUsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVELElBQUksQ0FBQztRQUNILE1BQU0sT0FBTyxHQUFHLE1BQU0sY0FBYyxDQUFDLGVBQWUsQ0FBQyxFQUFFLENBQUMsQ0FBQTtRQUV4RCxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDYixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUMxQixPQUFPLEVBQUUsNEJBQTRCO2FBQ3RDLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFFRCxNQUFNLGNBQWMsR0FBRyxNQUFNLGNBQWMsQ0FBQyxjQUFjLENBQUMsRUFBRSxFQUFFO1lBQzdELE1BQU07WUFDTixRQUFRLEVBQUU7Z0JBQ1IsR0FBRyxPQUFPLENBQUMsUUFBUTtnQkFDbkIsZ0JBQWdCLEVBQUUsZ0JBQWdCLElBQUksU0FBUzthQUNoRDtTQUNGLENBQUMsQ0FBQTtRQUVGLE9BQU8sR0FBRyxDQUFDLElBQUksQ0FBQztZQUNkLE9BQU8sRUFBRSxxQ0FBcUM7WUFDOUMsT0FBTyxFQUFFLGNBQWM7U0FDeEIsQ0FBQyxDQUFBO0lBRUosQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLGdDQUFnQyxFQUFFLEtBQUssQ0FBQyxDQUFBO1FBRXRELE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLCtCQUErQjtZQUN4QyxLQUFLLEVBQUUsS0FBSyxDQUFDLE9BQU87U0FDckIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUM7QUFFRDs7OztHQUlHO0FBQ0ksS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBa0MsRUFDbEMsR0FBbUI7SUFFbkIsTUFBTSxjQUFjLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsd0JBQWMsQ0FBQyxDQUFBO0lBQ3hELE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFBO0lBRXhCLElBQUksQ0FBQztRQUNILE1BQU0sT0FBTyxHQUFHLE1BQU0sY0FBYyxDQUFDLGVBQWUsQ0FBQyxFQUFFLENBQUMsQ0FBQTtRQUV4RCxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDYixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUMxQixPQUFPLEVBQUUsNEJBQTRCO2FBQ3RDLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFFRCxPQUFPLEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDZCxPQUFPO1NBQ1IsQ0FBQyxDQUFBO0lBRUosQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLDZCQUE2QixFQUFFLEtBQUssQ0FBQyxDQUFBO1FBRW5ELE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLDRCQUE0QjtZQUNyQyxLQUFLLEVBQUUsS0FBSyxDQUFDLE9BQU87U0FDckIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUMifQ==