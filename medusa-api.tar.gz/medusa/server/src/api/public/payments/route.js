"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AUTHENTICATE = void 0;
exports.POST = POST;
exports.GET = GET;
const pagbank_payment_1 = require("../../../modules/pagbank_payment");
exports.AUTHENTICATE = false;
/**
 * POST /public/payments
 *
 * Processar pagamento (simulado)
 */
async function POST(req, res) {
    const paymentService = req.scope.resolve(pagbank_payment_1.PAGBANK_PAYMENT_MODULE);
    const { booking_id, order_id, amount, payment_method, card_info } = req.body;
    if (!booking_id || !order_id || !amount || !payment_method) {
        return res.status(400).json({
            message: "Agendamento, pedido, valor e método de pagamento são obrigatórios"
        });
    }
    try {
        // Simular processamento de pagamento
        const payment = await paymentService.createPagbankPayments({
            order_id,
            amount: parseFloat(amount),
            payment_method,
            status: "approved", // Simular aprovação automática
            transaction_id: `sim_${Date.now()}`, // ID simulado
            metadata: {
                booking_id,
                card_last_4: card_info?.last_4 || "****",
                simulated: true
            }
        });
        return res.status(201).json({
            message: "Pagamento processado com sucesso!",
            payment: {
                id: payment.id,
                status: payment.status,
                transaction_id: payment.transaction_id,
                amount: payment.amount
            }
        });
    }
    catch (error) {
        console.error("Erro ao processar pagamento:", error);
        return res.status(500).json({
            message: "Erro ao processar pagamento",
            error: error.message
        });
    }
}
/**
 * GET /public/payments?order_id=xxx
 *
 * Buscar pagamentos de um pedido
 */
async function GET(req, res) {
    const paymentService = req.scope.resolve(pagbank_payment_1.PAGBANK_PAYMENT_MODULE);
    const { order_id } = req.query;
    if (!order_id) {
        return res.status(400).json({
            message: "ID do pedido é obrigatório"
        });
    }
    try {
        const payments = await paymentService.listPagbankPayments({
            order_id: order_id
        });
        return res.json({
            payments,
            count: payments.length
        });
    }
    catch (error) {
        console.error("Erro ao buscar pagamentos:", error);
        return res.status(500).json({
            message: "Erro ao buscar pagamentos",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3B1YmxpYy9wYXltZW50cy9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFVQSxvQkFxREM7QUFPRCxrQkErQkM7QUFwR0Qsc0VBQXlFO0FBRTVELFFBQUEsWUFBWSxHQUFHLEtBQUssQ0FBQTtBQUVqQzs7OztHQUlHO0FBQ0ksS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsTUFBTSxjQUFjLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsd0NBQXNCLENBQUMsQ0FBQTtJQUVoRSxNQUFNLEVBQ0osVUFBVSxFQUNWLFFBQVEsRUFDUixNQUFNLEVBQ04sY0FBYyxFQUNkLFNBQVMsRUFDVixHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUE7SUFFWixJQUFJLENBQUMsVUFBVSxJQUFJLENBQUMsUUFBUSxJQUFJLENBQUMsTUFBTSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDM0QsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsbUVBQW1FO1NBQzdFLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxJQUFJLENBQUM7UUFDSCxxQ0FBcUM7UUFDckMsTUFBTSxPQUFPLEdBQUcsTUFBTSxjQUFjLENBQUMscUJBQXFCLENBQUM7WUFDekQsUUFBUTtZQUNSLE1BQU0sRUFBRSxVQUFVLENBQUMsTUFBTSxDQUFDO1lBQzFCLGNBQWM7WUFDZCxNQUFNLEVBQUUsVUFBVSxFQUFFLCtCQUErQjtZQUNuRCxjQUFjLEVBQUUsT0FBTyxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUUsRUFBRSxjQUFjO1lBQ25ELFFBQVEsRUFBRTtnQkFDUixVQUFVO2dCQUNWLFdBQVcsRUFBRSxTQUFTLEVBQUUsTUFBTSxJQUFJLE1BQU07Z0JBQ3hDLFNBQVMsRUFBRSxJQUFJO2FBQ2hCO1NBQ0YsQ0FBQyxDQUFBO1FBRUYsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsbUNBQW1DO1lBQzVDLE9BQU8sRUFBRTtnQkFDUCxFQUFFLEVBQUUsT0FBTyxDQUFDLEVBQUU7Z0JBQ2QsTUFBTSxFQUFFLE9BQU8sQ0FBQyxNQUFNO2dCQUN0QixjQUFjLEVBQUUsT0FBTyxDQUFDLGNBQWM7Z0JBQ3RDLE1BQU0sRUFBRSxPQUFPLENBQUMsTUFBTTthQUN2QjtTQUNGLENBQUMsQ0FBQTtJQUVKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyw4QkFBOEIsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUVwRCxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSw2QkFBNkI7WUFDdEMsS0FBSyxFQUFFLEtBQUssQ0FBQyxPQUFPO1NBQ3JCLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDO0FBRUQ7Ozs7R0FJRztBQUNJLEtBQUssVUFBVSxHQUFHLENBQ3ZCLEdBQWtCLEVBQ2xCLEdBQW1CO0lBRW5CLE1BQU0sY0FBYyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHdDQUFzQixDQUFDLENBQUE7SUFDaEUsTUFBTSxFQUFFLFFBQVEsRUFBRSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUE7SUFFOUIsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2QsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsNEJBQTRCO1NBQ3RDLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxJQUFJLENBQUM7UUFDSCxNQUFNLFFBQVEsR0FBRyxNQUFNLGNBQWMsQ0FBQyxtQkFBbUIsQ0FBQztZQUN4RCxRQUFRLEVBQUUsUUFBa0I7U0FDN0IsQ0FBQyxDQUFBO1FBRUYsT0FBTyxHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ2QsUUFBUTtZQUNSLEtBQUssRUFBRSxRQUFRLENBQUMsTUFBTTtTQUN2QixDQUFDLENBQUE7SUFFSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsNEJBQTRCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFFbEQsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsMkJBQTJCO1lBQ3BDLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTztTQUNyQixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9