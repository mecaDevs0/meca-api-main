"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AUTHENTICATE = void 0;
exports.POST = POST;
exports.GET = GET;
const oficina_1 = require("../../../modules/oficina");
exports.AUTHENTICATE = false;
/**
 * POST /public/workshops
 *
 * Cadastro de uma nova oficina (sem autenticação)
 */
async function POST(req, res) {
    const oficinaModuleService = req.scope.resolve(oficina_1.OFICINA_MODULE);
    const { name, cnpj, email, phone, address, description, logo_url, photo_urls, horario_funcionamento, password } = req.body;
    if (!email || !name || !cnpj || !password) {
        return res.status(400).json({
            message: "Email, nome da oficina, CNPJ e senha são obrigatórios"
        });
    }
    try {
        // Verificar se já existe oficina com esse CNPJ ou email
        const existingOficinas = await oficinaModuleService.listOficinas({
            $or: [
                { cnpj },
                { email }
            ]
        });
        if (existingOficinas.length > 0) {
            return res.status(400).json({
                message: "Já existe uma oficina cadastrada com esse CNPJ ou email"
            });
        }
        // Criar oficina
        const oficina = await oficinaModuleService.createOficinas({
            name,
            cnpj,
            email,
            phone,
            address,
            description,
            logo_url,
            photo_urls,
            horario_funcionamento,
            status: "pendente"
        });
        // Atualizar com metadata (senha)
        await oficinaModuleService.updateOficinas(oficina.id, {
            metadata: {
                password
            }
        });
        return res.status(201).json({
            message: "Oficina cadastrada com sucesso! Aguardando aprovação.",
            oficina: {
                id: oficina.id,
                name: oficina.name,
                email: oficina.email,
                status: oficina.status
            }
        });
    }
    catch (error) {
        console.error("Erro ao cadastrar oficina:", error);
        return res.status(500).json({
            message: "Erro ao cadastrar oficina",
            error: error.message
        });
    }
}
/**
 * GET /public/workshops
 *
 * Lista oficinas aprovadas (sem autenticação)
 */
async function GET(req, res) {
    const oficinaModuleService = req.scope.resolve(oficina_1.OFICINA_MODULE);
    const { limit = 50, offset = 0, q, cidade, estado } = req.query;
    const filters = {
        status: "aprovado" // Apenas oficinas aprovadas
    };
    if (q) {
        filters.$or = [
            { name: { $ilike: `%${q}%` } }
        ];
    }
    if (cidade) {
        filters['address.cidade'] = { $ilike: `%${cidade}%` };
    }
    if (estado) {
        filters['address.estado'] = { $ilike: `%${estado}%` };
    }
    try {
        const workshops = await oficinaModuleService.listOficinas(filters, {
            take: Number(limit),
            skip: Number(offset),
            order: { created_at: "DESC" }
        });
        return res.json({
            workshops,
            count: workshops.length,
            limit: Number(limit),
            offset: Number(offset),
        });
    }
    catch (error) {
        console.error("Erro ao listar oficinas:", error);
        return res.status(500).json({
            message: "Erro ao listar oficinas",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3B1YmxpYy93b3Jrc2hvcHMvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBVUEsb0JBK0VDO0FBT0Qsa0JBZ0RDO0FBL0lELHNEQUF5RDtBQUU1QyxRQUFBLFlBQVksR0FBRyxLQUFLLENBQUE7QUFFakM7Ozs7R0FJRztBQUNJLEtBQUssVUFBVSxJQUFJLENBQ3hCLEdBQWtCLEVBQ2xCLEdBQW1CO0lBRW5CLE1BQU0sb0JBQW9CLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsd0JBQWMsQ0FBQyxDQUFBO0lBRTlELE1BQU0sRUFDSixJQUFJLEVBQ0osSUFBSSxFQUNKLEtBQUssRUFDTCxLQUFLLEVBQ0wsT0FBTyxFQUNQLFdBQVcsRUFDWCxRQUFRLEVBQ1IsVUFBVSxFQUNWLHFCQUFxQixFQUNyQixRQUFRLEVBQ1QsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFBO0lBRVosSUFBSSxDQUFDLEtBQUssSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQzFDLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLHVEQUF1RDtTQUNqRSxDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsSUFBSSxDQUFDO1FBQ0gsd0RBQXdEO1FBQ3hELE1BQU0sZ0JBQWdCLEdBQUcsTUFBTSxvQkFBb0IsQ0FBQyxZQUFZLENBQUM7WUFDL0QsR0FBRyxFQUFFO2dCQUNILEVBQUUsSUFBSSxFQUFFO2dCQUNSLEVBQUUsS0FBSyxFQUFFO2FBQ1Y7U0FDRixDQUFDLENBQUE7UUFFRixJQUFJLGdCQUFnQixDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUNoQyxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUMxQixPQUFPLEVBQUUseURBQXlEO2FBQ25FLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFFRCxnQkFBZ0I7UUFDaEIsTUFBTSxPQUFPLEdBQUcsTUFBTSxvQkFBb0IsQ0FBQyxjQUFjLENBQUM7WUFDeEQsSUFBSTtZQUNKLElBQUk7WUFDSixLQUFLO1lBQ0wsS0FBSztZQUNMLE9BQU87WUFDUCxXQUFXO1lBQ1gsUUFBUTtZQUNSLFVBQVU7WUFDVixxQkFBcUI7WUFDckIsTUFBTSxFQUFFLFVBQVU7U0FDbkIsQ0FBQyxDQUFBO1FBRUYsaUNBQWlDO1FBQ2pDLE1BQU0sb0JBQW9CLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxFQUFFLEVBQUU7WUFDcEQsUUFBUSxFQUFFO2dCQUNSLFFBQVE7YUFDVDtTQUNGLENBQUMsQ0FBQTtRQUVGLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLHVEQUF1RDtZQUNoRSxPQUFPLEVBQUU7Z0JBQ1AsRUFBRSxFQUFFLE9BQU8sQ0FBQyxFQUFFO2dCQUNkLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSTtnQkFDbEIsS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFLO2dCQUNwQixNQUFNLEVBQUUsT0FBTyxDQUFDLE1BQU07YUFDdkI7U0FDRixDQUFDLENBQUE7SUFFSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsNEJBQTRCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFFbEQsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsMkJBQTJCO1lBQ3BDLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTztTQUNyQixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQztBQUVEOzs7O0dBSUc7QUFDSSxLQUFLLFVBQVUsR0FBRyxDQUN2QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixNQUFNLG9CQUFvQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHdCQUFjLENBQUMsQ0FBQTtJQUU5RCxNQUFNLEVBQUUsS0FBSyxHQUFHLEVBQUUsRUFBRSxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQTtJQUUvRCxNQUFNLE9BQU8sR0FBUTtRQUNuQixNQUFNLEVBQUUsVUFBVSxDQUFDLDRCQUE0QjtLQUNoRCxDQUFBO0lBRUQsSUFBSSxDQUFDLEVBQUUsQ0FBQztRQUNOLE9BQU8sQ0FBQyxHQUFHLEdBQUc7WUFDWixFQUFFLElBQUksRUFBRSxFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUU7U0FDL0IsQ0FBQTtJQUNILENBQUM7SUFFRCxJQUFJLE1BQU0sRUFBRSxDQUFDO1FBQ1gsT0FBTyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxNQUFNLEVBQUUsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFBO0lBQ3ZELENBQUM7SUFFRCxJQUFJLE1BQU0sRUFBRSxDQUFDO1FBQ1gsT0FBTyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxNQUFNLEVBQUUsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFBO0lBQ3ZELENBQUM7SUFFRCxJQUFJLENBQUM7UUFDSCxNQUFNLFNBQVMsR0FBRyxNQUFNLG9CQUFvQixDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUU7WUFDakUsSUFBSSxFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUM7WUFDbkIsSUFBSSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUM7WUFDcEIsS0FBSyxFQUFFLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRTtTQUM5QixDQUFDLENBQUE7UUFFRixPQUFPLEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDZCxTQUFTO1lBQ1QsS0FBSyxFQUFFLFNBQVMsQ0FBQyxNQUFNO1lBQ3ZCLEtBQUssRUFBRSxNQUFNLENBQUMsS0FBSyxDQUFDO1lBQ3BCLE1BQU0sRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDO1NBQ3ZCLENBQUMsQ0FBQTtJQUVKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQywwQkFBMEIsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUVoRCxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSx5QkFBeUI7WUFDbEMsS0FBSyxFQUFFLEtBQUssQ0FBQyxPQUFPO1NBQ3JCLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=