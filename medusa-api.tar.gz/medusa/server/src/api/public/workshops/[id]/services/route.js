"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AUTHENTICATE = void 0;
exports.GET = GET;
exports.POST = POST;
const utils_1 = require("@medusajs/framework/utils");
exports.AUTHENTICATE = false;
/**
 * GET /public/workshops/:id/services
 *
 * Lista serviços oferecidos pela oficina
 */
async function GET(req, res) {
    const productService = req.scope.resolve(utils_1.Modules.PRODUCT);
    const oficina_id = req.params.id;
    try {
        // Buscar produtos (serviços) da oficina
        const products = await productService.listProducts({
            metadata: {
                oficina_id
            }
        });
        return res.json({
            services: products,
            count: products.length
        });
    }
    catch (error) {
        console.error("Erro ao listar serviços da oficina:", error);
        return res.status(500).json({
            message: "Erro ao listar serviços",
            error: error.message
        });
    }
}
/**
 * POST /public/workshops/:id/services
 *
 * Adicionar serviço à oficina
 */
async function POST(req, res) {
    const productService = req.scope.resolve(utils_1.Modules.PRODUCT);
    const oficina_id = req.params.id;
    const { title, description, price, duration, master_service_id } = req.body;
    if (!title || !price) {
        return res.status(400).json({
            message: "Título e preço são obrigatórios"
        });
    }
    try {
        // Criar produto (serviço)
        const product = await productService.createProducts({
            title,
            description,
            is_giftcard: false,
            discountable: true,
            options: [],
            variants: [
                {
                    title: "Default",
                    prices: [
                        {
                            amount: parseFloat(price) * 100, // Converter para centavos
                            currency_code: "BRL"
                        }
                    ]
                }
            ],
            metadata: {
                oficina_id,
                master_service_id,
                duration
            }
        });
        return res.status(201).json({
            message: "Serviço adicionado com sucesso!",
            service: product
        });
    }
    catch (error) {
        console.error("Erro ao adicionar serviço:", error);
        return res.status(500).json({
            message: "Erro ao adicionar serviço",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3B1YmxpYy93b3Jrc2hvcHMvW2lkXS9zZXJ2aWNlcy9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFVQSxrQkE0QkM7QUFPRCxvQkE0REM7QUF4R0QscURBQW1EO0FBRXRDLFFBQUEsWUFBWSxHQUFHLEtBQUssQ0FBQTtBQUVqQzs7OztHQUlHO0FBQ0ksS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBa0MsRUFDbEMsR0FBbUI7SUFFbkIsTUFBTSxjQUFjLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBTyxDQUFDLE9BQU8sQ0FBQyxDQUFBO0lBQ3pELE1BQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFBO0lBRWhDLElBQUksQ0FBQztRQUNILHdDQUF3QztRQUN4QyxNQUFNLFFBQVEsR0FBRyxNQUFNLGNBQWMsQ0FBQyxZQUFZLENBQUM7WUFDakQsUUFBUSxFQUFFO2dCQUNSLFVBQVU7YUFDWDtTQUNGLENBQUMsQ0FBQTtRQUVGLE9BQU8sR0FBRyxDQUFDLElBQUksQ0FBQztZQUNkLFFBQVEsRUFBRSxRQUFRO1lBQ2xCLEtBQUssRUFBRSxRQUFRLENBQUMsTUFBTTtTQUN2QixDQUFDLENBQUE7SUFFSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMscUNBQXFDLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFFM0QsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUseUJBQXlCO1lBQ2xDLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTztTQUNyQixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQztBQUVEOzs7O0dBSUc7QUFDSSxLQUFLLFVBQVUsSUFBSSxDQUN4QixHQUFrQyxFQUNsQyxHQUFtQjtJQUVuQixNQUFNLGNBQWMsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsT0FBTyxDQUFDLENBQUE7SUFDekQsTUFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUE7SUFFaEMsTUFBTSxFQUNKLEtBQUssRUFDTCxXQUFXLEVBQ1gsS0FBSyxFQUNMLFFBQVEsRUFDUixpQkFBaUIsRUFDbEIsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFBO0lBRVosSUFBSSxDQUFDLEtBQUssSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3JCLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLGlDQUFpQztTQUMzQyxDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsSUFBSSxDQUFDO1FBQ0gsMEJBQTBCO1FBQzFCLE1BQU0sT0FBTyxHQUFHLE1BQU0sY0FBYyxDQUFDLGNBQWMsQ0FBQztZQUNsRCxLQUFLO1lBQ0wsV0FBVztZQUNYLFdBQVcsRUFBRSxLQUFLO1lBQ2xCLFlBQVksRUFBRSxJQUFJO1lBQ2xCLE9BQU8sRUFBRSxFQUFFO1lBQ1gsUUFBUSxFQUFFO2dCQUNSO29CQUNFLEtBQUssRUFBRSxTQUFTO29CQUNoQixNQUFNLEVBQUU7d0JBQ047NEJBQ0UsTUFBTSxFQUFFLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLEVBQUUsMEJBQTBCOzRCQUMzRCxhQUFhLEVBQUUsS0FBSzt5QkFDckI7cUJBQ0Y7aUJBQ0Y7YUFDRjtZQUNELFFBQVEsRUFBRTtnQkFDUixVQUFVO2dCQUNWLGlCQUFpQjtnQkFDakIsUUFBUTthQUNUO1NBQ0YsQ0FBQyxDQUFBO1FBRUYsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsaUNBQWlDO1lBQzFDLE9BQU8sRUFBRSxPQUFPO1NBQ2pCLENBQUMsQ0FBQTtJQUVKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyw0QkFBNEIsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUVsRCxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSwyQkFBMkI7WUFDcEMsS0FBSyxFQUFFLEtBQUssQ0FBQyxPQUFPO1NBQ3JCLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=