"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AUTHENTICATE = void 0;
exports.POST = POST;
exports.GET = GET;
const vehicle_1 = require("../../../modules/vehicle");
exports.AUTHENTICATE = false;
/**
 * POST /public/vehicles
 *
 * Cadastro de novo veículo
 */
async function POST(req, res) {
    const vehicleService = req.scope.resolve(vehicle_1.VEHICLE_MODULE);
    const { customer_id, placa, marca, modelo, ano, cor, chassis } = req.body;
    if (!customer_id || !placa || !marca || !modelo) {
        return res.status(400).json({
            message: "Cliente, placa, marca e modelo são obrigatórios"
        });
    }
    try {
        // Verificar se já existe veículo com essa placa
        const existingVehicles = await vehicleService.listVehicles({ placa });
        if (existingVehicles.length > 0) {
            return res.status(400).json({
                message: "Já existe um veículo cadastrado com essa placa"
            });
        }
        // Criar veículo
        const vehicle = await vehicleService.createVehicles({
            customer_id,
            placa,
            marca,
            modelo,
            ano: ano ? parseInt(ano) : undefined,
            cor,
            chassis
        });
        return res.status(201).json({
            message: "Veículo cadastrado com sucesso!",
            vehicle
        });
    }
    catch (error) {
        console.error("Erro ao cadastrar veículo:", error);
        return res.status(500).json({
            message: "Erro ao cadastrar veículo",
            error: error.message
        });
    }
}
/**
 * GET /public/vehicles?customer_id=xxx
 *
 * Lista veículos do cliente
 */
async function GET(req, res) {
    const vehicleService = req.scope.resolve(vehicle_1.VEHICLE_MODULE);
    const { customer_id } = req.query;
    if (!customer_id) {
        return res.status(400).json({
            message: "ID do cliente é obrigatório"
        });
    }
    try {
        const vehicles = await vehicleService.listVehicles({ customer_id: customer_id });
        return res.json({
            vehicles,
            count: vehicles.length
        });
    }
    catch (error) {
        console.error("Erro ao listar veículos:", error);
        return res.status(500).json({
            message: "Erro ao listar veículos",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3B1YmxpYy92ZWhpY2xlcy9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFVQSxvQkF3REM7QUFPRCxrQkE2QkM7QUFyR0Qsc0RBQXlEO0FBRTVDLFFBQUEsWUFBWSxHQUFHLEtBQUssQ0FBQTtBQUVqQzs7OztHQUlHO0FBQ0ksS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsTUFBTSxjQUFjLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsd0JBQWMsQ0FBQyxDQUFBO0lBRXhELE1BQU0sRUFDSixXQUFXLEVBQ1gsS0FBSyxFQUNMLEtBQUssRUFDTCxNQUFNLEVBQ04sR0FBRyxFQUNILEdBQUcsRUFDSCxPQUFPLEVBQ1IsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFBO0lBRVosSUFBSSxDQUFDLFdBQVcsSUFBSSxDQUFDLEtBQUssSUFBSSxDQUFDLEtBQUssSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ2hELE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLGlEQUFpRDtTQUMzRCxDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsSUFBSSxDQUFDO1FBQ0gsZ0RBQWdEO1FBQ2hELE1BQU0sZ0JBQWdCLEdBQUcsTUFBTSxjQUFjLENBQUMsWUFBWSxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtRQUVyRSxJQUFJLGdCQUFnQixDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUNoQyxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUMxQixPQUFPLEVBQUUsZ0RBQWdEO2FBQzFELENBQUMsQ0FBQTtRQUNKLENBQUM7UUFFRCxnQkFBZ0I7UUFDaEIsTUFBTSxPQUFPLEdBQUcsTUFBTSxjQUFjLENBQUMsY0FBYyxDQUFDO1lBQ2xELFdBQVc7WUFDWCxLQUFLO1lBQ0wsS0FBSztZQUNMLE1BQU07WUFDTixHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7WUFDcEMsR0FBRztZQUNILE9BQU87U0FDUixDQUFDLENBQUE7UUFFRixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSxpQ0FBaUM7WUFDMUMsT0FBTztTQUNSLENBQUMsQ0FBQTtJQUVKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyw0QkFBNEIsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUVsRCxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSwyQkFBMkI7WUFDcEMsS0FBSyxFQUFFLEtBQUssQ0FBQyxPQUFPO1NBQ3JCLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDO0FBRUQ7Ozs7R0FJRztBQUNJLEtBQUssVUFBVSxHQUFHLENBQ3ZCLEdBQWtCLEVBQ2xCLEdBQW1CO0lBRW5CLE1BQU0sY0FBYyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHdCQUFjLENBQUMsQ0FBQTtJQUN4RCxNQUFNLEVBQUUsV0FBVyxFQUFFLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQTtJQUVqQyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDakIsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsNkJBQTZCO1NBQ3ZDLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxJQUFJLENBQUM7UUFDSCxNQUFNLFFBQVEsR0FBRyxNQUFNLGNBQWMsQ0FBQyxZQUFZLENBQUMsRUFBRSxXQUFXLEVBQUUsV0FBcUIsRUFBRSxDQUFDLENBQUE7UUFFMUYsT0FBTyxHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ2QsUUFBUTtZQUNSLEtBQUssRUFBRSxRQUFRLENBQUMsTUFBTTtTQUN2QixDQUFDLENBQUE7SUFFSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsMEJBQTBCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFFaEQsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUseUJBQXlCO1lBQ2xDLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTztTQUNyQixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9