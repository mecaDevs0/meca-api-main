"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AUTHENTICATE = void 0;
exports.GET = GET;
const utils_1 = require("@medusajs/framework/utils");
const oficina_1 = require("../../../modules/oficina");
exports.AUTHENTICATE = false;
/**
 * GET /admin/users
 *
 * Lista todos os usuários (customers e workshops)
 */
async function GET(req, res) {
    const customerService = req.scope.resolve(utils_1.Modules.CUSTOMER);
    const oficinaService = req.scope.resolve(oficina_1.OFICINA_MODULE);
    const userService = req.scope.resolve(utils_1.Modules.USER);
    const { type, limit = 100, offset = 0 } = req.query;
    try {
        let users = [];
        if (!type || type === 'customer') {
            const customers = await customerService.listCustomers({}, {
                take: Number(limit),
                skip: Number(offset),
                select: ['id', 'email', 'first_name', 'last_name', 'phone', 'created_at']
            });
            users = [
                ...users,
                ...customers.map(c => ({
                    id: c.id,
                    name: `${c.first_name} ${c.last_name}`,
                    email: c.email,
                    phone: c.phone || '',
                    type: 'customer',
                    created_at: c.created_at
                }))
            ];
        }
        if (!type || type === 'workshop') {
            const oficinas = await oficinaService.listOficinas({}, {
                take: Number(limit),
                skip: Number(offset)
            });
            users = [
                ...users,
                ...oficinas.map(o => ({
                    id: o.id,
                    name: o.name,
                    email: o.email,
                    phone: o.phone || '',
                    type: 'workshop',
                    created_at: o.created_at
                }))
            ];
        }
        return res.json({
            users,
            count: users.length
        });
    }
    catch (error) {
        console.error("Erro ao listar usuários:", error);
        return res.status(500).json({
            message: "Erro ao listar usuários",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3VzZXJzL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQVdBLGtCQWlFQztBQTNFRCxxREFBbUQ7QUFDbkQsc0RBQXlEO0FBRTVDLFFBQUEsWUFBWSxHQUFHLEtBQUssQ0FBQTtBQUVqQzs7OztHQUlHO0FBQ0ksS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsTUFBTSxlQUFlLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBTyxDQUFDLFFBQVEsQ0FBQyxDQUFBO0lBQzNELE1BQU0sY0FBYyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHdCQUFjLENBQUMsQ0FBQTtJQUN4RCxNQUFNLFdBQVcsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsSUFBSSxDQUFDLENBQUE7SUFFbkQsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEdBQUcsR0FBRyxFQUFFLE1BQU0sR0FBRyxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFBO0lBRW5ELElBQUksQ0FBQztRQUNILElBQUksS0FBSyxHQUFVLEVBQUUsQ0FBQTtRQUVyQixJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksS0FBSyxVQUFVLEVBQUUsQ0FBQztZQUNqQyxNQUFNLFNBQVMsR0FBRyxNQUFNLGVBQWUsQ0FBQyxhQUFhLENBQUMsRUFBRSxFQUFFO2dCQUN4RCxJQUFJLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQztnQkFDbkIsSUFBSSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUM7Z0JBQ3BCLE1BQU0sRUFBRSxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsWUFBWSxFQUFFLFdBQVcsRUFBRSxPQUFPLEVBQUUsWUFBWSxDQUFDO2FBQzFFLENBQUMsQ0FBQTtZQUVGLEtBQUssR0FBRztnQkFDTixHQUFHLEtBQUs7Z0JBQ1IsR0FBRyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztvQkFDckIsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFO29CQUNSLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDLFNBQVMsRUFBRTtvQkFDdEMsS0FBSyxFQUFFLENBQUMsQ0FBQyxLQUFLO29CQUNkLEtBQUssRUFBRSxDQUFDLENBQUMsS0FBSyxJQUFJLEVBQUU7b0JBQ3BCLElBQUksRUFBRSxVQUFVO29CQUNoQixVQUFVLEVBQUUsQ0FBQyxDQUFDLFVBQVU7aUJBQ3pCLENBQUMsQ0FBQzthQUNKLENBQUE7UUFDSCxDQUFDO1FBRUQsSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLEtBQUssVUFBVSxFQUFFLENBQUM7WUFDakMsTUFBTSxRQUFRLEdBQUcsTUFBTSxjQUFjLENBQUMsWUFBWSxDQUFDLEVBQUUsRUFBRTtnQkFDckQsSUFBSSxFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUM7Z0JBQ25CLElBQUksRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDO2FBQ3JCLENBQUMsQ0FBQTtZQUVGLEtBQUssR0FBRztnQkFDTixHQUFHLEtBQUs7Z0JBQ1IsR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztvQkFDcEIsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFO29CQUNSLElBQUksRUFBRSxDQUFDLENBQUMsSUFBSTtvQkFDWixLQUFLLEVBQUUsQ0FBQyxDQUFDLEtBQUs7b0JBQ2QsS0FBSyxFQUFFLENBQUMsQ0FBQyxLQUFLLElBQUksRUFBRTtvQkFDcEIsSUFBSSxFQUFFLFVBQVU7b0JBQ2hCLFVBQVUsRUFBRSxDQUFDLENBQUMsVUFBVTtpQkFDekIsQ0FBQyxDQUFDO2FBQ0osQ0FBQTtRQUNILENBQUM7UUFFRCxPQUFPLEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDZCxLQUFLO1lBQ0wsS0FBSyxFQUFFLEtBQUssQ0FBQyxNQUFNO1NBQ3BCLENBQUMsQ0FBQTtJQUVKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQywwQkFBMEIsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUVoRCxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSx5QkFBeUI7WUFDbEMsS0FBSyxFQUFFLEtBQUssQ0FBQyxPQUFPO1NBQ3JCLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=