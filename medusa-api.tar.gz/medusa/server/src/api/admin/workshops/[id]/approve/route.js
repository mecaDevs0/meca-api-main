"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AUTHENTICATE = void 0;
exports.POST = POST;
const oficina_1 = require("../../../../../modules/oficina");
const oficina_2 = require("../../../../../modules/oficina/models/oficina");
exports.AUTHENTICATE = false;
/**
 * POST /admin/workshops/:id/approve
 *
 * Aprova uma oficina pendente
 */
async function POST(req, res) {
    const oficinaModuleService = req.scope.resolve(oficina_1.OFICINA_MODULE);
    const oficinaId = req.params.id;
    try {
        // Buscar oficina
        const oficina = await oficinaModuleService.retrieveOficina(oficinaId);
        if (!oficina) {
            return res.status(404).json({
                message: "Oficina não encontrada"
            });
        }
        // Aprovar oficina (sem verificar status pendente para facilitar teste)
        const updatedOficina = await oficinaModuleService.updateOficinas(oficinaId, {
            status: oficina_2.OficinaStatus.APROVADO
        });
        return res.json({
            message: "Oficina aprovada com sucesso",
            oficina: updatedOficina
        });
    }
    catch (error) {
        console.error("Erro ao aprovar oficina:", error);
        return res.status(500).json({
            message: "Erro ao aprovar oficina",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3dvcmtzaG9wcy9baWRdL2FwcHJvdmUvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBV0Esb0JBb0NDO0FBOUNELDREQUErRDtBQUMvRCwyRUFBNkU7QUFFaEUsUUFBQSxZQUFZLEdBQUcsS0FBSyxDQUFBO0FBRWpDOzs7O0dBSUc7QUFDSSxLQUFLLFVBQVUsSUFBSSxDQUN4QixHQUFrQyxFQUNsQyxHQUFtQjtJQUVuQixNQUFNLG9CQUFvQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHdCQUFjLENBQUMsQ0FBQTtJQUU5RCxNQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQTtJQUUvQixJQUFJLENBQUM7UUFDSCxpQkFBaUI7UUFDakIsTUFBTSxPQUFPLEdBQUcsTUFBTSxvQkFBb0IsQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLENBQUE7UUFFckUsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ2IsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDMUIsT0FBTyxFQUFFLHdCQUF3QjthQUNsQyxDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQsdUVBQXVFO1FBQ3ZFLE1BQU0sY0FBYyxHQUFHLE1BQU0sb0JBQW9CLENBQUMsY0FBYyxDQUFDLFNBQVMsRUFBRTtZQUMxRSxNQUFNLEVBQUUsdUJBQWEsQ0FBQyxRQUFRO1NBQy9CLENBQUMsQ0FBQTtRQUVGLE9BQU8sR0FBRyxDQUFDLElBQUksQ0FBQztZQUNkLE9BQU8sRUFBRSw4QkFBOEI7WUFDdkMsT0FBTyxFQUFFLGNBQWM7U0FDeEIsQ0FBQyxDQUFBO0lBRUosQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLDBCQUEwQixFQUFFLEtBQUssQ0FBQyxDQUFBO1FBRWhELE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLHlCQUF5QjtZQUNsQyxLQUFLLEVBQUUsS0FBSyxDQUFDLE9BQU87U0FDckIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUMifQ==