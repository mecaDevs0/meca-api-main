"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const oficina_1 = require("../../../../../modules/oficina");
const oficina_2 = require("../../../../../modules/oficina/models/oficina");
/**
 * POST /admin/workshops/:id/reject
 *
 * Rejeita uma oficina pendente
 *
 * Body:
 * - reason: Motivo da rejeição (obrigatório)
 */
async function POST(req, res) {
    const oficinaModuleService = req.scope.resolve(oficina_1.OFICINA_MODULE);
    const eventBusService = req.scope.resolve("eventBus");
    const { id: oficinaId } = req.params;
    const { reason } = req.body;
    if (!reason) {
        return res.status(400).json({
            message: "O motivo da rejeição é obrigatório"
        });
    }
    try {
        // Buscar oficina
        const oficina = await oficinaModuleService.retrieveOficina(oficinaId);
        if (!oficina) {
            return res.status(404).json({
                message: "Oficina não encontrada"
            });
        }
        // Verificar se está pendente
        if (oficina.status !== oficina_2.OficinaStatus.PENDENTE) {
            return res.status(400).json({
                message: `Esta oficina não pode ser rejeitada. Status atual: ${oficina.status}`
            });
        }
        // Rejeitar oficina
        const updatedOficina = await oficinaModuleService.updateOficinas(oficinaId, {
            status: oficina_2.OficinaStatus.REJEITADO,
            status_reason: reason,
        });
        // Emitir evento para notificar a oficina
        await eventBusService.emit("oficina.rejected", {
            oficina_id: oficinaId,
            oficina_email: oficina.email,
            oficina_name: oficina.name,
            reason,
        });
        return res.json({
            message: "Oficina rejeitada",
            oficina: updatedOficina
        });
    }
    catch (error) {
        console.error("Erro ao rejeitar oficina:", error);
        return res.status(500).json({
            message: "Erro ao rejeitar oficina",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3dvcmtzaG9wcy9baWRdL3JlamVjdC9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQVlBLG9CQTREQztBQXZFRCw0REFBK0Q7QUFDL0QsMkVBQTZFO0FBRTdFOzs7Ozs7O0dBT0c7QUFDSSxLQUFLLFVBQVUsSUFBSSxDQUN4QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixNQUFNLG9CQUFvQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHdCQUFjLENBQUMsQ0FBQTtJQUM5RCxNQUFNLGVBQWUsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQTtJQUVyRCxNQUFNLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUE7SUFDcEMsTUFBTSxFQUFFLE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUE7SUFFM0IsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ1osT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsb0NBQW9DO1NBQzlDLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxJQUFJLENBQUM7UUFDSCxpQkFBaUI7UUFDakIsTUFBTSxPQUFPLEdBQUcsTUFBTSxvQkFBb0IsQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLENBQUE7UUFFckUsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ2IsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDMUIsT0FBTyxFQUFFLHdCQUF3QjthQUNsQyxDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQsNkJBQTZCO1FBQzdCLElBQUksT0FBTyxDQUFDLE1BQU0sS0FBSyx1QkFBYSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQzlDLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQzFCLE9BQU8sRUFBRSxzREFBc0QsT0FBTyxDQUFDLE1BQU0sRUFBRTthQUNoRixDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQsbUJBQW1CO1FBQ25CLE1BQU0sY0FBYyxHQUFHLE1BQU0sb0JBQW9CLENBQUMsY0FBYyxDQUFDLFNBQVMsRUFBRTtZQUMxRSxNQUFNLEVBQUUsdUJBQWEsQ0FBQyxTQUFTO1lBQy9CLGFBQWEsRUFBRSxNQUFNO1NBQ3RCLENBQUMsQ0FBQTtRQUVGLHlDQUF5QztRQUN6QyxNQUFNLGVBQWUsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUU7WUFDN0MsVUFBVSxFQUFFLFNBQVM7WUFDckIsYUFBYSxFQUFFLE9BQU8sQ0FBQyxLQUFLO1lBQzVCLFlBQVksRUFBRSxPQUFPLENBQUMsSUFBSTtZQUMxQixNQUFNO1NBQ1AsQ0FBQyxDQUFBO1FBRUYsT0FBTyxHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ2QsT0FBTyxFQUFFLG1CQUFtQjtZQUM1QixPQUFPLEVBQUUsY0FBYztTQUN4QixDQUFDLENBQUE7SUFFSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsMkJBQTJCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFFakQsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsMEJBQTBCO1lBQ25DLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTztTQUNyQixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9