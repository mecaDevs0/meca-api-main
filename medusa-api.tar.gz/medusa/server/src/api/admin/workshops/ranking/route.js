"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AUTHENTICATE = void 0;
exports.GET = GET;
const oficina_1 = require("../../../../modules/oficina");
const booking_1 = require("../../../../modules/booking");
const review_1 = require("../../../../modules/review");
exports.AUTHENTICATE = false;
/**
 * GET /admin/workshops/ranking
 *
 * Retorna ranking completo de oficinas com métricas de performance
 */
async function GET(req, res) {
    const { period = '30', limit = 10 } = req.query;
    const oficinaService = req.scope.resolve(oficina_1.OFICINA_MODULE);
    const bookingService = req.scope.resolve(booking_1.BOOKING_MODULE);
    const reviewService = req.scope.resolve(review_1.REVIEW_MODULE);
    try {
        // Buscar todas oficinas aprovadas
        const oficinas = await oficinaService.listOficinas({
            status: "aprovado"
        });
        // Data de referência para período
        const periodStart = new Date();
        periodStart.setDate(periodStart.getDate() - parseInt(period));
        // Calcular métricas para cada oficina
        const rankingData = await Promise.all(oficinas.map(async (oficina) => {
            // Total de agendamentos
            const bookings = await bookingService.listBookings({
                oficina_id: oficina.id,
                created_at: { $gte: periodStart.toISOString() }
            });
            const totalBookings = bookings.length;
            const confirmedBookings = bookings.filter(b => ['confirmado', 'finalizado_mecanico', 'finalizado_cliente'].includes(b.status)).length;
            const acceptanceRate = totalBookings > 0
                ? Math.round((confirmedBookings / totalBookings) * 100)
                : 0;
            // Avaliações
            const reviews = await reviewService.listReviews({
                oficina_id: oficina.id
            });
            const avgRating = reviews.length > 0
                ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length
                : 0;
            // Receita total
            const revenue = bookings.reduce((sum, b) => {
                return sum + (b.final_price || b.estimated_price || 0);
            }, 0);
            // Taxa de conclusão
            const completedBookings = bookings.filter(b => b.status === 'finalizado_cliente').length;
            const completionRate = totalBookings > 0
                ? Math.round((completedBookings / totalBookings) * 100)
                : 0;
            // Tempo médio de resposta (simples - calcular depois)
            const avgResponseTime = Math.random() * 24; // Mock por enquanto - implementar depois
            return {
                oficina_id: oficina.id,
                name: oficina.name,
                logo_url: oficina.logo_url,
                address: oficina.address,
                // Métricas
                total_bookings: totalBookings,
                confirmed_bookings: confirmedBookings,
                completed_bookings: completedBookings,
                acceptance_rate: acceptanceRate,
                completion_rate: completionRate,
                // Avaliações
                total_reviews: reviews.length,
                average_rating: Math.round(avgRating * 10) / 10,
                // Financeiro
                total_revenue: revenue,
                avg_ticket: totalBookings > 0 ? Math.round(revenue / totalBookings) : 0,
                // Performance
                avg_response_time_hours: Math.round(avgResponseTime * 10) / 10,
                // Score geral (ponderado)
                performance_score: calculatePerformanceScore({
                    avgRating,
                    acceptanceRate,
                    completionRate,
                    totalBookings
                })
            };
        }));
        // Ordenar por score de performance
        rankingData.sort((a, b) => b.performance_score - a.performance_score);
        // Adicionar posição
        const ranking = rankingData.slice(0, parseInt(limit)).map((item, index) => ({
            position: index + 1,
            medal: index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : '',
            ...item
        }));
        // Insights automáticos
        const insights = generateInsights(ranking);
        return res.json({
            period_days: parseInt(period),
            total_workshops: oficinas.length,
            ranking,
            insights
        });
    }
    catch (error) {
        console.error("Erro ao gerar ranking:", error);
        return res.status(500).json({
            message: "Erro ao gerar ranking",
            error: error.message
        });
    }
}
function calculatePerformanceScore(metrics) {
    const { avgRating, acceptanceRate, completionRate, totalBookings } = metrics;
    // Pesos
    const ratingWeight = 0.35;
    const acceptanceWeight = 0.25;
    const completionWeight = 0.25;
    const volumeWeight = 0.15;
    // Normalizar volume (assumindo max de 1000 agendamentos/mês)
    const normalizedVolume = Math.min(totalBookings / 1000, 1) * 100;
    const score = (avgRating * 20 * ratingWeight) + // Rating de 0-5 -> 0-100
        (acceptanceRate * acceptanceWeight) +
        (completionRate * completionWeight) +
        (normalizedVolume * volumeWeight);
    return Math.round(score * 10) / 10;
}
function generateInsights(ranking) {
    const insights = [];
    if (ranking.length === 0)
        return insights;
    // Top performer
    const top = ranking[0];
    if (top.acceptance_rate >= 95) {
        insights.push({
            type: "success",
            icon: "💡",
            message: `${top.name} tem ${top.acceptance_rate}% de taxa de aceitação - Considere destacar como "Parceiro Premium"`
        });
    }
    // Oficinas com baixo desempenho
    const lowPerformers = ranking.filter(r => r.average_rating < 4.0);
    if (lowPerformers.length > 0) {
        insights.push({
            type: "warning",
            icon: "⚠️",
            message: `${lowPerformers.length} oficina(s) com avaliação abaixo de 4.0 - Envie feedback e suporte`
        });
    }
    // Oficinas em crescimento
    const highVolume = ranking.filter(r => r.total_bookings > 100);
    if (highVolume.length > 0) {
        insights.push({
            type: "info",
            icon: "📈",
            message: `${highVolume.length} oficina(s) com mais de 100 agendamentos - Alto volume`
        });
    }
    return insights;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3dvcmtzaG9wcy9yYW5raW5nL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQVlBLGtCQThIQztBQXpJRCx5REFBNEQ7QUFDNUQseURBQTREO0FBQzVELHVEQUEwRDtBQUU3QyxRQUFBLFlBQVksR0FBRyxLQUFLLENBQUE7QUFFakM7Ozs7R0FJRztBQUNJLEtBQUssVUFBVSxHQUFHLENBQ3ZCLEdBQWtCLEVBQ2xCLEdBQW1CO0lBRW5CLE1BQU0sRUFBRSxNQUFNLEdBQUcsSUFBSSxFQUFFLEtBQUssR0FBRyxFQUFFLEVBQUUsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFBO0lBRS9DLE1BQU0sY0FBYyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHdCQUFjLENBQUMsQ0FBQTtJQUN4RCxNQUFNLGNBQWMsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyx3QkFBYyxDQUFDLENBQUE7SUFDeEQsTUFBTSxhQUFhLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsc0JBQWEsQ0FBQyxDQUFBO0lBRXRELElBQUksQ0FBQztRQUNILGtDQUFrQztRQUNsQyxNQUFNLFFBQVEsR0FBRyxNQUFNLGNBQWMsQ0FBQyxZQUFZLENBQUM7WUFDakQsTUFBTSxFQUFFLFVBQVU7U0FDbkIsQ0FBQyxDQUFBO1FBRUYsa0NBQWtDO1FBQ2xDLE1BQU0sV0FBVyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUE7UUFDOUIsV0FBVyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLEdBQUcsUUFBUSxDQUFDLE1BQWdCLENBQUMsQ0FBQyxDQUFBO1FBRXZFLHNDQUFzQztRQUN0QyxNQUFNLFdBQVcsR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQ25DLFFBQVEsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxFQUFFO1lBQzdCLHdCQUF3QjtZQUN4QixNQUFNLFFBQVEsR0FBRyxNQUFNLGNBQWMsQ0FBQyxZQUFZLENBQUM7Z0JBQ2pELFVBQVUsRUFBRSxPQUFPLENBQUMsRUFBRTtnQkFDdEIsVUFBVSxFQUFFLEVBQUUsSUFBSSxFQUFFLFdBQVcsQ0FBQyxXQUFXLEVBQUUsRUFBRTthQUNoRCxDQUFDLENBQUE7WUFFRixNQUFNLGFBQWEsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFBO1lBQ3JDLE1BQU0saUJBQWlCLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUM1QyxDQUFDLFlBQVksRUFBRSxxQkFBcUIsRUFBRSxvQkFBb0IsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQy9FLENBQUMsTUFBTSxDQUFBO1lBRVIsTUFBTSxjQUFjLEdBQUcsYUFBYSxHQUFHLENBQUM7Z0JBQ3RDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsaUJBQWlCLEdBQUcsYUFBYSxDQUFDLEdBQUcsR0FBRyxDQUFDO2dCQUN2RCxDQUFDLENBQUMsQ0FBQyxDQUFBO1lBRUwsYUFBYTtZQUNiLE1BQU0sT0FBTyxHQUFHLE1BQU0sYUFBYSxDQUFDLFdBQVcsQ0FBQztnQkFDOUMsVUFBVSxFQUFFLE9BQU8sQ0FBQyxFQUFFO2FBQ3ZCLENBQUMsQ0FBQTtZQUVGLE1BQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQztnQkFDbEMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsR0FBRyxPQUFPLENBQUMsTUFBTTtnQkFDaEUsQ0FBQyxDQUFDLENBQUMsQ0FBQTtZQUVMLGdCQUFnQjtZQUNoQixNQUFNLE9BQU8sR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUN6QyxPQUFPLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxXQUFXLElBQUksQ0FBQyxDQUFDLGVBQWUsSUFBSSxDQUFDLENBQUMsQ0FBQTtZQUN4RCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUE7WUFFTCxvQkFBb0I7WUFDcEIsTUFBTSxpQkFBaUIsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQzVDLENBQUMsQ0FBQyxNQUFNLEtBQUssb0JBQW9CLENBQ2xDLENBQUMsTUFBTSxDQUFBO1lBRVIsTUFBTSxjQUFjLEdBQUcsYUFBYSxHQUFHLENBQUM7Z0JBQ3RDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsaUJBQWlCLEdBQUcsYUFBYSxDQUFDLEdBQUcsR0FBRyxDQUFDO2dCQUN2RCxDQUFDLENBQUMsQ0FBQyxDQUFBO1lBRUwsc0RBQXNEO1lBQ3RELE1BQU0sZUFBZSxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxFQUFFLENBQUEsQ0FBQyx5Q0FBeUM7WUFFcEYsT0FBTztnQkFDTCxVQUFVLEVBQUUsT0FBTyxDQUFDLEVBQUU7Z0JBQ3RCLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSTtnQkFDbEIsUUFBUSxFQUFFLE9BQU8sQ0FBQyxRQUFRO2dCQUMxQixPQUFPLEVBQUUsT0FBTyxDQUFDLE9BQU87Z0JBRXhCLFdBQVc7Z0JBQ1gsY0FBYyxFQUFFLGFBQWE7Z0JBQzdCLGtCQUFrQixFQUFFLGlCQUFpQjtnQkFDckMsa0JBQWtCLEVBQUUsaUJBQWlCO2dCQUNyQyxlQUFlLEVBQUUsY0FBYztnQkFDL0IsZUFBZSxFQUFFLGNBQWM7Z0JBRS9CLGFBQWE7Z0JBQ2IsYUFBYSxFQUFFLE9BQU8sQ0FBQyxNQUFNO2dCQUM3QixjQUFjLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDLEdBQUcsRUFBRTtnQkFFL0MsYUFBYTtnQkFDYixhQUFhLEVBQUUsT0FBTztnQkFDdEIsVUFBVSxFQUFFLGFBQWEsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUV2RSxjQUFjO2dCQUNkLHVCQUF1QixFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsZUFBZSxHQUFHLEVBQUUsQ0FBQyxHQUFHLEVBQUU7Z0JBRTlELDBCQUEwQjtnQkFDMUIsaUJBQWlCLEVBQUUseUJBQXlCLENBQUM7b0JBQzNDLFNBQVM7b0JBQ1QsY0FBYztvQkFDZCxjQUFjO29CQUNkLGFBQWE7aUJBQ2QsQ0FBQzthQUNILENBQUE7UUFDSCxDQUFDLENBQUMsQ0FDSCxDQUFBO1FBRUQsbUNBQW1DO1FBQ25DLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUE7UUFFckUsb0JBQW9CO1FBQ3BCLE1BQU0sT0FBTyxHQUFHLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxLQUFlLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDcEYsUUFBUSxFQUFFLEtBQUssR0FBRyxDQUFDO1lBQ25CLEtBQUssRUFBRSxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ3hFLEdBQUcsSUFBSTtTQUNSLENBQUMsQ0FBQyxDQUFBO1FBRUgsdUJBQXVCO1FBQ3ZCLE1BQU0sUUFBUSxHQUFHLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFBO1FBRTFDLE9BQU8sR0FBRyxDQUFDLElBQUksQ0FBQztZQUNkLFdBQVcsRUFBRSxRQUFRLENBQUMsTUFBZ0IsQ0FBQztZQUN2QyxlQUFlLEVBQUUsUUFBUSxDQUFDLE1BQU07WUFDaEMsT0FBTztZQUNQLFFBQVE7U0FDVCxDQUFDLENBQUE7SUFFSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsd0JBQXdCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDOUMsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsdUJBQXVCO1lBQ2hDLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTztTQUNyQixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQztBQUVELFNBQVMseUJBQXlCLENBQUMsT0FBWTtJQUM3QyxNQUFNLEVBQ0osU0FBUyxFQUNULGNBQWMsRUFDZCxjQUFjLEVBQ2QsYUFBYSxFQUNkLEdBQUcsT0FBTyxDQUFBO0lBRVgsUUFBUTtJQUNSLE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQTtJQUN6QixNQUFNLGdCQUFnQixHQUFHLElBQUksQ0FBQTtJQUM3QixNQUFNLGdCQUFnQixHQUFHLElBQUksQ0FBQTtJQUM3QixNQUFNLFlBQVksR0FBRyxJQUFJLENBQUE7SUFFekIsNkRBQTZEO0lBQzdELE1BQU0sZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEdBQUcsSUFBSSxFQUFFLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQTtJQUVoRSxNQUFNLEtBQUssR0FDVCxDQUFDLFNBQVMsR0FBRyxFQUFFLEdBQUcsWUFBWSxDQUFDLEdBQUcseUJBQXlCO1FBQzNELENBQUMsY0FBYyxHQUFHLGdCQUFnQixDQUFDO1FBQ25DLENBQUMsY0FBYyxHQUFHLGdCQUFnQixDQUFDO1FBQ25DLENBQUMsZ0JBQWdCLEdBQUcsWUFBWSxDQUFDLENBQUE7SUFFbkMsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUE7QUFDcEMsQ0FBQztBQUVELFNBQVMsZ0JBQWdCLENBQUMsT0FBYztJQUN0QyxNQUFNLFFBQVEsR0FBRyxFQUFFLENBQUE7SUFFbkIsSUFBSSxPQUFPLENBQUMsTUFBTSxLQUFLLENBQUM7UUFBRSxPQUFPLFFBQVEsQ0FBQTtJQUV6QyxnQkFBZ0I7SUFDaEIsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFBO0lBQ3RCLElBQUksR0FBRyxDQUFDLGVBQWUsSUFBSSxFQUFFLEVBQUUsQ0FBQztRQUM5QixRQUFRLENBQUMsSUFBSSxDQUFDO1lBQ1osSUFBSSxFQUFFLFNBQVM7WUFDZixJQUFJLEVBQUUsSUFBSTtZQUNWLE9BQU8sRUFBRSxHQUFHLEdBQUcsQ0FBQyxJQUFJLFFBQVEsR0FBRyxDQUFDLGVBQWUscUVBQXFFO1NBQ3JILENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxnQ0FBZ0M7SUFDaEMsTUFBTSxhQUFhLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxjQUFjLEdBQUcsR0FBRyxDQUFDLENBQUE7SUFDakUsSUFBSSxhQUFhLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO1FBQzdCLFFBQVEsQ0FBQyxJQUFJLENBQUM7WUFDWixJQUFJLEVBQUUsU0FBUztZQUNmLElBQUksRUFBRSxJQUFJO1lBQ1YsT0FBTyxFQUFFLEdBQUcsYUFBYSxDQUFDLE1BQU0sb0VBQW9FO1NBQ3JHLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCwwQkFBMEI7SUFDMUIsTUFBTSxVQUFVLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxjQUFjLEdBQUcsR0FBRyxDQUFDLENBQUE7SUFDOUQsSUFBSSxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO1FBQzFCLFFBQVEsQ0FBQyxJQUFJLENBQUM7WUFDWixJQUFJLEVBQUUsTUFBTTtZQUNaLElBQUksRUFBRSxJQUFJO1lBQ1YsT0FBTyxFQUFFLEdBQUcsVUFBVSxDQUFDLE1BQU0sd0RBQXdEO1NBQ3RGLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxPQUFPLFFBQVEsQ0FBQTtBQUNqQixDQUFDIn0=