"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AUTHENTICATE = void 0;
exports.GET = GET;
const oficina_1 = require("../../../modules/oficina");
exports.AUTHENTICATE = false;
/**
 * GET /admin/workshops
 *
 * Lista todas as oficinas
 * Query params:
 * - status: filtrar por status (pendente, aprovado, rejeitado, suspenso)
 */
async function GET(req, res) {
    const oficinaModuleService = req.scope.resolve(oficina_1.OFICINA_MODULE);
    const { status, limit = 50, offset = 0, q } = req.query;
    const filters = {};
    if (status) {
        filters.status = status;
    }
    if (q) {
        // Busca por nome ou CNPJ
        filters.$or = [
            { name: { $ilike: `%${q}%` } },
            { cnpj: { $ilike: `%${q}%` } }
        ];
    }
    try {
        const oficinas = await oficinaModuleService.listOficinas(filters, {
            take: Number(limit),
            skip: Number(offset),
            order: { created_at: "DESC" }
        });
        return res.json({
            oficinas,
            count: oficinas.length,
            limit: Number(limit),
            offset: Number(offset),
        });
    }
    catch (error) {
        console.error("Erro ao listar oficinas:", error);
        return res.status(500).json({
            message: "Erro ao listar oficinas",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3dvcmtzaG9wcy9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFZQSxrQkE0Q0M7QUF2REQsc0RBQXlEO0FBRTVDLFFBQUEsWUFBWSxHQUFHLEtBQUssQ0FBQTtBQUVqQzs7Ozs7O0dBTUc7QUFDSSxLQUFLLFVBQVUsR0FBRyxDQUN2QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixNQUFNLG9CQUFvQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHdCQUFjLENBQUMsQ0FBQTtJQUU5RCxNQUFNLEVBQUUsTUFBTSxFQUFFLEtBQUssR0FBRyxFQUFFLEVBQUUsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFBO0lBRXZELE1BQU0sT0FBTyxHQUFRLEVBQUUsQ0FBQTtJQUV2QixJQUFJLE1BQU0sRUFBRSxDQUFDO1FBQ1gsT0FBTyxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUE7SUFDekIsQ0FBQztJQUVELElBQUksQ0FBQyxFQUFFLENBQUM7UUFDTix5QkFBeUI7UUFDekIsT0FBTyxDQUFDLEdBQUcsR0FBRztZQUNaLEVBQUUsSUFBSSxFQUFFLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRTtZQUM5QixFQUFFLElBQUksRUFBRSxFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUU7U0FDL0IsQ0FBQTtJQUNILENBQUM7SUFFRCxJQUFJLENBQUM7UUFDSCxNQUFNLFFBQVEsR0FBRyxNQUFNLG9CQUFvQixDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUU7WUFDaEUsSUFBSSxFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUM7WUFDbkIsSUFBSSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUM7WUFDcEIsS0FBSyxFQUFFLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRTtTQUM5QixDQUFDLENBQUE7UUFFRixPQUFPLEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDZCxRQUFRO1lBQ1IsS0FBSyxFQUFFLFFBQVEsQ0FBQyxNQUFNO1lBQ3RCLEtBQUssRUFBRSxNQUFNLENBQUMsS0FBSyxDQUFDO1lBQ3BCLE1BQU0sRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDO1NBQ3ZCLENBQUMsQ0FBQTtJQUVKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQywwQkFBMEIsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUVoRCxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSx5QkFBeUI7WUFDbEMsS0FBSyxFQUFFLEtBQUssQ0FBQyxPQUFPO1NBQ3JCLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=