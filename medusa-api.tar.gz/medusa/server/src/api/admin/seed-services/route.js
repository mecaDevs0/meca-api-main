"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AUTHENTICATE = void 0;
exports.POST = POST;
const master_service_1 = require("../../../modules/master_service");
exports.AUTHENTICATE = false;
/**
 * POST /admin/seed-services
 * Endpoint especial para popular serviços iniciais (SEM AUTH para seed)
 */
async function POST(req, res) {
    const masterServiceService = req.scope.resolve(master_service_1.MASTER_SERVICE_MODULE);
    const services = [
        {
            name: "Troca de Óleo",
            description: "Troca de óleo do motor e filtro",
            category: "Manutenção Preventiva",
            estimated_duration_minutes: 30,
            suggested_price_min: 10000,
            suggested_price_max: 25000,
            display_order: 1,
            is_active: true
        },
        {
            name: "Alinhamento e Balanceamento",
            description: "Alinhamento e balanceamento de rodas",
            category: "Manutenção Preventiva",
            estimated_duration_minutes: 60,
            suggested_price_min: 15000,
            suggested_price_max: 30000,
            display_order: 2,
            is_active: true
        },
        {
            name: "Troca de Pneus",
            description: "Troca de pneus com montagem e balanceamento",
            category: "Pneus e Rodas",
            estimated_duration_minutes: 90,
            suggested_price_min: 50000,
            suggested_price_max: 200000,
            display_order: 3,
            is_active: true
        },
        {
            name: "Revisão Geral",
            description: "Revisão completa do veículo conforme manual",
            category: "Manutenção Preventiva",
            estimated_duration_minutes: 120,
            suggested_price_min: 30000,
            suggested_price_max: 80000,
            display_order: 4,
            is_active: true
        },
        {
            name: "Freios",
            description: "Troca de pastilhas e discos de freio",
            category: "Sistema de Freios",
            estimated_duration_minutes: 90,
            suggested_price_min: 40000,
            suggested_price_max: 150000,
            display_order: 5,
            is_active: true
        }
    ];
    try {
        const created = [];
        for (const service of services) {
            const result = await masterServiceService.createMasterServices(service);
            created.push(result);
        }
        return res.status(201).json({
            message: "Serviços base criados com sucesso",
            services: created
        });
    }
    catch (error) {
        return res.status(500).json({
            message: "Erro ao criar serviços",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NlZWQtc2VydmljZXMvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBU0Esb0JBMEVDO0FBbEZELG9FQUF1RTtBQUUxRCxRQUFBLFlBQVksR0FBRyxLQUFLLENBQUE7QUFFakM7OztHQUdHO0FBQ0ksS0FBSyxVQUFVLElBQUksQ0FBQyxHQUFrQixFQUFFLEdBQW1CO0lBQ2hFLE1BQU0sb0JBQW9CLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsc0NBQXFCLENBQUMsQ0FBQTtJQUVyRSxNQUFNLFFBQVEsR0FBRztRQUNmO1lBQ0UsSUFBSSxFQUFFLGVBQWU7WUFDckIsV0FBVyxFQUFFLGlDQUFpQztZQUM5QyxRQUFRLEVBQUUsdUJBQXVCO1lBQ2pDLDBCQUEwQixFQUFFLEVBQUU7WUFDOUIsbUJBQW1CLEVBQUUsS0FBSztZQUMxQixtQkFBbUIsRUFBRSxLQUFLO1lBQzFCLGFBQWEsRUFBRSxDQUFDO1lBQ2hCLFNBQVMsRUFBRSxJQUFJO1NBQ2hCO1FBQ0Q7WUFDRSxJQUFJLEVBQUUsNkJBQTZCO1lBQ25DLFdBQVcsRUFBRSxzQ0FBc0M7WUFDbkQsUUFBUSxFQUFFLHVCQUF1QjtZQUNqQywwQkFBMEIsRUFBRSxFQUFFO1lBQzlCLG1CQUFtQixFQUFFLEtBQUs7WUFDMUIsbUJBQW1CLEVBQUUsS0FBSztZQUMxQixhQUFhLEVBQUUsQ0FBQztZQUNoQixTQUFTLEVBQUUsSUFBSTtTQUNoQjtRQUNEO1lBQ0UsSUFBSSxFQUFFLGdCQUFnQjtZQUN0QixXQUFXLEVBQUUsNkNBQTZDO1lBQzFELFFBQVEsRUFBRSxlQUFlO1lBQ3pCLDBCQUEwQixFQUFFLEVBQUU7WUFDOUIsbUJBQW1CLEVBQUUsS0FBSztZQUMxQixtQkFBbUIsRUFBRSxNQUFNO1lBQzNCLGFBQWEsRUFBRSxDQUFDO1lBQ2hCLFNBQVMsRUFBRSxJQUFJO1NBQ2hCO1FBQ0Q7WUFDRSxJQUFJLEVBQUUsZUFBZTtZQUNyQixXQUFXLEVBQUUsNkNBQTZDO1lBQzFELFFBQVEsRUFBRSx1QkFBdUI7WUFDakMsMEJBQTBCLEVBQUUsR0FBRztZQUMvQixtQkFBbUIsRUFBRSxLQUFLO1lBQzFCLG1CQUFtQixFQUFFLEtBQUs7WUFDMUIsYUFBYSxFQUFFLENBQUM7WUFDaEIsU0FBUyxFQUFFLElBQUk7U0FDaEI7UUFDRDtZQUNFLElBQUksRUFBRSxRQUFRO1lBQ2QsV0FBVyxFQUFFLHNDQUFzQztZQUNuRCxRQUFRLEVBQUUsbUJBQW1CO1lBQzdCLDBCQUEwQixFQUFFLEVBQUU7WUFDOUIsbUJBQW1CLEVBQUUsS0FBSztZQUMxQixtQkFBbUIsRUFBRSxNQUFNO1lBQzNCLGFBQWEsRUFBRSxDQUFDO1lBQ2hCLFNBQVMsRUFBRSxJQUFJO1NBQ2hCO0tBQ0YsQ0FBQTtJQUVELElBQUksQ0FBQztRQUNILE1BQU0sT0FBTyxHQUFHLEVBQUUsQ0FBQTtRQUVsQixLQUFLLE1BQU0sT0FBTyxJQUFJLFFBQVEsRUFBRSxDQUFDO1lBQy9CLE1BQU0sTUFBTSxHQUFHLE1BQU0sb0JBQW9CLENBQUMsb0JBQW9CLENBQUMsT0FBTyxDQUFDLENBQUE7WUFDdkUsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQTtRQUN0QixDQUFDO1FBRUQsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsbUNBQW1DO1lBQzVDLFFBQVEsRUFBRSxPQUFPO1NBQ2xCLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsd0JBQXdCO1lBQ2pDLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTztTQUNyQixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9