"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AUTHENTICATE = void 0;
exports.GET = GET;
exports.POST = POST;
const master_service_1 = require("../../../modules/master_service");
exports.AUTHENTICATE = false;
/**
 * GET /admin/master-services
 *
 * Lista todos os serviços master (catálogo base)
 */
async function GET(req, res) {
    const masterServiceService = req.scope.resolve(master_service_1.MASTER_SERVICE_MODULE);
    const { category, is_active, limit = 100, offset = 0 } = req.query;
    const filters = {};
    if (category) {
        filters.category = category;
    }
    if (is_active !== undefined) {
        filters.is_active = is_active === "true";
    }
    try {
        const services = await masterServiceService.listMasterServices(filters, {
            take: Number(limit),
            skip: Number(offset),
            order: { display_order: "ASC", name: "ASC" }
        });
        return res.json({
            services,
            count: services.length,
        });
    }
    catch (error) {
        console.error("Erro ao listar serviços master:", error);
        return res.status(500).json({
            message: "Erro ao listar serviços",
            error: error.message
        });
    }
}
/**
 * POST /admin/master-services
 *
 * Admin cria um novo serviço na lista mestra
 */
async function POST(req, res) {
    const masterServiceService = req.scope.resolve(master_service_1.MASTER_SERVICE_MODULE);
    const { name, description, category, estimated_duration_minutes, suggested_price_min, suggested_price_max, icon_url, image_url, display_order } = req.body;
    // Validações
    if (!name || !category) {
        return res.status(400).json({
            message: "Nome e categoria são obrigatórios"
        });
    }
    try {
        const service = await masterServiceService.createMasterServices({
            name,
            description,
            category,
            estimated_duration_minutes,
            suggested_price_min,
            suggested_price_max,
            icon_url,
            image_url,
            display_order: display_order || 0,
            is_active: true,
        });
        return res.status(201).json({
            message: "Serviço criado com sucesso",
            service
        });
    }
    catch (error) {
        console.error("Erro ao criar serviço master:", error);
        return res.status(500).json({
            message: "Erro ao criar serviço",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL21hc3Rlci1zZXJ2aWNlcy9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFVQSxrQkFzQ0M7QUFPRCxvQkFvREM7QUExR0Qsb0VBQXVFO0FBRTFELFFBQUEsWUFBWSxHQUFHLEtBQUssQ0FBQTtBQUVqQzs7OztHQUlHO0FBQ0ksS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsTUFBTSxvQkFBb0IsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxzQ0FBcUIsQ0FBQyxDQUFBO0lBRXJFLE1BQU0sRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLEtBQUssR0FBRyxHQUFHLEVBQUUsTUFBTSxHQUFHLENBQUMsRUFBRSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUE7SUFFbEUsTUFBTSxPQUFPLEdBQVEsRUFBRSxDQUFBO0lBRXZCLElBQUksUUFBUSxFQUFFLENBQUM7UUFDYixPQUFPLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQTtJQUM3QixDQUFDO0lBRUQsSUFBSSxTQUFTLEtBQUssU0FBUyxFQUFFLENBQUM7UUFDNUIsT0FBTyxDQUFDLFNBQVMsR0FBRyxTQUFTLEtBQUssTUFBTSxDQUFBO0lBQzFDLENBQUM7SUFFRCxJQUFJLENBQUM7UUFDSCxNQUFNLFFBQVEsR0FBRyxNQUFNLG9CQUFvQixDQUFDLGtCQUFrQixDQUFDLE9BQU8sRUFBRTtZQUN0RSxJQUFJLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQztZQUNuQixJQUFJLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQztZQUNwQixLQUFLLEVBQUUsRUFBRSxhQUFhLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUU7U0FDN0MsQ0FBQyxDQUFBO1FBRUYsT0FBTyxHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ2QsUUFBUTtZQUNSLEtBQUssRUFBRSxRQUFRLENBQUMsTUFBTTtTQUN2QixDQUFDLENBQUE7SUFFSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsaUNBQWlDLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFFdkQsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUseUJBQXlCO1lBQ2xDLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTztTQUNyQixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQztBQUVEOzs7O0dBSUc7QUFDSSxLQUFLLFVBQVUsSUFBSSxDQUN4QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixNQUFNLG9CQUFvQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHNDQUFxQixDQUFDLENBQUE7SUFFckUsTUFBTSxFQUNKLElBQUksRUFDSixXQUFXLEVBQ1gsUUFBUSxFQUNSLDBCQUEwQixFQUMxQixtQkFBbUIsRUFDbkIsbUJBQW1CLEVBQ25CLFFBQVEsRUFDUixTQUFTLEVBQ1QsYUFBYSxFQUNkLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQTtJQUVaLGFBQWE7SUFDYixJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDdkIsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsbUNBQW1DO1NBQzdDLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxJQUFJLENBQUM7UUFDSCxNQUFNLE9BQU8sR0FBRyxNQUFNLG9CQUFvQixDQUFDLG9CQUFvQixDQUFDO1lBQzlELElBQUk7WUFDSixXQUFXO1lBQ1gsUUFBUTtZQUNSLDBCQUEwQjtZQUMxQixtQkFBbUI7WUFDbkIsbUJBQW1CO1lBQ25CLFFBQVE7WUFDUixTQUFTO1lBQ1QsYUFBYSxFQUFFLGFBQWEsSUFBSSxDQUFDO1lBQ2pDLFNBQVMsRUFBRSxJQUFJO1NBQ2hCLENBQUMsQ0FBQTtRQUVGLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLDRCQUE0QjtZQUNyQyxPQUFPO1NBQ1IsQ0FBQyxDQUFBO0lBRUosQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLCtCQUErQixFQUFFLEtBQUssQ0FBQyxDQUFBO1FBRXJELE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLHVCQUF1QjtZQUNoQyxLQUFLLEVBQUUsS0FBSyxDQUFDLE9BQU87U0FDckIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUMifQ==