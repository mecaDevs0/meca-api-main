"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AUTHENTICATE = void 0;
exports.GET = GET;
exports.PUT = PUT;
const system_alert_1 = require("../../../modules/system_alert");
exports.AUTHENTICATE = false;
/**
 * GET /admin/alerts
 *
 * Lista todos os alertas do sistema com filtros
 */
async function GET(req, res) {
    const { severity, category, is_read, is_resolved, limit = 50, offset = 0 } = req.query;
    const alertService = req.scope.resolve(system_alert_1.SYSTEM_ALERT_MODULE);
    try {
        const filters = {};
        if (severity)
            filters.severity = severity;
        if (category)
            filters.category = category;
        if (is_read !== undefined)
            filters.is_read = is_read === 'true';
        if (is_resolved !== undefined)
            filters.is_resolved = is_resolved === 'true';
        const alerts = await alertService.listSystemAlerts(filters, {
            take: Number(limit),
            skip: Number(offset),
            order: { created_at: "DESC" }
        });
        // Estatísticas
        const stats = {
            total: alerts.length,
            unread: alerts.filter(a => !a.is_read).length,
            unresolved: alerts.filter(a => !a.is_resolved).length,
            critical: alerts.filter(a => a.severity === 'critical').length,
            high: alerts.filter(a => a.severity === 'high').length,
        };
        return res.json({
            alerts,
            stats,
            count: alerts.length,
            limit: Number(limit),
            offset: Number(offset)
        });
    }
    catch (error) {
        console.error("Erro ao listar alertas:", error);
        return res.status(500).json({
            message: "Erro ao listar alertas",
            error: error.message
        });
    }
}
/**
 * PUT /admin/alerts/:id/resolve
 *
 * Marca um alerta como resolvido
 */
async function PUT(req, res) {
    const { id } = req.params;
    const { resolved_by, notes } = req.body;
    const alertService = req.scope.resolve(system_alert_1.SYSTEM_ALERT_MODULE);
    try {
        const alert = await alertService.updateSystemAlerts(id, {
            is_resolved: true,
            is_read: true,
            resolved_at: new Date(),
            resolved_by,
            details: {
                ...alert.details,
                resolution_notes: notes
            }
        });
        return res.json({
            message: "Alerta resolvido",
            alert
        });
    }
    catch (error) {
        console.error("Erro ao resolver alerta:", error);
        return res.status(500).json({
            message: "Erro ao resolver alerta",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2FsZXJ0cy9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFVQSxrQkFxREM7QUFPRCxrQkFpQ0M7QUF0R0QsZ0VBQW1FO0FBRXRELFFBQUEsWUFBWSxHQUFHLEtBQUssQ0FBQTtBQUVqQzs7OztHQUlHO0FBQ0ksS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsTUFBTSxFQUNKLFFBQVEsRUFDUixRQUFRLEVBQ1IsT0FBTyxFQUNQLFdBQVcsRUFDWCxLQUFLLEdBQUcsRUFBRSxFQUNWLE1BQU0sR0FBRyxDQUFDLEVBQ1gsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFBO0lBRWIsTUFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsa0NBQW1CLENBQUMsQ0FBQTtJQUUzRCxJQUFJLENBQUM7UUFDSCxNQUFNLE9BQU8sR0FBUSxFQUFFLENBQUE7UUFFdkIsSUFBSSxRQUFRO1lBQUUsT0FBTyxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUE7UUFDekMsSUFBSSxRQUFRO1lBQUUsT0FBTyxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUE7UUFDekMsSUFBSSxPQUFPLEtBQUssU0FBUztZQUFFLE9BQU8sQ0FBQyxPQUFPLEdBQUcsT0FBTyxLQUFLLE1BQU0sQ0FBQTtRQUMvRCxJQUFJLFdBQVcsS0FBSyxTQUFTO1lBQUUsT0FBTyxDQUFDLFdBQVcsR0FBRyxXQUFXLEtBQUssTUFBTSxDQUFBO1FBRTNFLE1BQU0sTUFBTSxHQUFHLE1BQU0sWUFBWSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRTtZQUMxRCxJQUFJLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQztZQUNuQixJQUFJLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQztZQUNwQixLQUFLLEVBQUUsRUFBRSxVQUFVLEVBQUUsTUFBTSxFQUFFO1NBQzlCLENBQUMsQ0FBQTtRQUVGLGVBQWU7UUFDZixNQUFNLEtBQUssR0FBRztZQUNaLEtBQUssRUFBRSxNQUFNLENBQUMsTUFBTTtZQUNwQixNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU07WUFDN0MsVUFBVSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNO1lBQ3JELFFBQVEsRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsS0FBSyxVQUFVLENBQUMsQ0FBQyxNQUFNO1lBQzlELElBQUksRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsS0FBSyxNQUFNLENBQUMsQ0FBQyxNQUFNO1NBQ3ZELENBQUE7UUFFRCxPQUFPLEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDZCxNQUFNO1lBQ04sS0FBSztZQUNMLEtBQUssRUFBRSxNQUFNLENBQUMsTUFBTTtZQUNwQixLQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQztZQUNwQixNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQztTQUN2QixDQUFDLENBQUE7SUFFSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMseUJBQXlCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDL0MsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsd0JBQXdCO1lBQ2pDLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTztTQUNyQixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQztBQUVEOzs7O0dBSUc7QUFDSSxLQUFLLFVBQVUsR0FBRyxDQUN2QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixNQUFNLEVBQUUsRUFBRSxFQUFFLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQTtJQUN6QixNQUFNLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUE7SUFFdkMsTUFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsa0NBQW1CLENBQUMsQ0FBQTtJQUUzRCxJQUFJLENBQUM7UUFDSCxNQUFNLEtBQUssR0FBRyxNQUFNLFlBQVksQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLEVBQUU7WUFDdEQsV0FBVyxFQUFFLElBQUk7WUFDakIsT0FBTyxFQUFFLElBQUk7WUFDYixXQUFXLEVBQUUsSUFBSSxJQUFJLEVBQUU7WUFDdkIsV0FBVztZQUNYLE9BQU8sRUFBRTtnQkFDUCxHQUFHLEtBQUssQ0FBQyxPQUFPO2dCQUNoQixnQkFBZ0IsRUFBRSxLQUFLO2FBQ3hCO1NBQ0YsQ0FBQyxDQUFBO1FBRUYsT0FBTyxHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ2QsT0FBTyxFQUFFLGtCQUFrQjtZQUMzQixLQUFLO1NBQ04sQ0FBQyxDQUFBO0lBRUosQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLDBCQUEwQixFQUFFLEtBQUssQ0FBQyxDQUFBO1FBQ2hELE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLHlCQUF5QjtZQUNsQyxLQUFLLEVBQUUsS0FBSyxDQUFDLE9BQU87U0FDckIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUMifQ==