"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AUTHENTICATE = void 0;
exports.POST = POST;
const fcm_notification_1 = require("../../../../modules/fcm_notification");
exports.AUTHENTICATE = false;
/**
 * POST /admin/notifications/send
 *
 * Envia notificação push para usuários
 */
async function POST(req, res) {
    const fcmService = req.scope.resolve(fcm_notification_1.FCM_NOTIFICATION_MODULE);
    const { title, message, target } = req.body;
    if (!title || !message || !target) {
        return res.status(400).json({
            message: "title, message e target são obrigatórios"
        });
    }
    try {
        // Criar notificação
        const notification = await fcmService.createFcmNotifications({
            title,
            body: message,
            data: { target },
            sent_at: new Date(),
        });
        return res.status(201).json({
            message: "Notificação enviada com sucesso",
            notification,
            sent_to: target
        });
    }
    catch (error) {
        console.error("Erro ao enviar notificação:", error);
        return res.status(500).json({
            message: "Erro ao enviar notificação",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL25vdGlmaWNhdGlvbnMvc2VuZC9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFVQSxvQkFxQ0M7QUE5Q0QsMkVBQThFO0FBRWpFLFFBQUEsWUFBWSxHQUFHLEtBQUssQ0FBQTtBQUVqQzs7OztHQUlHO0FBQ0ksS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsTUFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsMENBQXVCLENBQUMsQ0FBQTtJQUU3RCxNQUFNLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFBO0lBRTNDLElBQUksQ0FBQyxLQUFLLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNsQyxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSwwQ0FBMEM7U0FDcEQsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVELElBQUksQ0FBQztRQUNILG9CQUFvQjtRQUNwQixNQUFNLFlBQVksR0FBRyxNQUFNLFVBQVUsQ0FBQyxzQkFBc0IsQ0FBQztZQUMzRCxLQUFLO1lBQ0wsSUFBSSxFQUFFLE9BQU87WUFDYixJQUFJLEVBQUUsRUFBRSxNQUFNLEVBQUU7WUFDaEIsT0FBTyxFQUFFLElBQUksSUFBSSxFQUFFO1NBQ3BCLENBQUMsQ0FBQTtRQUVGLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLGlDQUFpQztZQUMxQyxZQUFZO1lBQ1osT0FBTyxFQUFFLE1BQU07U0FDaEIsQ0FBQyxDQUFBO0lBRUosQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLDZCQUE2QixFQUFFLEtBQUssQ0FBQyxDQUFBO1FBRW5ELE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLDRCQUE0QjtZQUNyQyxLQUFLLEVBQUUsS0FBSyxDQUFDLE9BQU87U0FDckIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUMifQ==