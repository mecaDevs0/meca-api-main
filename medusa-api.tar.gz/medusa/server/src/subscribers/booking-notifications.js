"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = bookingNotificationsHandler;
const fcm_notification_1 = require("../modules/fcm_notification");
/**
 * Subscriber: Booking Notifications
 *
 * Envia notificações push quando eventos de agendamento ocorrem
 */
async function bookingNotificationsHandler({ event, container, }) {
    const { data, name: event_name } = event;
    const fcmService = container.resolve(fcm_notification_1.FCM_MODULE);
    const logger = container.resolve("logger");
    try {
        switch (event_name) {
            case "booking.created":
                await fcmService.send({
                    to: data.oficina_id,
                    title: "Novo Agendamento! 🔔",
                    body: "Você recebeu um novo pedido de agendamento. Confira os detalhes!",
                    data: {
                        type: "new_booking",
                        booking_id: data.booking_id,
                    }
                });
                logger.info(`Notificação de novo agendamento enviada para oficina ${data.oficina_id}`);
                break;
            case "booking.confirmed":
                await fcmService.send({
                    to: data.customer_id,
                    title: "Agendamento Confirmado! ✅",
                    body: "Sua oficina confirmou o agendamento. Prepare-se para o atendimento!",
                    data: {
                        type: "booking_confirmed",
                        booking_id: data.booking_id,
                    }
                });
                logger.info(`Notificação de confirmação enviada para cliente ${data.customer_id}`);
                break;
            case "booking.rejected":
                await fcmService.send({
                    to: data.customer_id,
                    title: "Agendamento Recusado ❌",
                    body: `Infelizmente sua solicitação foi recusada. Motivo: ${data.reason}`,
                    data: {
                        type: "booking_rejected",
                        booking_id: data.booking_id,
                        reason: data.reason,
                    }
                });
                logger.info(`Notificação de rejeição enviada para cliente ${data.customer_id}`);
                break;
            case "booking.finalized_by_workshop":
                await fcmService.send({
                    to: data.customer_id,
                    title: "Serviço Finalizado! 🎉",
                    body: `Seu serviço foi concluído! Confirme e realize o pagamento de R$ ${(data.final_price / 100).toFixed(2)}`,
                    data: {
                        type: "booking_finalized",
                        booking_id: data.booking_id,
                        final_price: data.final_price,
                    }
                });
                logger.info(`Notificação de serviço finalizado enviada para cliente ${data.customer_id}`);
                break;
            default:
                logger.warn(`Evento não tratado: ${event_name}`);
        }
    }
    catch (error) {
        logger.error(`Erro ao enviar notificação para evento ${event_name}:`, error);
    }
}
exports.config = {
    event: ["booking.created", "booking.confirmed", "booking.rejected", "booking.finalized_by_workshop"],
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYm9va2luZy1ub3RpZmljYXRpb25zLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3N1YnNjcmliZXJzL2Jvb2tpbmctbm90aWZpY2F0aW9ucy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFTQSw4Q0F1RUM7QUEvRUQsa0VBQXdEO0FBRXhEOzs7O0dBSUc7QUFFWSxLQUFLLFVBQVUsMkJBQTJCLENBQUMsRUFDeEQsS0FBSyxFQUNMLFNBQVMsR0FDVztJQUNwQixNQUFNLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUUsR0FBRyxLQUFLLENBQUE7SUFDeEMsTUFBTSxVQUFVLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyw2QkFBVSxDQUFDLENBQUE7SUFDaEQsTUFBTSxNQUFNLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQTtJQUUxQyxJQUFJLENBQUM7UUFDSCxRQUFRLFVBQVUsRUFBRSxDQUFDO1lBQ25CLEtBQUssaUJBQWlCO2dCQUNwQixNQUFNLFVBQVUsQ0FBQyxJQUFJLENBQUM7b0JBQ3BCLEVBQUUsRUFBRSxJQUFJLENBQUMsVUFBVTtvQkFDbkIsS0FBSyxFQUFFLHNCQUFzQjtvQkFDN0IsSUFBSSxFQUFFLGtFQUFrRTtvQkFDeEUsSUFBSSxFQUFFO3dCQUNKLElBQUksRUFBRSxhQUFhO3dCQUNuQixVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVU7cUJBQzVCO2lCQUNGLENBQUMsQ0FBQTtnQkFDRixNQUFNLENBQUMsSUFBSSxDQUFDLHdEQUF3RCxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQTtnQkFDdEYsTUFBSztZQUVQLEtBQUssbUJBQW1CO2dCQUN0QixNQUFNLFVBQVUsQ0FBQyxJQUFJLENBQUM7b0JBQ3BCLEVBQUUsRUFBRSxJQUFJLENBQUMsV0FBVztvQkFDcEIsS0FBSyxFQUFFLDJCQUEyQjtvQkFDbEMsSUFBSSxFQUFFLHFFQUFxRTtvQkFDM0UsSUFBSSxFQUFFO3dCQUNKLElBQUksRUFBRSxtQkFBbUI7d0JBQ3pCLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVTtxQkFDNUI7aUJBQ0YsQ0FBQyxDQUFBO2dCQUNGLE1BQU0sQ0FBQyxJQUFJLENBQUMsbURBQW1ELElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFBO2dCQUNsRixNQUFLO1lBRVAsS0FBSyxrQkFBa0I7Z0JBQ3JCLE1BQU0sVUFBVSxDQUFDLElBQUksQ0FBQztvQkFDcEIsRUFBRSxFQUFFLElBQUksQ0FBQyxXQUFXO29CQUNwQixLQUFLLEVBQUUsd0JBQXdCO29CQUMvQixJQUFJLEVBQUUsc0RBQXNELElBQUksQ0FBQyxNQUFNLEVBQUU7b0JBQ3pFLElBQUksRUFBRTt3QkFDSixJQUFJLEVBQUUsa0JBQWtCO3dCQUN4QixVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVU7d0JBQzNCLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTTtxQkFDcEI7aUJBQ0YsQ0FBQyxDQUFBO2dCQUNGLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0RBQWdELElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFBO2dCQUMvRSxNQUFLO1lBRVAsS0FBSywrQkFBK0I7Z0JBQ2xDLE1BQU0sVUFBVSxDQUFDLElBQUksQ0FBQztvQkFDcEIsRUFBRSxFQUFFLElBQUksQ0FBQyxXQUFXO29CQUNwQixLQUFLLEVBQUUsd0JBQXdCO29CQUMvQixJQUFJLEVBQUUsbUVBQW1FLENBQUMsSUFBSSxDQUFDLFdBQVcsR0FBRyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7b0JBQzlHLElBQUksRUFBRTt3QkFDSixJQUFJLEVBQUUsbUJBQW1CO3dCQUN6QixVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVU7d0JBQzNCLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVztxQkFDOUI7aUJBQ0YsQ0FBQyxDQUFBO2dCQUNGLE1BQU0sQ0FBQyxJQUFJLENBQUMsMERBQTBELElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFBO2dCQUN6RixNQUFLO1lBRVA7Z0JBQ0UsTUFBTSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsVUFBVSxFQUFFLENBQUMsQ0FBQTtRQUNwRCxDQUFDO0lBRUgsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixNQUFNLENBQUMsS0FBSyxDQUFDLDBDQUEwQyxVQUFVLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQTtJQUM5RSxDQUFDO0FBQ0gsQ0FBQztBQUVZLFFBQUEsTUFBTSxHQUFxQjtJQUN0QyxLQUFLLEVBQUUsQ0FBQyxpQkFBaUIsRUFBRSxtQkFBbUIsRUFBRSxrQkFBa0IsRUFBRSwrQkFBK0IsQ0FBQztDQUNyRyxDQUFBIn0=