"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = handleOrderPlaced;
const utils_1 = require("@medusajs/framework/utils");
/**
 * Subscriber: Commission Calculator
 *
 * Calcula a comissão da MECA quando um pedido é completado
 * Escuta o evento: order.placed
 */
async function handleOrderPlaced({ event: { data }, container, }) {
    const orderModuleService = container.resolve(utils_1.Modules.ORDER);
    const logger = container.resolve("logger");
    try {
        const orderId = data.id;
        // Buscar detalhes completos do pedido
        const order = await orderModuleService.retrieveOrder(orderId, {
            relations: ["items"]
        });
        if (!order) {
            logger.warn(`Order ${orderId} não encontrado para cálculo de comissão`);
            return;
        }
        // Calcular comissão (10% do total por padrão)
        const commissionRate = parseFloat(process.env.MECA_COMMISSION_RATE || "0.10");
        const total = Number(order.total || 0);
        const commissionAmount = Math.round(total * commissionRate);
        // Armazenar comissão nos metadata do pedido
        await orderModuleService.updateOrders(orderId, {
            metadata: {
                ...(order.metadata || {}),
                meca_commission_rate: commissionRate,
                meca_commission_amount: commissionAmount,
                meca_commission_calculated_at: new Date().toISOString(),
            }
        });
        logger.info(`Comissão calculada para Order ${orderId}: R$ ${(commissionAmount / 100).toFixed(2)} (${commissionRate * 100}%)`);
    }
    catch (error) {
        logger.error(`Erro ao calcular comissão para order ${data.id}:`, error);
    }
}
exports.config = {
    event: "order.placed",
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tbWlzc2lvbi1jYWxjdWxhdG9yLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3N1YnNjcmliZXJzL2NvbW1pc3Npb24tY2FsY3VsYXRvci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFVQSxvQ0F3Q0M7QUFqREQscURBQW1EO0FBRW5EOzs7OztHQUtHO0FBRVksS0FBSyxVQUFVLGlCQUFpQixDQUFDLEVBQzlDLEtBQUssRUFBRSxFQUFFLElBQUksRUFBRSxFQUNmLFNBQVMsR0FDc0I7SUFDL0IsTUFBTSxrQkFBa0IsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLGVBQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUMzRCxNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFBO0lBRTFDLElBQUksQ0FBQztRQUNILE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxFQUFFLENBQUE7UUFFdkIsc0NBQXNDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHLE1BQU0sa0JBQWtCLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRTtZQUM1RCxTQUFTLEVBQUUsQ0FBQyxPQUFPLENBQUM7U0FDckIsQ0FBQyxDQUFBO1FBRUYsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ1gsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLE9BQU8sMENBQTBDLENBQUMsQ0FBQTtZQUN2RSxPQUFNO1FBQ1IsQ0FBQztRQUVELDhDQUE4QztRQUM5QyxNQUFNLGNBQWMsR0FBRyxVQUFVLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsSUFBSSxNQUFNLENBQUMsQ0FBQTtRQUM3RSxNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQTtRQUN0QyxNQUFNLGdCQUFnQixHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFHLGNBQWMsQ0FBQyxDQUFBO1FBRTNELDRDQUE0QztRQUM1QyxNQUFNLGtCQUFrQixDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUU7WUFDN0MsUUFBUSxFQUFFO2dCQUNSLEdBQUcsQ0FBQyxLQUFLLENBQUMsUUFBUSxJQUFJLEVBQUUsQ0FBQztnQkFDekIsb0JBQW9CLEVBQUUsY0FBYztnQkFDcEMsc0JBQXNCLEVBQUUsZ0JBQWdCO2dCQUN4Qyw2QkFBNkIsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTthQUN4RDtTQUNGLENBQUMsQ0FBQTtRQUVGLE1BQU0sQ0FBQyxJQUFJLENBQUMsaUNBQWlDLE9BQU8sUUFBUSxDQUFDLGdCQUFnQixHQUFHLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxjQUFjLEdBQUcsR0FBRyxJQUFJLENBQUMsQ0FBQTtJQUUvSCxDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE1BQU0sQ0FBQyxLQUFLLENBQUMsd0NBQXdDLElBQUksQ0FBQyxFQUFFLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQTtJQUN6RSxDQUFDO0FBQ0gsQ0FBQztBQUVZLFFBQUEsTUFBTSxHQUFxQjtJQUN0QyxLQUFLLEVBQUUsY0FBYztDQUN0QixDQUFBIn0=