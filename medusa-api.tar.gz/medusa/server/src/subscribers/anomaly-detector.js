"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = anomalyDetectorHandler;
const system_alert_1 = require("../modules/system_alert");
const booking_1 = require("../modules/booking");
const review_1 = require("../modules/review");
/**
 * Anomaly Detector - Detector de Anomalias Automático
 *
 * Monitora eventos e gera alertas quando detecta comportamentos suspeitos
 */
async function anomalyDetectorHandler({ event: { data, event_name }, container, }) {
    const alertService = container.resolve(system_alert_1.SYSTEM_ALERT_MODULE);
    const bookingService = container.resolve(booking_1.BOOKING_MODULE);
    const reviewService = container.resolve(review_1.REVIEW_MODULE);
    const logger = container.resolve("logger");
    try {
        switch (event_name) {
            case "booking.rejected":
                // Detectar oficina rejeitando muitos agendamentos
                await checkHighRejectionRate(data.oficina_id, bookingService, alertService);
                break;
            case "review.created":
                // Detectar avaliações muito baixas
                if (data.rating <= 2) {
                    await alertService.createSystemAlerts({
                        type: "warning",
                        severity: "high",
                        category: "review",
                        title: "Avaliação Baixa Detectada",
                        message: `Oficina ${data.oficina_id} recebeu avaliação ${data.rating}/5`,
                        entity_type: "workshop",
                        entity_id: data.oficina_id,
                        action_required: true,
                        details: {
                            review_id: data.review_id,
                            rating: data.rating,
                            comment: data.comment
                        },
                        triggered_by: "low_rating_detector"
                    });
                }
                break;
            case "booking.created":
                // Detectar spike de agendamentos (possível fraude/bot)
                await checkBookingSpike(data.customer_id, bookingService, alertService);
                break;
            case "order.payment_failed":
                // Alerta de falha de pagamento
                await alertService.createSystemAlerts({
                    severity: "high",
                    category: "payment",
                    title: "Falha de Pagamento",
                    message: `Pagamento falhou para o pedido ${data.order_id}`,
                    entity_type: "order",
                    entity_id: data.order_id,
                    action_required: true,
                    details: data,
                    triggered_by: "payment_failure_detector"
                });
                break;
        }
    }
    catch (error) {
        logger.error(`Erro no detector de anomalias: ${error.message}`);
    }
}
async function checkHighRejectionRate(oficinaId, bookingService, alertService) {
    // Buscar últimos 10 agendamentos da oficina
    const recentBookings = await bookingService.listBookings({ oficina_id: oficinaId }, { take: 10, order: { created_at: "DESC" } });
    if (recentBookings.length < 5)
        return; // Amostra pequena
    const rejectedCount = recentBookings.filter(b => b.status === 'recusado').length;
    const rejectionRate = (rejectedCount / recentBookings.length) * 100;
    if (rejectionRate > 50) {
        await alertService.createSystemAlerts({
            type: "warning",
            severity: "medium",
            category: "workshop",
            title: "Alta Taxa de Rejeição",
            message: `Oficina ${oficinaId} está rejeitando ${rejectionRate.toFixed(0)}% dos agendamentos`,
            entity_type: "workshop",
            entity_id: oficinaId,
            action_required: true,
            details: {
                rejection_rate: rejectionRate,
                total_bookings: recentBookings.length,
                rejected_count: rejectedCount
            },
            triggered_by: "high_rejection_detector"
        });
    }
}
async function checkBookingSpike(customerId, bookingService, alertService) {
    // Buscar agendamentos do cliente nas últimas 24h
    const dayAgo = new Date();
    dayAgo.setHours(dayAgo.getHours() - 24);
    const recentBookings = await bookingService.listBookings({
        customer_id: customerId,
        created_at: { $gte: dayAgo.toISOString() }
    });
    // Mais de 5 agendamentos em 24h é suspeito
    if (recentBookings.length > 5) {
        await alertService.createSystemAlerts({
            type: "security",
            severity: "high",
            category: "booking",
            title: "Possível Atividade Suspeita",
            message: `Cliente ${customerId} criou ${recentBookings.length} agendamentos em 24h`,
            entity_type: "client",
            entity_id: customerId,
            action_required: true,
            details: {
                booking_count: recentBookings.length,
                period_hours: 24
            },
            triggered_by: "booking_spike_detector"
        });
    }
}
exports.config = {
    event: [
        "booking.rejected",
        "review.created",
        "booking.created",
        "order.payment_failed"
    ],
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYW5vbWFseS1kZXRlY3Rvci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9zdWJzY3JpYmVycy9hbm9tYWx5LWRldGVjdG9yLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQVdBLHlDQThEQztBQXhFRCwwREFBNkQ7QUFDN0QsZ0RBQW1EO0FBQ25ELDhDQUFpRDtBQUVqRDs7OztHQUlHO0FBRVksS0FBSyxVQUFVLHNCQUFzQixDQUFDLEVBQ25ELEtBQUssRUFBRSxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUUsRUFDM0IsU0FBUyxHQUNXO0lBQ3BCLE1BQU0sWUFBWSxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsa0NBQW1CLENBQUMsQ0FBQTtJQUMzRCxNQUFNLGNBQWMsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLHdCQUFjLENBQUMsQ0FBQTtJQUN4RCxNQUFNLGFBQWEsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLHNCQUFhLENBQUMsQ0FBQTtJQUN0RCxNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFBO0lBRTFDLElBQUksQ0FBQztRQUNILFFBQVEsVUFBVSxFQUFFLENBQUM7WUFDbkIsS0FBSyxrQkFBa0I7Z0JBQ3JCLGtEQUFrRDtnQkFDbEQsTUFBTSxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLGNBQWMsRUFBRSxZQUFZLENBQUMsQ0FBQTtnQkFDM0UsTUFBSztZQUVQLEtBQUssZ0JBQWdCO2dCQUNuQixtQ0FBbUM7Z0JBQ25DLElBQUksSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUUsQ0FBQztvQkFDckIsTUFBTSxZQUFZLENBQUMsa0JBQWtCLENBQUM7d0JBQ3BDLElBQUksRUFBRSxTQUFTO3dCQUNmLFFBQVEsRUFBRSxNQUFNO3dCQUNoQixRQUFRLEVBQUUsUUFBUTt3QkFDbEIsS0FBSyxFQUFFLDJCQUEyQjt3QkFDbEMsT0FBTyxFQUFFLFdBQVcsSUFBSSxDQUFDLFVBQVUsc0JBQXNCLElBQUksQ0FBQyxNQUFNLElBQUk7d0JBQ3hFLFdBQVcsRUFBRSxVQUFVO3dCQUN2QixTQUFTLEVBQUUsSUFBSSxDQUFDLFVBQVU7d0JBQzFCLGVBQWUsRUFBRSxJQUFJO3dCQUNyQixPQUFPLEVBQUU7NEJBQ1AsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTOzRCQUN6QixNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU07NEJBQ25CLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTzt5QkFDdEI7d0JBQ0QsWUFBWSxFQUFFLHFCQUFxQjtxQkFDcEMsQ0FBQyxDQUFBO2dCQUNKLENBQUM7Z0JBQ0QsTUFBSztZQUVQLEtBQUssaUJBQWlCO2dCQUNwQix1REFBdUQ7Z0JBQ3ZELE1BQU0saUJBQWlCLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxjQUFjLEVBQUUsWUFBWSxDQUFDLENBQUE7Z0JBQ3ZFLE1BQUs7WUFFUCxLQUFLLHNCQUFzQjtnQkFDekIsK0JBQStCO2dCQUMvQixNQUFNLFlBQVksQ0FBQyxrQkFBa0IsQ0FBQztvQkFDcEMsUUFBUSxFQUFFLE1BQU07b0JBQ2hCLFFBQVEsRUFBRSxTQUFTO29CQUNuQixLQUFLLEVBQUUsb0JBQW9CO29CQUMzQixPQUFPLEVBQUUsa0NBQWtDLElBQUksQ0FBQyxRQUFRLEVBQUU7b0JBQzFELFdBQVcsRUFBRSxPQUFPO29CQUNwQixTQUFTLEVBQUUsSUFBSSxDQUFDLFFBQVE7b0JBQ3hCLGVBQWUsRUFBRSxJQUFJO29CQUNyQixPQUFPLEVBQUUsSUFBSTtvQkFDYixZQUFZLEVBQUUsMEJBQTBCO2lCQUN6QyxDQUFDLENBQUE7Z0JBQ0YsTUFBSztRQUNULENBQUM7SUFFSCxDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE1BQU0sQ0FBQyxLQUFLLENBQUMsa0NBQWtDLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFBO0lBQ2pFLENBQUM7QUFDSCxDQUFDO0FBRUQsS0FBSyxVQUFVLHNCQUFzQixDQUNuQyxTQUFpQixFQUNqQixjQUFtQixFQUNuQixZQUFpQjtJQUVqQiw0Q0FBNEM7SUFDNUMsTUFBTSxjQUFjLEdBQUcsTUFBTSxjQUFjLENBQUMsWUFBWSxDQUN0RCxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUUsRUFDekIsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUsRUFBRSxDQUM1QyxDQUFBO0lBRUQsSUFBSSxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUM7UUFBRSxPQUFNLENBQUMsa0JBQWtCO0lBRXhELE1BQU0sYUFBYSxHQUFHLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxLQUFLLFVBQVUsQ0FBQyxDQUFDLE1BQU0sQ0FBQTtJQUNoRixNQUFNLGFBQWEsR0FBRyxDQUFDLGFBQWEsR0FBRyxjQUFjLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxDQUFBO0lBRW5FLElBQUksYUFBYSxHQUFHLEVBQUUsRUFBRSxDQUFDO1FBQ3ZCLE1BQU0sWUFBWSxDQUFDLGtCQUFrQixDQUFDO1lBQ3BDLElBQUksRUFBRSxTQUFTO1lBQ2YsUUFBUSxFQUFFLFFBQVE7WUFDbEIsUUFBUSxFQUFFLFVBQVU7WUFDcEIsS0FBSyxFQUFFLHVCQUF1QjtZQUM5QixPQUFPLEVBQUUsV0FBVyxTQUFTLG9CQUFvQixhQUFhLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxvQkFBb0I7WUFDN0YsV0FBVyxFQUFFLFVBQVU7WUFDdkIsU0FBUyxFQUFFLFNBQVM7WUFDcEIsZUFBZSxFQUFFLElBQUk7WUFDckIsT0FBTyxFQUFFO2dCQUNQLGNBQWMsRUFBRSxhQUFhO2dCQUM3QixjQUFjLEVBQUUsY0FBYyxDQUFDLE1BQU07Z0JBQ3JDLGNBQWMsRUFBRSxhQUFhO2FBQzlCO1lBQ0QsWUFBWSxFQUFFLHlCQUF5QjtTQUN4QyxDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQztBQUVELEtBQUssVUFBVSxpQkFBaUIsQ0FDOUIsVUFBa0IsRUFDbEIsY0FBbUIsRUFDbkIsWUFBaUI7SUFFakIsaURBQWlEO0lBQ2pELE1BQU0sTUFBTSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUE7SUFDekIsTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUE7SUFFdkMsTUFBTSxjQUFjLEdBQUcsTUFBTSxjQUFjLENBQUMsWUFBWSxDQUFDO1FBQ3ZELFdBQVcsRUFBRSxVQUFVO1FBQ3ZCLFVBQVUsRUFBRSxFQUFFLElBQUksRUFBRSxNQUFNLENBQUMsV0FBVyxFQUFFLEVBQUU7S0FDM0MsQ0FBQyxDQUFBO0lBRUYsMkNBQTJDO0lBQzNDLElBQUksY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztRQUM5QixNQUFNLFlBQVksQ0FBQyxrQkFBa0IsQ0FBQztZQUNwQyxJQUFJLEVBQUUsVUFBVTtZQUNoQixRQUFRLEVBQUUsTUFBTTtZQUNoQixRQUFRLEVBQUUsU0FBUztZQUNuQixLQUFLLEVBQUUsNkJBQTZCO1lBQ3BDLE9BQU8sRUFBRSxXQUFXLFVBQVUsVUFBVSxjQUFjLENBQUMsTUFBTSxzQkFBc0I7WUFDbkYsV0FBVyxFQUFFLFFBQVE7WUFDckIsU0FBUyxFQUFFLFVBQVU7WUFDckIsZUFBZSxFQUFFLElBQUk7WUFDckIsT0FBTyxFQUFFO2dCQUNQLGFBQWEsRUFBRSxjQUFjLENBQUMsTUFBTTtnQkFDcEMsWUFBWSxFQUFFLEVBQUU7YUFDakI7WUFDRCxZQUFZLEVBQUUsd0JBQXdCO1NBQ3ZDLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDO0FBRVksUUFBQSxNQUFNLEdBQXFCO0lBQ3RDLEtBQUssRUFBRTtRQUNMLGtCQUFrQjtRQUNsQixnQkFBZ0I7UUFDaEIsaUJBQWlCO1FBQ2pCLHNCQUFzQjtLQUN2QjtDQUNGLENBQUEifQ==