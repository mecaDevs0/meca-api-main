import{an as u}from"./index-DxtigSoG.js";function m(e,r){const[n]=u(),s={};return e.forEach(a=>{const t=r?`${r}_${a}`:a,o=n.get(t)||void 0;s[a]=o}),s}export{m as u};
