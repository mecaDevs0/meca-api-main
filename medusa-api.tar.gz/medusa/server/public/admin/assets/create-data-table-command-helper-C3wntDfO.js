const e=()=>({command:a=>a});export{e as c};
