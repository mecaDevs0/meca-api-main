var _="product_variant_ids";export{_ as P};
