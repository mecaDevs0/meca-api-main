import{j as r}from"./index-DxtigSoG.js";var e=({children:s})=>r.jsx("span",{className:"sr-only",children:s});export{e as V};
