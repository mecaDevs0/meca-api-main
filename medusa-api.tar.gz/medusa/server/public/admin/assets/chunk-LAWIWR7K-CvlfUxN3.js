import{aN as i}from"./index-DxtigSoG.js";var a=i("product","*categories,*shipping_profile,-variants");export{a as P};
