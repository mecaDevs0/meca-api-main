"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
(0, utils_1.loadEnv)(process.env.NODE_ENV || 'development', process.cwd());
module.exports = (0, utils_1.defineConfig)({
    projectConfig: {
        databaseUrl: process.env.DATABASE_URL,
        http: {
            storeCors: process.env.STORE_CORS,
            adminCors: process.env.ADMIN_CORS,
            authCors: process.env.AUTH_CORS,
            jwtSecret: process.env.JWT_SECRET || "supersecret",
            cookieSecret: process.env.COOKIE_SECRET || "supersecret",
        },
        workerMode: process.env.WORKER_MODE === 'true' ? 'worker' : 'shared',
    },
    modules: [
        {
            resolve: "./src/modules/booking",
            options: {
                isQueryable: true
            }
        },
        {
            resolve: "./src/modules/vehicle",
            options: {
                isQueryable: true
            }
        },
        {
            resolve: "./src/modules/oficina",
            options: {
                isQueryable: true
            }
        },
        {
            resolve: "./src/modules/master_service",
            options: {
                isQueryable: true
            }
        },
        {
            resolve: "./src/modules/review",
            options: {
                isQueryable: true
            }
        },
        {
            resolve: "./src/modules/service_photo",
            options: {
                isQueryable: true
            }
        },
        {
            resolve: "./src/modules/system_alert",
            options: {
                isQueryable: true
            }
        },
        {
            resolve: "./src/modules/vehicle_history",
            options: {
                isQueryable: true
            }
        },
        {
            resolve: "./src/modules/fcm_notification",
            options: {
                isQueryable: true
            }
        },
        {
            resolve: "./src/modules/pagbank_payment",
            options: {
                isQueryable: true
            }
        }
    ]
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVkdXNhLWNvbmZpZy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL21lZHVzYS1jb25maWcudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxxREFBaUU7QUFFakUsSUFBQSxlQUFPLEVBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLElBQUksYUFBYSxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFBO0FBRTdELE1BQU0sQ0FBQyxPQUFPLEdBQUcsSUFBQSxvQkFBWSxFQUFDO0lBQzVCLGFBQWEsRUFBRTtRQUNiLFdBQVcsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVk7UUFDckMsSUFBSSxFQUFFO1lBQ0osU0FBUyxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVztZQUNsQyxTQUFTLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFXO1lBQ2xDLFFBQVEsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFNBQVU7WUFDaEMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxJQUFJLGFBQWE7WUFDbEQsWUFBWSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBYSxJQUFJLGFBQWE7U0FDekQ7UUFDRCxVQUFVLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVE7S0FDckU7SUFDRCxPQUFPLEVBQUU7UUFDUDtZQUNFLE9BQU8sRUFBRSx1QkFBdUI7WUFDaEMsT0FBTyxFQUFFO2dCQUNQLFdBQVcsRUFBRSxJQUFJO2FBQ2xCO1NBQ0Y7UUFDRDtZQUNFLE9BQU8sRUFBRSx1QkFBdUI7WUFDaEMsT0FBTyxFQUFFO2dCQUNQLFdBQVcsRUFBRSxJQUFJO2FBQ2xCO1NBQ0Y7UUFDRDtZQUNFLE9BQU8sRUFBRSx1QkFBdUI7WUFDaEMsT0FBTyxFQUFFO2dCQUNQLFdBQVcsRUFBRSxJQUFJO2FBQ2xCO1NBQ0Y7UUFDRDtZQUNFLE9BQU8sRUFBRSw4QkFBOEI7WUFDdkMsT0FBTyxFQUFFO2dCQUNQLFdBQVcsRUFBRSxJQUFJO2FBQ2xCO1NBQ0Y7UUFDRDtZQUNFLE9BQU8sRUFBRSxzQkFBc0I7WUFDL0IsT0FBTyxFQUFFO2dCQUNQLFdBQVcsRUFBRSxJQUFJO2FBQ2xCO1NBQ0Y7UUFDRDtZQUNFLE9BQU8sRUFBRSw2QkFBNkI7WUFDdEMsT0FBTyxFQUFFO2dCQUNQLFdBQVcsRUFBRSxJQUFJO2FBQ2xCO1NBQ0Y7UUFDRDtZQUNFLE9BQU8sRUFBRSw0QkFBNEI7WUFDckMsT0FBTyxFQUFFO2dCQUNQLFdBQVcsRUFBRSxJQUFJO2FBQ2xCO1NBQ0Y7UUFDRDtZQUNFLE9BQU8sRUFBRSwrQkFBK0I7WUFDeEMsT0FBTyxFQUFFO2dCQUNQLFdBQVcsRUFBRSxJQUFJO2FBQ2xCO1NBQ0Y7UUFDRDtZQUNFLE9BQU8sRUFBRSxnQ0FBZ0M7WUFDekMsT0FBTyxFQUFFO2dCQUNQLFdBQVcsRUFBRSxJQUFJO2FBQ2xCO1NBQ0Y7UUFDRDtZQUNFLE9BQU8sRUFBRSwrQkFBK0I7WUFDeEMsT0FBTyxFQUFFO2dCQUNQLFdBQVcsRUFBRSxJQUFJO2FBQ2xCO1NBQ0Y7S0FDRjtDQUNGLENBQUMsQ0FBQSJ9