import { MedusaService } from "@medusajs/framework/utils"
import { Vehicle } from "../models/vehicle"

export default class VehicleModuleService extends MedusaService({
  Vehicle,
}) {}



export default class VehicleModuleService extends MedusaService({
  Vehicle,
}) {}







export default class VehicleModuleService extends MedusaService({
  Vehicle,
}) {}



export default class VehicleModuleService extends MedusaService({
  Vehicle,
}) {}









