import { MedusaService } from "@medusajs/framework/utils"
import { Booking } from "../models/booking"

export default class BookingModuleService extends MedusaService({
  Booking,
}) {}



export default class BookingModuleService extends MedusaService({
  Booking,
}) {}







export default class BookingModuleService extends MedusaService({
  Booking,
}) {}



export default class BookingModuleService extends MedusaService({
  Booking,
}) {}









